"""Posthoc training-only instruction-pair diagnostic from complete fixed F7 forwards."""
import collections
import itertools
import json
import numpy as np
import torch
from mydata_bench.auto_research_addbase.common import create_json, read_rows, timestamp
from mydata_bench.auto_research_addbase.robust_prepare import DEST, digest
from mydata_bench.auto_research_addbase.score_branches import score_readout


def aggregate(rows):
    if not rows:
        return dict(pairs=0)
    keys=['strict_order_correct','tied','inverted','native_score_gap','expected_grade_gap','gap_absolute_error']
    groups=collections.defaultdict(list)
    for row in rows:
        groups[row['episode_group']].append(row)
    result=dict(pairs=len(rows),episode_groups=len(groups),row_pair_mean={key:float(np.mean([r[key] for r in rows])) for key in keys})
    result['episode_equal_pair_mean']={key:float(np.mean([np.mean([r[key] for r in values]) for values in groups.values()])) for key in keys}
    return result


def main():
    training=DEST/'external_training_research_v1'
    input_path=training/'grounding_v1/grounded_inputs_v1.jsonl'
    label_path=training/'fit_labels_only_v1.jsonl'
    samples=[r for r in read_rows(input_path) if r['training_partition']=='fit']
    labels={r['example_id']:r['reward'] for r in read_rows(label_path)}
    if len(samples)!=1942 or {r['example_id'] for r in samples}!=set(labels):
        raise ValueError('Exact complete fitting-only cohort required')
    groups=collections.defaultdict(list)
    for sample in samples:
        groups[sample['video_sha256']].append(sample)
    pairs=[]
    for values in groups.values():
        for a,b in itertools.combinations(values,2):
            ga,gb=labels[a['example_id']],labels[b['example_id']]
            if a['task']==b['task'] or ga==gb:
                continue
            hi,lo=(a,b) if ga>gb else (b,a)
            if hi['training_episode_group_sha256']!=lo['training_episode_group_sha256'] or hi['decoded_frame_pixel_sha256']!=lo['decoded_frame_pixel_sha256']:
                raise ValueError('Same-video pair violates displayed-frame or episode equivalence')
            pairs.append(dict(hi=hi['example_id'],lo=lo['example_id'],truth_gap=abs(ga-gb),
                episode_group=hi['training_episode_group_sha256'],
                both_grounded=hi['grounding_status']=='ok' and lo['grounding_status']=='ok'))
    support=DEST/'fit_instruction_contrast_support_audit_v1.json'
    expected=json.loads(support.read_text())['fit_encoded_video']['pair_counts']
    if len(pairs)!=expected['different_instruction_different_grade_pairs']:
        raise ValueError('Pair cohort disagrees with independent support audit')
    cases={}
    for name in ['qwen_text_video','meter_text_image']:
        model=name.split('_',1)[0]
        root=DEST/'f7_fit_finite_bias_diagnostic_v1'/name
        done=json.loads((root/'completion_v1.json').read_text())
        source=root/'records_v1.jsonl'
        if done['errors'] or digest(source)!=done['records_sha256']:
            raise ValueError('Complete F7 finite-bias provenance required')
        raw=list(read_rows(source));records={r['example_id']:r for r in raw}
        if len(raw)!=len(records) or set(records)!=set(labels) or any(r['status'] not in ['ok','no_grounding'] for r in raw):
            raise ValueError('All1942 finite-bias fitting outputs required')
        conditions={}
        for condition in ['baseline','all_query','same_heads_readout']:
            scores={};expected_grades={}
            for eid,row in records.items():
                logits=row['score_logits'][condition]
                scores[eid]=1+4*score_readout(logits,model)['progress']
                tensor=torch.tensor(logits,dtype=torch.float32)
                expected_grades[eid]=float((tensor.softmax(0)*torch.linspace(1.,5.,len(logits))).sum())
            observations=[]
            for pair in pairs:
                gap=scores[pair['hi']]-scores[pair['lo']]
                observations.append(dict(pair,native_score_gap=gap,
                    expected_grade_gap=expected_grades[pair['hi']]-expected_grades[pair['lo']],
                    strict_order_correct=float(gap>0),tied=float(gap==0),inverted=float(gap<0),
                    gap_absolute_error=abs(gap-pair['truth_gap'])))
            conditions[condition]=dict(all_pairs=aggregate(observations),
                by_truth_gap={str(g):aggregate([r for r in observations if r['truth_gap']==g]) for g in [1,2,3,4]},
                both_grounded_diagnostic=aggregate([r for r in observations if r['both_grounded']]),
                any_noROI_diagnostic=aggregate([r for r in observations if not r['both_grounded']]))
        cases[name]=dict(records_sha256=digest(source),conditions=conditions,
            noROI_rows_kept_in_primary=True,finite_b1_k48_fixed=True)
        print(name,{key:value['all_pairs'] for key,value in conditions.items()},flush=True)
    create_json(DEST/'f7_fit_instruction_pair_diagnostic_v1.json',dict(time=timestamp(),source_sha256=digest(__file__),
        fit_input_sha256=digest(input_path),fit_labels_sha256=digest(label_path),pair_support_audit_sha256=digest(support),
        cases=cases,pairs=len(pairs),both_grounded_pairs=sum(p['both_grounded'] for p in pairs),
        interpretation='posthoc fit-only pair description after CE mismatch; no independent inference, new gates, or candidate selection',
        pairwise_gap_not_a_measure_of_causal_understanding=True,correlated_pairs_not_independent_samples=True,
        expected_grade_gap_is_auxiliary_not_changed_native_output=True,validation_and_test_not_read=True,final_goal_completed=False))


if __name__=='__main__':
    main()
