"""Execute frozen score-distribution experiments, preserving all raw branches."""
import argparse,os,subprocess,time,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);p.add_argument('--models',default='qwen,rr,meter');p.add_argument('--protocols',default='text_video,video_text,text_image,image_text,interleaved');a=p.parse_args()
    root=RESEARCH/'score_development_v1';plan=json.loads((root/'prospective_plan.json').read_text())
    log=root/f'queue_gpu{a.gpu}_events.jsonl';env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(a.gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    def execute(command,folder,name):
        append(log,{'event':'launch','time':timestamp(),'command':command})
        with (folder/f'{name}.log').open('a') as f:
            proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT);code=proc.wait()
        append(log,{'event':'exit','time':timestamp(),'command':command,'returncode':code,'pid':proc.pid})
        return code
    for item in plan['configs']:
        if item['model'] not in a.models.split(',') or item['protocol'] not in a.protocols.split(','):continue
        path=pathlib.Path(item['path']);cfg=yaml.safe_load(path.read_text());assert fingerprint(cfg)==item['sha256']
        out=output_path(cfg['output_dir']);out.mkdir(parents=True,exist_ok=True)
        while True:
            free=int(subprocess.check_output(['nvidia-smi',f'--id={a.gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
            if free>=(15000 if cfg['model']=='meter' else 23000):break
            append(log,{'event':'waiting_memory','time':timestamp(),'free_mib':free});time.sleep(20)
        if not (out/'ranking.json').exists():
            for source in [item['preferred_ranking_source'],item.get('fallback_meter_ranking_source')]:
                if source and pathlib.Path(source).exists():
                    ranking=json.loads(pathlib.Path(source).read_text());ranking.update(copied_from=source,source_sha256=fingerprint(ranking));create_json(out/'ranking.json',ranking);break
        if not (out/'ranking.json').exists():
            if execute([sys.executable,'-u','-m','mydata_bench.auto_research_addbase.run','--config',str(path),'--stage','rank'],out,'rank')!=0:continue
        if execute([sys.executable,'-u','-m','mydata_bench.auto_research_addbase.score_branches','--config',str(path)],out,'score_branches')!=0:continue
        execute([sys.executable,'-u','-m','mydata_bench.auto_research_addbase.combine_scores','--folder',str(out)],out,'combine')
        print(cfg['model'],cfg['protocol'],'finished attempts',flush=True)
    append(log,{'event':'queue_completed','time':timestamp()})
if __name__=='__main__':main()
