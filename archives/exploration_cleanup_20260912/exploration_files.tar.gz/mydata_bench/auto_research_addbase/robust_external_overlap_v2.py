"""Label-free perceptual overlap audit against the entire old1213 source."""
import json
import pathlib
import time
import cv2
import numpy as np
from .common import BASE, read_rows, create_json, timestamp
from .robust_external_data import OUT
from .robust_prepare import digest


def perceptual_bits(paths):
    hashes = []
    for index in [0, 3, 7]:
        frame = cv2.imread(paths[index], cv2.IMREAD_GRAYSCALE)
        if frame is None:
            raise ValueError('Unreadable audit frame')
        reduced = cv2.resize(frame, (32, 32), interpolation=cv2.INTER_AREA).astype(np.float32)
        coefficients = cv2.dct(reduced)[:8, :8].reshape(-1)[1:]
        hashes.append(coefficients > np.median(coefficients))
    return np.stack(hashes)


def main():
    create_json(OUT / 'perceptual_overlap_plan_v2.json', dict(time=timestamp(),
        source_sha256=digest(__file__), perceptual_hash='32x32 gray DCT,8x8 minus DC,63bits',
        frame_indices_in_eight_frame_input=[0, 3, 7],
        flag_rule='Hamming distance <=4 in all three frames against any old video',
        interpretation='potential same/near video; conservative flag, not proof of identity',
        labels_accessed=False, model_predictions_accessed=False,
        policy='report all2831 and a separate independent subset excluding exact/potential overlaps; never hide exclusions'))
    launch = json.loads((OUT / 'preparation_launch_v1.json').read_text())
    while not (OUT / 'preparation_completion_v1.json').exists():
        process = pathlib.Path('/proc') / str(launch['pid']) / 'cmdline'
        if not process.exists() or b'mydata_bench.auto_research_addbase.robust_external_data' not in process.read_bytes():
            raise RuntimeError('Data preparation stopped without completion; inspect original process/output')
        time.sleep(20)
    old = {r['video_sha256']: r for r in read_rows(BASE / 'inputs/full.jsonl')}
    keys = sorted(old)
    old_bits = np.stack([perceptual_bits(old[key]['image_paths']) for key in keys])
    external = {r['video_sha256']: r for r in read_rows(OUT / 'inputs_without_labels_v1.jsonl') if r['preparation_status'] == 'ok'}
    flags = []
    exact = set()
    for i, (h, row) in enumerate(external.items(), 1):
        if row['overlaps_old_data']:
            exact.add(h)
        bits = perceptual_bits(row['image_paths'])
        distances = np.count_nonzero(old_bits != bits[None, ...], axis=-1)
        matches = np.flatnonzero((distances <= 4).all(-1))
        for match in matches:
            flags.append(dict(external_video_sha256=h, old_video_sha256=keys[match],
                              three_hamming_distances=distances[match].tolist()))
        if i % 100 == 0:
            print(json.dumps(dict(time=timestamp(), audited=i, expected=len(external), flags=len(flags))), flush=True)
    excluded = exact | {r['external_video_sha256'] for r in flags}
    inputs = list(read_rows(OUT / 'inputs_without_labels_v1.jsonl'))
    independent = [r['example_id'] for r in inputs if r['preparation_status'] == 'ok' and r['video_sha256'] not in excluded]
    create_json(OUT / 'independent_ids_before_grounding_v2.json', independent)
    create_json(OUT / 'perceptual_overlap_audit_v2.json', dict(time=timestamp(),
        expected_samples=len(inputs), prepared_video_hashes=len(external), old_video_hashes=len(old),
        unprepared_samples=sum(r['preparation_status'] != 'ok' for r in inputs), exact_overlap_hashes=sorted(exact), perceptual_flags=flags,
        conservatively_excluded_video_hashes=sorted(excluded), independent_ids=len(independent),
        labels_accessed=False, predictions_accessed=False,
        limitation='Sparse perceptual audit cannot rule out all shared source episodes or training contamination'))


if __name__ == '__main__':
    main()
