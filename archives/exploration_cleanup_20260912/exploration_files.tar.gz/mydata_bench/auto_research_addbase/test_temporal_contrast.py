import unittest
import numpy as np
from .combine_scores import combine_logits


class TemporalContrastTests(unittest.TestCase):
    def test_static_video_identity_and_zero_intervention(self):
        rng=np.random.default_rng(9)
        for bins in [5,10]:
            base,plus,minus=rng.normal(size=(3,bins))
            c={'contrast_weight':4.,'combination_type':'temporal_region_contrast'}
            self.assertEqual(combine_logits([base,plus,minus,plus,minus],c),base.tolist())
            self.assertEqual(combine_logits([base,base,base,plus,plus],c),base.tolist())
            result=combine_logits([base,plus,minus,base,base],c)
            np.testing.assert_array_equal(result,base+4*(plus-minus))
            self.assertEqual(len(result),bins)
    def test_reject_invalid_recipe(self):
        with self.assertRaises(ValueError):combine_logits([[1,2],[1]],{'contrast_weight':1.,'combination_type':'visual_contrast'})
        with self.assertRaises(ValueError):combine_logits([[1,2]]*4,{'contrast_weight':1.,'combination_type':'temporal_region_contrast'})


if __name__=='__main__':unittest.main()
