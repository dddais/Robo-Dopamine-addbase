"""Freeze F3 head selection, with shared rule and the original +6/-6 bias."""
import json
import yaml
from .common import ROOT, BASE, RESEARCH, create_json, read_rows, timestamp
from .robust_prepare import DEST, digest
from .specificity_ranking import rank_specificity


def main():
    old = json.loads((DEST / 'frame_transport_frozen_plan_v1.json').read_text())
    records = []
    expected_ranking_ids = {r['example_id'] for r in read_rows(BASE / 'inputs/ranking.jsonl')}
    for case in old['configurations']:
        name = case['model'] + '_' + case['protocol']
        config = yaml.safe_load(open(case['path']))
        measurements = RESEARCH / f'development_v1/{name}/rank.jsonl'
        if not measurements.exists():
            measurements = BASE / f'{name}_v1/rank.jsonl'
        rows = list(read_rows(measurements))
        if {r['example_id'] for r in rows} != expected_ranking_ids or len(rows) != len(expected_ranking_ids):
            raise ValueError('Ranking sample set differs from predefined34')
        ranking = rank_specificity(rows)
        ranking.update(source_path=str(measurements), source_sha256=digest(measurements),
                       scope='all_frames', query='unchanged original native ranking query')
        folder = DEST / f'specificity_v1/{name}'
        ranking_path = folder / 'ranking_v1.json'
        create_json(ranking_path, ranking)
        old_heads = json.loads(open(config['ranking_file']).read())['ranking']
        overlap = {str(k): len({(r['layer'], r['head']) for r in ranking['ranking'][:k]} &
                              {(r['layer'], r['head']) for r in old_heads[:k]}) for k in [8, 32, 48, 64]}
        conditions = [dict(name='baseline', k=0, cached_reference=True),
                      dict(name='native_generation_baseline', k=0, kind='native_generation', cached_reference=True)]
        for k in [32, 48, 64]:
            conditions.extend([
                dict(name=f'original_all_k{k}', k=k, kind='bias', bias=6., scope='all_frames', ranking='original', cached_reference=True),
                dict(name=f'specificity_k{k}', k=k, kind='bias', bias=6., scope='all_frames')])
        conditions.extend([
            dict(name='specificity_zero_k48', k=48, kind='bias', bias=0., scope='all_frames'),
            dict(name='specificity_wrong_k48', k=48, kind='bias', bias=6., scope='all_frames', region='wrong'),
            dict(name='specificity_low_k48', k=48, kind='bias', bias=6., scope='all_frames', head_group='low')])
        config.update(stage='F3_shared_label_free_specificity_ranking', clean_source_dir=config['output_dir'],
                      output_dir=str(folder), original_ranking_file=config['ranking_file'],
                      original_ranking_sha256=config['ranking_sha256'], ranking_file=str(ranking_path),
                      ranking_sha256=digest(ranking_path), conditions=conditions,
                      primary_k=48, k_neighborhood=[32, 48, 64], output_score_adjustment='none')
        for module in ['specificity_ranking.py', 'specificity_runner.py', 'freeze_specificity.py']:
            path = ROOT / 'mydata_bench/auto_research_addbase' / module
            config['source_sha256'][str(path.relative_to(ROOT))] = digest(path)
        path = ROOT / f'mydata_bench/configs/v2_crossmodel/addbase_robust_specificity_v1_{name}.yaml'
        with path.open('x') as handle:
            yaml.safe_dump(config, handle, sort_keys=False)
        records.append(dict(model=case['model'], protocol=case['protocol'], path=str(path), sha256=digest(path),
                            head_overlap_with_original=overlap,
                            top8=[(r['layer'], r['head']) for r in ranking['ranking'][:8]]))
    create_json(DEST / 'specificity_frozen_plan_v1.json', dict(time=timestamp(), configurations=records,
        main_change='replace raw_mass head order with mean excess minus 1.96 video-group SE',
        shared_parameters=dict(bias=6., k_neighborhood=[32, 48, 64], primary_k=48, variability_coefficient=1.96),
        ranking_uses_reward_labels=False, output_transform='none',
        candidate_proposed_after='F1 first9 negative development results and F2 early failures',
        F3_results_unseen_at_freeze=True, external_test_performance_not_opened=True,
        claims='ranking variability penalty is a heuristic, not post-selection confidence coverage'))
    print('F3 frozen:', len(records), 'cases; ranking34 videos; no new forward/labels needed for head order')


if __name__ == '__main__':
    main()
