"""Inference-only damping; native confidence never replaces a reward prediction."""
import numpy as np


def native_completion_confidence(model,baseline,native_generation):
    if model=='meter':
        # This is the checkpoint's separately trained task-success head, not
        # the ground-truth success label or a thresholded progress prediction.
        value=float(native_generation['success_probability'])
    elif model in {'qwen','rr'}:
        logits=np.asarray(baseline['score_logits'],dtype=np.float64)
        if logits.shape!=(5,) or not np.isfinite(logits).all():raise ValueError('Five finite native reward logits required')
        prob=np.exp(logits-logits.max());prob/=prob.sum()
        value=float(prob@np.linspace(0.,1.,5))
    else:raise ValueError('Confidence contract not specified for this model')
    if not np.isfinite(value) or not 0.<=value<=1.:raise ValueError('Native completion confidence must be a probability')
    return value


def damping_factor(confidence,power):
    if not np.isfinite(confidence) or not 0.<=confidence<=1.:raise ValueError('Invalid native confidence')
    if not np.isfinite(power) or power<=0:raise ValueError('Positive damping exponent required')
    return float((1.-confidence)**power)
