"""Recover lost schedulers while preserving live model processes and results."""
import argparse, fcntl, subprocess, time
import yaml
from .common import *


def matching_model_processes(config_path):
    found = []
    for path in pathlib.Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = path.joinpath('cmdline').read_bytes().split(b'\0')
            if b'mydata_bench.auto_research_addbase.score_branches' not in args or b'--config' not in args:
                continue
            config = pathlib.Path(args[args.index(b'--config') + 1].decode()).resolve()
            if config == config_path and path.joinpath('cwd').resolve() == ROOT:
                found.append(int(path.name))
        except (OSError, ValueError, IndexError):
            continue
    return found


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--configs', required=True)
    parser.add_argument('--gpu', type=int, required=True)
    parser.add_argument('--lost-pid', type=int, required=True)
    parser.add_argument('--name', required=True)
    args = parser.parse_args()
    if pathlib.Path(f'/proc/{args.lost_pid}').exists():
        raise ValueError('Original scheduler is still present; do not duplicate it')
    events = RESEARCH / f'{args.name}_durable_recovery_events_v1.jsonl'
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(args.gpu), OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
    append(events, {'time': timestamp(), 'event': 'recovery_started', 'pid': os.getpid(), 'lost_scheduler': args.lost_pid,
                    'policy': 'Preserve active inference; finish combination after completion; launch only unstarted remaining frozen configs. No signal sent to any model.'})
    for raw in args.configs.split(','):
        path = pathlib.Path(raw).resolve()
        cfg = yaml.safe_load(path.read_text())
        out = output_path(cfg['output_dir'])
        plan = json.loads((out / 'prospective_plan.json').read_text())
        if fingerprint(cfg) != plan['config_sha256']:
            raise ValueError('Frozen config changed')
        with (out / 'recovery_coordinator_v1.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            preserved = matching_model_processes(path)
            observed_live = bool(preserved)
            while preserved:
                append(events, {'time': timestamp(), 'event': 'waiting_preserved_model', 'config': str(path), 'pids': preserved})
                time.sleep(20)
                preserved = matching_model_processes(path)
            complete = (out / 'completion_events.jsonl').exists()
            if observed_live and not complete:
                raise RuntimeError('Preserved model exited without completion; inspect its logs before resuming')
            commands = []
            if not complete:
                # Reused rows from a frozen plan are expected for new configs.
                # A prior launch without completion is not silently retried.
                if (out / 'launches.jsonl').exists():
                    raise RuntimeError('Stopped model with no completion; explicit engineering review required')
                while int(subprocess.check_output(['nvidia-smi', f'--id={args.gpu}', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip()) < (24000 if cfg['model'] == 'meter' else 34000):
                    time.sleep(20)
                commands.append(['score_branches', '--config', str(path)])
            commands.extend([['combine_scores', '--folder', str(out)], ['materialize_supplements', '--folder', str(out)]])
            for command in commands:
                full = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.' + command[0]] + command[1:]
                if command[0] == 'combine_scores':
                    rows = {(r['example_id'], r['condition']) for r in read_rows(out / 'score_branches.jsonl')}
                    ids = json.loads(pathlib.Path(cfg['example_ids_file']).read_text())
                    missing = [(i, c['name']) for i in ids for c in cfg['branch_conditions'] if (i, c['name']) not in rows]
                    if missing:
                        raise RuntimeError(f'Completion marker lacks {len(missing)} expected branch attempts')
                append(events, {'time': timestamp(), 'event': 'launch', 'command': full})
                with (out / f'durable_recovery_{command[0]}_v1.log').open('a') as log:
                    child = subprocess.Popen(full, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                    code = child.wait()
                append(events, {'time': timestamp(), 'event': 'exit', 'pid': child.pid, 'returncode': code, 'stage': command[0]})
                if code:
                    raise RuntimeError('Recovery stage failed; raw results retained')
            append(events, {'time': timestamp(), 'event': 'case_completed', 'folder': str(out)})
    append(events, {'time': timestamp(), 'event': 'queue_completed'})


if __name__ == '__main__':
    main()
