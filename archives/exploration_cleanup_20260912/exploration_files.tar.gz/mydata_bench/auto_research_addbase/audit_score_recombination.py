"""Replay completed score combinations and summarize unlabeled diagnostics."""
import argparse
import collections
import numpy as np
from .common import *
from .combine_scores import combine_logits
from .score_branches import score_readout
from .native_confidence import native_completion_confidence, damping_factor
from mydata_bench.meter_eval.readout import canonicalize


def describe(values):
    a = np.asarray(values, dtype=float)
    return {'n': len(a), 'min': float(a.min()), 'median': float(np.median(a)),
            'p90': float(np.quantile(a, .9)), 'max': float(a.max()), 'mean': float(a.mean())} if len(a) else {'n': 0}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    folder = pathlib.Path(args.folder).resolve()
    if not (folder / 'completion_events.jsonl').exists() or not (folder / 'combination_events.jsonl').exists():
        raise ValueError('Wait for both neural branches and default combinations')
    cfg = json.loads((folder / 'config.json').read_text())
    ids = json.loads(pathlib.Path(cfg['example_ids_file']).read_text())
    raw_blob = (folder / 'score_branches.jsonl').read_bytes()
    sweep_blob = (folder / 'sweep.jsonl').read_bytes()
    raw = {(r['example_id'], r['condition']): canonicalize(r) for r in map(json.loads, raw_blob.decode().splitlines())}
    sweep = {(r['example_id'], r['condition']): canonicalize(r) for r in map(json.loads, sweep_blob.decode().splitlines())}
    issues = []
    exact, invalid = 0, 0
    by_condition = {}
    for condition in cfg['conditions']:
        name = condition['name']
        strengths, confidences, caps, divergences = [], [], [], []
        for eid in ids:
            row = sweep.get((eid, name))
            sources = condition.get('source_branches', [name])
            required = [raw.get((eid, source)) for source in sources]
            if row is None or any(r is None for r in required):
                issues.append({'example_id': eid, 'condition': name, 'fields': ['missing source/output']})
                continue
            if any(r.get('status') != 'ok' for r in required):
                if row.get('status') != 'error':
                    issues.append({'example_id': eid, 'condition': name, 'fields': ['invalid branch not propagated']})
                else:
                    invalid += 1
                continue
            if len(required) == 1 and condition.get('combination_type') != 'native_logit_temperature':
                expected = {k: required[0][k] for k in ['status', 'progress', 'score_logits', 'native_prediction', 'native_percent_prediction', 'raw_output'] if k in required[0]}
            else:
                confidence, diagnostics = None, {}
                if 'native_confidence_power' in condition:
                    confidence = native_completion_confidence(cfg['model'], raw[(eid, 'baseline')], raw[(eid, 'native_generation_baseline')])
                logits = combine_logits([r['score_logits'] for r in required], condition, confidence, diagnostics)
                expected = {'status': 'ok', 'score_logits': logits, **score_readout(logits, cfg['model']),
                            'source_score_logits': {source: r['score_logits'] for source, r in zip(sources, required)}, **diagnostics}
                if confidence is not None:
                    damping = damping_factor(confidence, condition['native_confidence_power'])
                    expected.update(native_completion_confidence=confidence, native_confidence_damping=damping)
                    strengths.append(condition['contrast_weight'] * damping)
                    confidences.append(confidence)
                elif 'target_kl' in condition:
                    audit = diagnostics['kl_budget_audit']
                    strengths.append(audit['effective_contrast_weight'])
                    divergences.append(audit['achieved_kl_p0_to_candidate_nats'])
                    caps.append(audit['gain_cap_reached'])
                else:
                    strengths.append(condition['contrast_weight'])
            different = [k for k, value in expected.items() if row.get(k) != value]
            if different:
                issues.append({'example_id': eid, 'condition': name, 'fields': different})
            else:
                exact += 1
        by_condition[name] = {'effective_contrast_weight': describe(strengths), 'native_completion_expectation_or_head': describe(confidences),
                              'achieved_kl_nats': describe(divergences), 'n_gain_cap_reached': sum(caps), 'n_kl_outputs': len(caps)}
    branch_diagnostics = {}
    for name in [c['name'] for c in cfg['branch_conditions']]:
        rows = [raw[(i, name)] for i in ids if (i, name) in raw and raw[(i, name)].get('status') == 'ok']
        mass = [r['total_probability_of_five_native_choices'] for r in rows if 'total_probability_of_five_native_choices' in r]
        branch_diagnostics[name] = {'n_valid': len(rows), 'elapsed_seconds': describe([r['elapsed_seconds'] for r in rows if 'elapsed_seconds' in r]),
                                    'five_choice_probability_mass': describe(mass),
                                    'n_five_choice_mass_below_0.5': sum(v < .5 for v in mass), 'n_five_choice_mass_below_0.9': sum(v < .9 for v in mass)}
    create_json(args.output, {'time': timestamp(), 'folder': str(folder), 'config_sha256': fingerprint(cfg),
                             'raw_source_sha256': hashlib.sha256(raw_blob).hexdigest(), 'sweep_source_sha256': hashlib.sha256(sweep_blob).hexdigest(),
                             'audit_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
                             'n_expected_outputs': len(ids) * len(cfg['conditions']), 'n_exact_valid_outputs': exact,
                             'n_expected_invalid_outputs_propagated': invalid, 'issues': issues,
                             'all_frozen_outputs_reproduced_exactly': not issues and exact + invalid == len(ids) * len(cfg['conditions']),
                             'by_condition': by_condition, 'native_branch_diagnostics': branch_diagnostics,
                             'scope': 'No labels accessed. Deterministic raw-logit recombination and native readout replay, not an independent rerun of neural inference. Duplicate conflicts are audited separately. Branch times were measured on shared GPUs and include branch-specific work; they are not controlled throughput benchmarks.'})
    print(folder.name, 'exact valid', exact, 'propagated invalid', invalid, 'issues', len(issues))


if __name__ == '__main__':
    main()
