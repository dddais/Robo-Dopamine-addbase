"""Recover metadata-count mismatches using verified actual decoded frames.

Append-only repair: every original media file, v1 frame and failure is kept.
No labels are read. OpenCV and FFprobe must agree on the decoded frame count.
"""
import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import cv2
import numpy as np
from .common import create_json, append, read_rows, timestamp
from .robust_external_data import OUT
from .robust_prepare import digest


def recover(download):
    video_hash = download['video_sha256']
    path = download['path']
    result = dict(video_sha256=video_hash, source_video_path=path, status='error')
    try:
        if digest(path) != video_hash:
            raise ValueError('Downloaded video hash changed')
        cap = cv2.VideoCapture(path)
        if not cap.isOpened():
            raise ValueError('OpenCV could not open media')
        metadata_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = float(cap.get(cv2.CAP_PROP_FPS))
        count = 0
        while True:
            ok, _ = cap.read()
            if not ok:
                break
            count += 1
        cap.release()
        probe = subprocess.run(['ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
            '-show_entries', 'stream=nb_frames,nb_read_frames,r_frame_rate,avg_frame_rate,duration,codec_name',
            '-of', 'json', path], capture_output=True, text=True, timeout=60)
        if probe.returncode or probe.stderr.strip():
            raise ValueError('FFprobe reported a decoding error: ' + probe.stderr[:500])
        stream = json.loads(probe.stdout)['streams'][0]
        if count <= 0 or count != int(stream['nb_read_frames']) or not np.isfinite(fps) or fps <= 0:
            raise ValueError('Actual frame count disagreement or invalid video')
        result.update(metadata_frame_count=metadata_count, actual_decoded_frame_count=count,
                      metadata_count_difference=metadata_count-count, ffprobe=stream)
        indices = np.linspace(0, count-1, 8).round().astype(int).tolist()
        wanted = set(indices)
        folder = OUT / 'frames_actual_decode_v2' / video_hash
        folder.mkdir(parents=True, exist_ok=True)
        cap = cv2.VideoCapture(path)
        image_paths, pixel_hashes = {}, {}
        second_count = 0
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            if second_count in wanted:
                dest = folder / f'frame_{second_count:06d}.png'
                if dest.exists():
                    raise FileExistsError(dest)
                if not cv2.imwrite(str(dest), frame):
                    raise IOError('Frame write failed')
                image_paths[second_count] = str(dest)
                pixel_hashes[second_count] = hashlib.sha256(frame.tobytes()).hexdigest()
            second_count += 1
        cap.release()
        if second_count != count or set(image_paths) != wanted:
            raise ValueError('Actual decode was not reproducible')
        result.update(status='ok', image_paths=[image_paths[i] for i in indices], image_source_indices=indices,
            decoded_frame_pixel_sha256=[pixel_hashes[i] for i in indices],
            image_sampling_record=dict(terminal_source_index=count-1, selected_source_indices=indices,
                decoded_frame_count=count, metadata_frame_count=metadata_count, source_fps=fps,
                decoder_rule='actual readable frames; OpenCV/FFprobe counts agree; no synthetic terminal frame'))
        create_json(folder / 'manifest_v2.json', result)
    except Exception as exc:
        result.update(status='error', error=repr(exc))
    return result


def main():
    v1_done = json.loads((OUT / 'preparation_completion_v1.json').read_text())
    input_path = OUT / 'inputs_without_labels_v1.jsonl'
    if digest(input_path) != v1_done['inputs_sha256']:
        raise ValueError('Frozen v1 inputs changed')
    inputs = list(read_rows(input_path))
    records = list(read_rows(OUT / 'decode_records_v1.jsonl'))
    bad = {row['video_sha256'] for row in records if row['status'] != 'ok'}
    downloads = {row['video_sha256']: row for row in read_rows(OUT / 'download_records_v1.jsonl') if row['status'] == 'ok'}
    create_json(OUT / 'actual_decode_repair_plan_v2.json', dict(time=timestamp(), source_sha256=digest(__file__),
        labels_accessed=False, model_outcomes_accessed=False, expected_samples=len(inputs),
        failed_unique_videos=len(bad), v1_inputs_sha256=digest(input_path),
        rule='all failed videos: require positive and agreeing OpenCV/FFprobe actual counts and zero FFprobe errors; sample eight actual frames including actual first and last',
        exclusions='none based on label or prediction; unrecoverable failures retained in full denominator',
        existing_media_and_results_untouched=True))
    repaired = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs = [pool.submit(recover, downloads[h]) for h in sorted(bad)]
        for i, job in enumerate(concurrent.futures.as_completed(jobs), 1):
            row = job.result()
            repaired[row['video_sha256']] = row
            append(OUT / 'actual_decode_repair_records_v2.jsonl', dict(time=timestamp(), **row))
            if i % 50 == 0 or i == len(jobs):
                print(json.dumps(dict(time=timestamp(), recovered=i, expected=len(jobs),
                    successful=sum(r['status'] == 'ok' for r in repaired.values()))), flush=True)
    output = []
    for sample in inputs:
        repair = repaired.get(sample['video_sha256'])
        row = dict(sample)
        if repair and repair['status'] == 'ok':
            row.update(preparation_status='ok', preparation_version='actual_decode_v2',
                **{k: repair[k] for k in ['image_paths', 'image_source_indices', 'image_sampling_record', 'decoded_frame_pixel_sha256']})
        else:
            row['preparation_version'] = 'unchanged_v1'
        output.append(row)
    path = OUT / 'inputs_without_labels_v2.jsonl'
    with path.open('x') as handle:
        for row in output:
            handle.write(json.dumps(row, ensure_ascii=False) + '\n')
    create_json(OUT / 'preparation_completion_v2.json', dict(time=timestamp(), expected_rows=len(output),
        ready_rows=sum(r['preparation_status'] == 'ok' for r in output),
        repaired_video_hashes=sorted(h for h, r in repaired.items() if r['status'] == 'ok'),
        remaining_failed_video_hashes=sorted(h for h, r in repaired.items() if r['status'] != 'ok'),
        inputs_sha256=digest(path), labels_sealed_sha256=v1_done['labels_sealed_sha256'],
        independent_overlap_audit_must_be_rerun_on_all_v2_inputs=True, external_performance_not_evaluated=True))


if __name__ == '__main__':
    main()
