# 抗过拟合续研进展（2026-09-10 01:32）

目标3未完成。以下是已暴露的旧234开发集结果，不是独立确认；全部失败与未完成项保留。

|候选|已分析输入/15|满足完整稳定门槛的输入数|状态|
|---|---:|---:|---|
|F1：逐帧概率搬运|15/15|0|该家族完整开发失败|
|F2：逐帧搬运+固定VCD|9/15|0|已完成部分未达标，其余继续|
|F3：面积调整的head排序|5/15|0|已完成部分未达标，其余继续|
|F4：任务文字与ROI联合注意力|5/15|0|已完成部分未达标，其余继续|
|F5：任务embedding消融的交互差分|5/15|0|已完成部分未达标，其余继续|

单个k的某项提升不等于通过。完整门槛还要求三个邻居、两种baseline、成功/失败均提高、总准确率至少+10pp、原attention改良，以及Meter两套阈值方向一致。

F6已实现公开训练标签辅助的有符号梯度选头，三个模型真实工程均通过，当前尚未拟合或验证性能。其完整说明和数据隔离规则见[续研协议](ROBUST_RESEARCH_PROTOCOL_20260909.md)。

所选训练数据2509条已完成全部下载尝试；2496条可用，13条SSL下载失败已保留。实际媒体与保留测试/旧数据的重叠审计正在运行；源episode分组未发现与保留test交叉。失败不会从原始审计记录消失。

保留外部test仍为2831条、1172个保守来源组，没有打开奖励模型测试性能；无标签定位仍运行。旧共享熵/anchor方案不计为当前目标成功。

## F1 已完成case的primary k48

来源：`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f1_frame_transport_analysis_2026-09-09T172443.406728_0000.json`

|case|MAE变化|总准确率pp|成功pp|失败pp|完整三k门槛|
|---|---:|---:|---:|---:|---|
|meter_image_text|-0.205517|0.0000|0.0000|0.0000|False|
|meter_interleaved|-0.405272|-8.9744|-28.9474|0.6329|False|
|meter_text_image|-0.335553|-8.9744|-28.9474|0.6329|False|
|meter_text_video|-0.294144|0.4274|-2.6316|1.8987|False|
|meter_video_text|-0.064762|0.0000|0.0000|0.0000|False|
|qwen_image_text|-0.128205|1.7094|0.0000|2.5316|False|
|qwen_interleaved|-0.435897|-4.7009|-17.1053|1.2658|False|
|qwen_text_image|-0.559829|3.4188|-18.4211|13.9241|False|
|qwen_text_video|-0.196581|-0.8547|-5.2632|1.2658|False|
|qwen_video_text|-0.042735|-3.4188|-2.6316|-3.7975|False|
|rr_image_text|-0.123932|2.5641|0.0000|3.7975|False|
|rr_interleaved|-0.487179|13.6752|-3.9474|22.1519|False|
|rr_text_image|-0.303419|8.9744|-1.3158|13.9241|False|
|rr_text_video|-0.410256|1.2821|3.9474|0.0000|False|
|rr_video_text|0.106838|-2.1368|3.9474|-5.0633|False|

## F2 已完成case的primary k48

来源：`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f2_frame_transport_analysis_2026-09-09T172444.229651_0000.json`

|case|MAE变化|总准确率pp|成功pp|失败pp|完整三k门槛|
|---|---:|---:|---:|---:|---|
|meter_text_video|-0.190632|7.6923|15.7895|3.7975|False|
|qwen_text_image|-0.367521|6.8376|-13.1579|16.4557|False|
|qwen_text_video|0.252137|3.4188|10.5263|0.0000|False|
|qwen_video_text|0.358974|0.4274|18.4211|-8.2278|False|
|rr_image_text|0.098291|2.1368|5.2632|0.6329|False|
|rr_interleaved|-0.452991|12.8205|9.2105|14.5570|False|
|rr_text_image|-0.461538|24.7863|13.1579|30.3797|False|
|rr_text_video|-0.153846|4.7009|14.4737|0.0000|False|
|rr_video_text|0.149573|0.4274|3.9474|-1.2658|False|

## F3 已完成case的primary k48

来源：`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f3_frame_transport_analysis_2026-09-09T163425.026175_0000.json`

|case|MAE变化|总准确率pp|成功pp|失败pp|完整三k门槛|
|---|---:|---:|---:|---:|---|
|rr_image_text|0.034188|-12.3932|-15.7895|-10.7595|False|
|rr_interleaved|-0.581197|25.6410|3.9474|36.0759|False|
|rr_text_image|-0.363248|23.5043|-3.9474|36.7089|False|
|rr_text_video|-0.628205|-6.8376|-25.0000|1.8987|False|
|rr_video_text|-0.059829|-7.6923|-13.1579|-5.0633|False|

## F4 已完成case的primary k48

来源：`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f4_frame_transport_analysis_2026-09-09T165149.021698_0000.json`

|case|MAE变化|总准确率pp|成功pp|失败pp|完整三k门槛|
|---|---:|---:|---:|---:|---|
|rr_image_text|0.017094|-7.2650|-28.9474|3.1646|False|
|rr_interleaved|-0.222222|-0.4274|-23.6842|10.7595|False|
|rr_text_image|-0.175214|8.9744|-17.1053|21.5190|False|
|rr_text_video|-0.619658|-8.1197|-26.3158|0.6329|False|
|rr_video_text|0.247863|-24.3590|-25.0000|-24.0506|False|

## F5 已完成case的primary k48

来源：`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f5_frame_transport_analysis_2026-09-09T171932.281859_0000.json`

|case|MAE变化|总准确率pp|成功pp|失败pp|完整三k门槛|
|---|---:|---:|---:|---:|---|
|rr_image_text|1.098291|-36.7521|-2.6316|-53.1646|False|
|rr_interleaved|0.465812|-4.2735|1.3158|-6.9620|False|
|rr_text_image|0.641026|2.1368|5.2632|0.6329|False|
|rr_text_video|0.371795|6.8376|21.0526|0.0000|False|
|rr_video_text|1.076923|-23.0769|17.1053|-42.4051|False|

记录UTC：2026-09-09T17:32:03.600957+00:00


### 01:32 状态追加：训练媒体审计已完成

媒体重叠审计于UTC17:30:04正常结束，不能再将其列为运行中。21个匹配记录的原因计数为{'reserved_test_sparse_perceptual_flag': 21}；保留训练资格的条数为{'validation': 493, 'fit': 1942}，隔离条数为{'validation': 28, 'fit': 46}。逐条隔离原因计数为{'reserved_test_sparse_perceptual_flag': 61, 'media_unavailable': 13}（一条可有多个原因，不能直接相加当独立样本数）。全部2509条仍在审计文件中，保留test分母未变。无标签训练任务解析已启动，1072个不同任务；尚未选头或测试奖励表现。

记录UTC：2026-09-09T17:32:32.230406+00:00
