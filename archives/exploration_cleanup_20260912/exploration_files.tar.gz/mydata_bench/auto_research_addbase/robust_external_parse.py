"""Parse external task nouns without consulting labels or grading videos."""
import hashlib
import json
import os
import pathlib
import time
import traceback
from .common import ROOT, create_json, append, read_rows, timestamp
from .robust_external_data import OUT
from .robust_prepare import digest
from mydata_bench.grounding.parser import InstructionParser


def main():
    inputs_path = OUT / 'inputs_without_labels_v4.jsonl'
    complete = json.loads((OUT / 'preparation_completion_v4.json').read_text())
    if digest(inputs_path) != complete['inputs_sha256']:
        raise ValueError('External input file changed')
    rows = list(read_rows(inputs_path))
    tasks = sorted({row['task'] for row in rows}, key=lambda text: hashlib.sha256(text.encode()).hexdigest())
    model = '/home/dais/workspace/model/Qwen3-4B-Instruct-2507'
    dest = OUT / 'grounding_v1'
    dest.mkdir(exist_ok=True)
    source = ROOT / 'mydata_bench/grounding/parser.py'
    create_json(dest / 'parser_plan_v1.json', dict(time=timestamp(), pid=os.getpid(),
        input_sha256=digest(inputs_path), unique_tasks=len(tasks), expected_samples=len(rows),
        model_path=model, model_config_sha256=digest(pathlib.Path(model) / 'config.json'),
        parser_source_sha256=digest(source), runner_source_sha256=digest(__file__),
        fields_passed_to_parser=['task', 'opaque task hash'], labels_and_model_rewards_not_used=True,
        generation='existing deterministic InstructionParser; max256; existing validated fallback retained',
        role='unlabelled localization preparation only; never reward annotation',
        future_grounding_policy='single unambiguous target from first frame then track same instance over the eight displayed frames; unsupported/failed localization retains baseline for full-test evaluation',
        final_method_test_evaluation_not_started=True))
    parser = InstructionParser(model, use_model=True)
    begin = time.monotonic()
    errors = 0
    for index, task in enumerate(tasks, 1):
        task_id = hashlib.sha256(task.encode()).hexdigest()
        record = dict(time=timestamp(), task_id=task_id)
        try:
            target = parser.parse(task, task_id)
            record.update(status='ok', target=target.to_dict())
        except Exception as exc:
            traceback.print_exc()
            errors += 1
            record.update(status='error', error=repr(exc))
        append(dest / 'parsed_targets_v1.jsonl', record)
        if index % 25 == 0 or index == len(tasks):
            print(json.dumps(dict(time=timestamp(), parsed=index, expected=len(tasks),
                                  errors=errors, elapsed_seconds=time.monotonic()-begin)), flush=True)
    create_json(dest / 'parser_completion_v1.json', dict(time=timestamp(), expected_tasks=len(tasks), errors=errors,
        records_sha256=digest(dest / 'parsed_targets_v1.jsonl'), labels_not_used=True, performance_not_evaluated=True))


if __name__ == '__main__':
    main()
