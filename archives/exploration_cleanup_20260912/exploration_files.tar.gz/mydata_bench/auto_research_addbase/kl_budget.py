"""Label-free, bounded exponential tilting of a complete native posterior."""
import numpy as np


def logsumexp(z):
    maximum=float(np.max(z))
    return maximum+float(np.log(np.exp(z-maximum).sum()))


def kl_budget_tilt(base,direction,target_kl,max_weight=64.):
    base=np.asarray(base,dtype=np.float64);direction=np.asarray(direction,dtype=np.float64)
    if base.ndim!=1 or base.shape!=direction.shape or base.size<2:raise ValueError('Matching complete native score vectors required')
    if not np.isfinite(base).all() or not np.isfinite(direction).all():raise ValueError('Finite score vectors required')
    if not np.isfinite(target_kl) or target_kl<0 or not np.isfinite(max_weight) or max_weight<=0:raise ValueError('Nonnegative KL budget and positive finite gain cap required')
    normalizer=logsumexp(base);p0=np.exp(base-normalizer)
    centered=direction-float(p0@direction)
    def divergence(weight):return max(0.,logsumexp(base+weight*centered)-normalizer)
    if target_kl==0 or np.ptp(direction)==0:weight=0.
    elif divergence(max_weight)<=target_kl:weight=float(max_weight)
    else:
        left=0.;right=float(max_weight)
        for _ in range(64):
            middle=(left+right)/2
            if divergence(middle)>target_kl:right=middle
            else:left=middle
        weight=left
    result=base+weight*centered
    return result.tolist(),{'target_kl_nats':float(target_kl),'achieved_kl_p0_to_candidate_nats':divergence(weight),
        'effective_contrast_weight':weight,'max_contrast_weight':float(max_weight),'gain_cap_reached':weight==max_weight,
        'direction_weighted_variance':float(p0@(centered**2)),'constant_direction':bool(np.ptp(direction)==0),
        'adaptation_inputs':'native score vectors only; no labels or endpoint targets'}
