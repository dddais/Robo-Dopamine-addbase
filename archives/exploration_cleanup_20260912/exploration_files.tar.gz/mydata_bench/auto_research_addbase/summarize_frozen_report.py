"""Readable supplements for every frozen neighbor; no inference or selection."""
import argparse
from .common import *
from .task_macro_summary import collect

BASELINES = ['native_generation_baseline', 'baseline']


def task_directions(candidate, baseline, metric):
    common = sorted(set(candidate['by_task']) & set(baseline['by_task']))
    defined = [t for t in common if candidate['by_task'][t].get(metric) is not None
               and baseline['by_task'][t].get(metric) is not None]
    changes = {t: candidate['by_task'][t][metric] - baseline['by_task'][t][metric] for t in defined}
    sign = -1 if 'mae' in metric else 1
    return {'n_tasks': len(common), 'n_defined': len(defined),
            'improved': [t for t, d in changes.items() if sign * d > 1e-12],
            'tied': [t for t, d in changes.items() if abs(d) <= 1e-12],
            'worsened': [t for t, d in changes.items() if sign * d < -1e-12],
            'candidate_minus_baseline_by_task': changes}


def compact(summary):
    return {'overall': summary['overall'],
            'suc': summary['by_split']['suc'], 'fail': summary['by_split']['fail'],
            'pairwise': summary['pairwise'],
            'task_macro': collect(summary)['']['metrics']}


def supplement(case):
    summaries = case['summaries']
    continuous = case['model'] in {'meter', 'sole'}
    primary = case['primary']
    neighbors = {}
    for name, comparison in case['comparisons'].items():
        s = summaries[name]
        deltas = {}
        for base in BASELINES:
            b = summaries[base]
            deltas[base] = {
                'mae': s['overall']['mae'] - b['overall']['mae'] if s['overall']['mae'] is not None and b['overall']['mae'] is not None else None,
                'continuous_ordinal_mae': s['overall']['continuous_ordinal_mae'] - b['overall']['continuous_ordinal_mae'] if s['overall']['continuous_ordinal_mae'] is not None and b['overall']['continuous_ordinal_mae'] is not None else None,
                'accuracy': s['overall']['accuracy'] - b['overall']['accuracy'],
                'suc_accuracy': s['by_split']['suc']['accuracy'] - b['by_split']['suc']['accuracy'],
                'fail_accuracy': s['by_split']['fail']['accuracy'] - b['by_split']['fail']['accuracy'],
                'endpoint_accuracy_0.2_0.8': s['overall']['endpoint_accuracy_0.2_0.8'] - b['overall']['endpoint_accuracy_0.2_0.8']}
        neighbors[name] = {'is_frozen_primary': name == primary, 'summary': compact(s), 'deltas': deltas,
                           'frozen_point_gate_vs_both_baselines': comparison['point_gate_vs_both_baselines'],
                           'frozen_improves_same_k_original': comparison.get('improves_original_same_k', comparison.get('improves_same_k_original')),
                           'additional_five_bin_mae_improves_both_baselines': s['complete'] and all(summaries[b]['complete'] and deltas[b]['mae'] is not None and deltas[b]['mae'] < 0 for b in BASELINES)}
    p = summaries[primary]
    task_changes = {base: {metric: task_directions(p, summaries[base], metric)
                          for metric in ['mae', 'continuous_ordinal_mae', 'accuracy']} for base in BASELINES}
    return {'model': case['model'], 'protocol': case['protocol'], 'primary': primary,
            'selected_ks': case['selected_ks'], 'main_mae': 'continuous_ordinal_mae' if continuous else 'mae',
            'baselines': {b: compact(summaries[b]) for b in BASELINES}, 'neighbors': neighbors,
            'all_neighbors_five_bin_mae_improve_both_baselines': all(n['additional_five_bin_mae_improves_both_baselines'] for n in neighbors.values()),
            'primary_task_directions': task_changes,
            'primary_intermediate_bin_count': sum(p['overall']['prediction_distribution'][str(i)] for i in [2, 3, 4]),
            'all_condition_summaries': {n: compact(s) for n, s in summaries.items()},
            'case_point_acceptance': case.get('confirmation_case_point_acceptance', case.get('all_frozen_neighbors_descriptive_point_acceptance')),
            'primary_joint_direction_p': case.get('primary_joint_direction_p'),
            'holm_primary_joint_direction_p': case.get('holm_primary_joint_direction_p')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    source = pathlib.Path(args.source).resolve()
    value = json.loads(source.read_text())
    sources = {str(source): hashlib.sha256(source.read_bytes()).hexdigest()}
    if 'cases' in value:
        cases = value['cases']
    elif 'report' in value:
        case = value['report']
        cases = {case['model'] + '_' + case['protocol']: case}
    elif 'case_files' in value:
        cases = {}
        for name, path in value['case_files'].items():
            blob = pathlib.Path(path).read_bytes()
            sources[path] = hashlib.sha256(blob).hexdigest()
            cases[name] = json.loads(blob)
    else:
        raise ValueError('Expected frozen confirmation or full-cohort analysis')
    reports = {name: supplement(case) for name, case in cases.items()}
    output = pathlib.Path(args.output).resolve()
    create_json(output, {'time': timestamp(), 'sources_sha256': sources, 'cases': reports,
                         'all_source_cases_included': sorted(reports) == sorted(cases),
                         'scope': 'Descriptive supplement; all frozen neighbors retained. Additional all-neighbor five-bin MAE checks and task-macro summaries do not alter the frozen point criterion or select parameters.',
                         'task_macro_boundary': 'Custom task equal weighting differs from RoboRewardBench 23-subset Overall. Main 1..5 MAE is per-example; continuous ordinal MAE is separate.',
                         'analysis_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    lines = ['# Frozen result supplement', '',
             'All source cases and frozen neighbors are included. The all-neighbor five-bin MAE check is supplemental; the frozen criterion is unchanged.', '',
             '|Case|k|Primary|Continuous ordinal MAE|Five-bin/native MAE|Total acc|Suc acc|Fail acc|Total Δ vs native (pp)|Five-bin MAE improves both baselines|',
             '|---|---:|---|---:|---:|---:|---:|---:|---:|---|']
    for name, r in reports.items():
        b = r['baselines']['native_generation_baseline']
        o = b['overall']
        lines.append(f"|{name}|native|—|{o['continuous_ordinal_mae']:.6f}|{o['mae']:.6f}|{o['accuracy']:.4%}|{b['suc']['accuracy']:.4%}|{b['fail']['accuracy']:.4%}|—|—|")
        for k, (condition, n) in zip(r['selected_ks'], r['neighbors'].items()):
            s = n['summary']; o = s['overall']; d = n['deltas']['native_generation_baseline']
            lines.append(f"|{name}|{k}|{n['is_frozen_primary']}|{o['continuous_ordinal_mae']:.6f}|{o['mae']:.6f}|{o['accuracy']:.4%}|{s['suc']['accuracy']:.4%}|{s['fail']['accuracy']:.4%}|{100*d['accuracy']:.4f}|{n['additional_five_bin_mae_improves_both_baselines']}|")
    with output.with_suffix('.md').open('x') as handle:
        handle.write('\n'.join(lines) + '\n')
    print(output)
    for name, r in reports.items():
        print(name, 'case point acceptance', r['case_point_acceptance'], 'all-neighbor five-bin MAE', r['all_neighbors_five_bin_mae_improve_both_baselines'])


if __name__ == '__main__':
    main()
