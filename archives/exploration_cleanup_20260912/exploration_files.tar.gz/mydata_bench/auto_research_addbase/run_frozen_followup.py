"""Finish the fixed cohort remainder after one GPU's confirmation queue."""
import argparse
import subprocess
import time
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, required=True)
    parser.add_argument('--cases', required=True)
    parser.add_argument('--parent-pid', type=int, required=True)
    args = parser.parse_args()
    root = RESEARCH / 'frozen_cohort_completion_v1'
    events = root / f'followup_gpu{args.gpu}_events_v1.jsonl'
    upstream = RESEARCH / f'confirmation_v1/queue_gpu{args.gpu}_events_v1.jsonl'
    names = set(args.cases.split(','))
    append(events, {'time': timestamp(), 'event': 'waiting_confirmation_queue', 'pid': os.getpid(),
                    'upstream_pid': args.parent_pid, 'cases': sorted(names)})
    while True:
        completed = {e['case'] for e in read_rows(upstream) if e['event'] == 'case_completed'} if upstream.exists() else set()
        if names <= completed:
            break
        if not pathlib.Path(f'/proc/{args.parent_pid}').exists():
            raise RuntimeError('Confirmation scheduler stopped before all cases completed; inspect and recover explicitly')
        time.sleep(20)
    command = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.run_confirmation_queue',
               '--gpu', str(args.gpu), '--cases', args.cases, '--manifest', str(root / 'frozen_manifest_v1.json')]
    with (root / f'cohort_queue_gpu{args.gpu}_v1.log').open('a') as log:
        child = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        append(events, {'time': timestamp(), 'event': 'cohort_queue_launched', 'pid': child.pid, 'command': command})
        code = child.wait()
    append(events, {'time': timestamp(), 'event': 'cohort_queue_exit', 'pid': child.pid, 'returncode': code})
    if code:
        raise RuntimeError('Frozen remainder queue failed; preserve all data')


if __name__ == '__main__':
    main()
