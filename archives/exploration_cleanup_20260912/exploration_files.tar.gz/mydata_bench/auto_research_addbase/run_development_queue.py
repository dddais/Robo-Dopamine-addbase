import argparse,json,os,subprocess
from .common import *
def main():
 p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);p.add_argument('--models',default='qwen,rr,meter');p.add_argument('--retry-errors',action='store_true');a=p.parse_args()
 dest=RESEARCH/'development_v1';plan=json.loads((dest/'prospective_plan.json').read_text());env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(a.gpu),OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
 for case in plan['cases']:
  if case['model'] not in a.models.split(','):continue
  config=pathlib.Path(case['config']);import yaml
  if fingerprint(yaml.safe_load(config.read_text()))!=case['config_sha256']:raise ValueError('Prospective config changed')
  for stage in ['rank','sweep']:
   command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.run','--config',str(config),'--stage',stage]
   if a.retry_errors:command.append('--retry-errors')
   append(dest/'queue_events.jsonl',{'time':timestamp(),'event':'start','gpu':a.gpu,'case':case,'stage':stage,'command':command})
   with (dest/f'{case["model"]}_{case["protocol"]}_{stage}.log').open('a') as f:result=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
   append(dest/'queue_events.jsonl',{'time':timestamp(),'event':'exit','case':case,'stage':stage,'returncode':result.returncode})
   if result.returncode:break
if __name__=='__main__':main()
