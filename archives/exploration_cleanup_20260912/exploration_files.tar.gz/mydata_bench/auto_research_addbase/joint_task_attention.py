"""Joint task-text and target-region steering with unchanged relative odds."""
from contextlib import contextmanager
from mydata_bench.top_eval.batch_attention_residual import batch_steering


def task_token_positions(tokenizer, input_ids, task, model, protocol):
    ids = list(input_ids)
    text = tokenizer.decode(ids, skip_special_tokens=False, clean_up_tokenization_spaces=False)
    if model == 'meter':
        marker = "The task for the robot is '"
    elif protocol == 'interleaved':
        marker = '<Task>\n`'
    else:
        marker = 'Task: '
    needle = marker + task
    if not task or text.count(needle) != 1:
        raise ValueError('Cannot uniquely locate the explicit task field')
    start = text.index(needle) + len(marker)
    end = start + len(task)
    encoded = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
    selected = [i for i, (a, b) in enumerate(encoded['offset_mapping']) if a < end and b > start]
    if not selected:
        raise ValueError('Empty task-token span')
    # Manual ANSWER-prefix appending can change suffix tokenization. The
    # complete prefix through the task must nevertheless match exactly.
    stop = selected[-1] + 1
    if list(encoded['input_ids'][:stop]) != ids[:stop]:
        raise ValueError('Decoded/re-encoded task prefix does not match actual model token IDs')
    return selected, dict(task_character_span=[start, end], task_token_span=[selected[0], selected[-1]+1],
                          exact_actual_token_prefix_verified=True, task_token_count=len(selected))


@contextmanager
def joint_task_steering(layers, heads, target, visual, task_tokens, bias=6.,
                       task_only=False, diagnostics=None):
    target, visual, task_tokens = set(target), set(visual), set(task_tokens)
    if not target or not task_tokens or not target <= visual or task_tokens & visual:
        raise ValueError('Separate nonempty task text and grounded visual spans required')
    raw = {}
    # The low-level residual kernel accepts arbitrary addressed positions.
    # Here its domain is visual keys UNION task keys, explicitly relabelled
    # below so text tokens are never reported as visual tokens.
    positive = task_tokens if task_only else target | task_tokens
    domain = task_tokens if task_only else visual | task_tokens
    with batch_steering(layers, heads, [sorted(positive)], [sorted(domain)],
                       bias, 'target_only' if task_only else 'bias', 'all', raw,
                       capture_safe=False):
        yield raw
    raw['positive_key_counts'] = raw.pop('target_counts')
    raw['addressed_key_counts'] = raw.pop('visual_counts')
    raw.update(engine='joint_task_region_native_residual_v1', actual_visual_tokens=len(visual),
               actual_visual_target_tokens=len(target), actual_task_text_tokens=len(task_tokens),
               task_only=task_only, rule='same positive bias for task text and ROI; negative bias only for other visual keys',
               visual_mass_conservation_claim=False,
               task_to_target_relative_odds_preserved=not task_only)
    if diagnostics is not None:
        diagnostics.update(raw)
