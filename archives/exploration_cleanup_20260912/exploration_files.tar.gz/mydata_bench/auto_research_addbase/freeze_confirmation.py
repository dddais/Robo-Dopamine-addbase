"""Validate development selections before freezing any confirmation outputs.

This offline admission step never reads confirmation predictions. It performs
all case checks before writing a manifest or an inference configuration.
"""
import argparse, collections, copy, re
import yaml
from .common import *
from .metrics import summarize
from .analyze_development import contrast
from .candidate_inventory import signature


def load_source(folder):
    folder = pathlib.Path(folder).resolve()
    if not folder.is_relative_to(RESEARCH) or 'confirmation' in folder.name:
        raise ValueError('Selection source must be a development folder')
    cfg = json.loads((folder / 'config.json').read_text())
    if 'development' not in cfg.get('stage', ''):
        raise ValueError('Development provenance required')
    plan = json.loads((folder / 'prospective_plan.json').read_text())
    if plan.get('config_sha256') != fingerprint(cfg):
        raise ValueError('Development configuration differs from its frozen plan')
    branches = list(cfg['branch_conditions'])
    conditions = list(cfg['conditions'])
    supplements = []
    ledger = folder / 'analysis_supplements.jsonl'
    if ledger.exists():
        for entry in read_rows(ledger):
            data = json.loads(pathlib.Path(entry['path']).read_text())
            if fingerprint(data) != entry['sha256']:
                raise ValueError('Development supplement hash changed')
            branches += data.get('branch_conditions', [])
            conditions += data.get('conditions', [])
            supplements.append(entry)
    for collection in [branches, conditions]:
        if len({c['name'] for c in collection}) != len(collection):
            raise ValueError('Duplicate source condition/branch names')
    blob = (folder / 'sweep.jsonl').read_bytes()
    rows = collections.defaultdict(list)
    for line in blob.decode().splitlines():
        row = json.loads(line)
        rows[row['condition']].append(row)
    return cfg, {c['name']: c for c in branches}, {c['name']: c for c in conditions}, rows, {
        'folder': str(folder), 'config_sha256': fingerprint(cfg),
        'sweep_sha256': hashlib.sha256(blob).hexdigest(), 'supplements': supplements,
    }


def validate_case(case, labels, development_ids):
    cfg, branches, conditions, rows, source = load_source(case['folder'])
    source_ids = json.loads(pathlib.Path(cfg['example_ids_file']).read_text())
    if set(source_ids) != set(development_ids) or len(source_ids) != len(development_ids):
        raise ValueError('Every selected case must cover the complete frozen development set')
    selected = case['conditions']
    if len(selected) < 3 or len(set(selected)) != len(selected) or case['primary'] not in selected:
        raise ValueError('A primary and at least three distinct neighboring conditions are required')
    recipes = [conditions[name] for name in selected]
    if any(not c['name'].startswith('contrast_target_') for c in recipes):
        raise ValueError('Only task-target attention evidence can be selected')
    if len({signature(c) for c in recipes}) != 1 or len({c['k'] for c in recipes}) != len(recipes):
        raise ValueError('Selected k must share every other recipe parameter')
    ks = sorted(c['k'] for c in recipes)
    tested = sorted({c['k'] for c in conditions.values() if c['name'].startswith('contrast_target_') and signature(c) == signature(recipes[0])})
    if [k for k in tested if ks[0] <= k <= ks[-1]] != ks:
        raise ValueError('A selected neighborhood must not skip a tested intermediate k')
    # Verify semantic branch configurations as well as top-level recipe fields.
    defaults = {'kind': None, 'scope': 'last_frame', 'region': 'target', 'head_group': 'high',
                'media_condition': 'observed', 'query_scope': 'all', 'bias': 3.}
    branch_signatures = []
    for c in recipes:
        branch_signatures.append(fingerprint([{key: branches[name].get(key, default) for key, default in defaults.items()}
                                              for name in c['source_branches']]))
    if len(set(branch_signatures)) != 1:
        raise ValueError('Neighbor branches differ in more than k')
    continuous = cfg['model'] in {'meter', 'sole'}
    summaries = {name: summarize(rr, labels, development_ids) for name, rr in rows.items()}
    baseline, native = summaries['baseline'], summaries['native_generation_baseline']
    zero_audits = {}
    zero_pairs = [('baseline', 'zero_preserve_k32')]
    if any(c.get('combination_type') == 'temporal_region_contrast' for c in recipes):
        zero_pairs.append(('static_baseline', 'static_zero_preserve_k32'))
    for reference, zero in zero_pairs:
        base_rows = {r['example_id']: r for r in rows[reference]}
        zero_rows = {r['example_id']: r for r in rows[zero]}
        mismatches = [i for i in development_ids if base_rows.get(i, {}).get('status') != 'ok'
                      or zero_rows.get(i, {}).get('status') != 'ok'
                      or base_rows[i].get('score_logits') != zero_rows[i].get('score_logits')
                      or base_rows[i].get('progress') != zero_rows[i].get('progress')]
        if mismatches:
            raise ValueError(f'Incomplete or nonidentical development zero audit: {zero}')
        zero_audits[zero] = {'n_expected': len(development_ids), 'n_exact': len(development_ids)}
    effects = {}
    for c in recipes:
        candidate = summaries[c['name']]
        original = summaries.get(f'original_all_k{c["k"]}')
        if original is None:
            raise ValueError('Same-k original evidence is missing')
        effect = contrast(candidate, baseline, continuous)
        native_effect = contrast(candidate, native, continuous)
        original_effect = contrast(candidate, original, continuous)
        if not (effect.get('point_estimate_10pp_gate') and native_effect.get('point_estimate_10pp_gate')
                and original_effect.get('complete') and original_effect['mae_delta'] < 0
                and original_effect['accuracy_delta'] > 0):
            raise ValueError(f'Incomplete or nonpassing development condition: {c["name"]}')
        if continuous and c['name'] == case['primary']:
            if not all(candidate['overall']['mae'] < comparator['overall']['mae'] for comparator in [baseline, native]):
                raise ValueError('Primary five-bin MAE must improve against both baselines')
        effects[c['name']] = {'versus_baseline': effect, 'versus_native': native_effect, 'versus_original_same_k': original_effect}
    loss = 'continuous_ordinal_mae' if continuous else 'mae'
    originals = [name for name, summary in summaries.items() if re.fullmatch(r'original_all_k\d+', name) and summary['complete']]
    # This is one actual comparator, not an unattainable envelope combining k.
    best_original = min(originals, key=lambda name: (summaries[name]['overall'][loss], -summaries[name]['overall']['accuracy'], conditions[name]['k']))
    return cfg, branches, conditions, {
        **source, 'model': cfg['model'], 'protocol': cfg['protocol'], 'primary': case['primary'],
        'conditions': selected, 'tested_recipe_ks': tested, 'selected_ks': ks, 'development_effects': effects,
        'best_development_original': best_original,
        'original_selection_rule': 'Minimum complete development MAE, then maximum accuracy, then smaller k',
        'n_development': len(development_ids), 'zero_audits': zero_audits,
    }


def build_config(cfg, branches, conditions, evidence, out, confirmation_ids_path):
    result = copy.deepcopy(cfg)
    result.pop('score_branch_source', None)
    result.pop('score_branch_source_sha256', None)
    result.pop('screen_video_groups', None)
    chosen = {name: copy.deepcopy(conditions[name]) for name in evidence['conditions']}
    primary = chosen[evidence['primary']]
    required = {'baseline', 'native_generation_baseline', 'zero_preserve_k32', evidence['best_development_original']}
    required.update(f'original_all_k{k}' for k in evidence['selected_ks'])
    for recipe in chosen.values():
        required.update(recipe['source_branches'])
    new_branches = {}
    primary_zero = copy.deepcopy(branches[primary['source_branches'][1]])
    primary_zero.update(name='zero_primary', bias=0.)
    new_branches[primary_zero['name']] = primary_zero
    if primary.get('combination_type') == 'temporal_region_contrast':
        static_zero = copy.deepcopy(branches[primary['source_branches'][3]])
        static_zero.update(name='static_zero_primary', bias=0.)
        new_branches[static_zero['name']] = static_zero
    # Matched target/wrong/low controls at the frozen primary setting.
    for control in ['wrong', 'low_rank']:
        recipe = copy.deepcopy(primary)
        recipe['name'] = 'control_' + control + '_primary'
        recipe['region'] = control
        sources = []
        for name in primary['source_branches']:
            branch = branches[name]
            if not branch.get('k', 0):
                sources.append(name)
                continue
            new = copy.deepcopy(branch)
            new['name'] = 'confirmation_' + control + '_' + name
            if control == 'wrong':
                new['region'] = 'wrong'
            else:
                new['head_group'] = 'low'
            new_branches[new['name']] = new
            sources.append(new['name'])
        recipe['source_branches'] = sources
        chosen[recipe['name']] = recipe
    if primary.get('combination_type') == 'temporal_region_contrast':
        required.update(['static_baseline', 'static_zero_preserve_k32'])
        recipe = copy.deepcopy(primary)
        recipe.update(name='control_observed_only_primary', combination_type='region_contrast', source_branches=primary['source_branches'][:3])
        chosen[recipe['name']] = recipe
    if 'native_confidence_power' in primary:
        recipe = copy.deepcopy(primary)
        recipe.pop('native_confidence_power')
        recipe['name'] = 'control_uniform_strength_primary'
        chosen[recipe['name']] = recipe
    for tau in [2., 4., 8., 16.]:
        name = f'control_native_temperature_tau{tau:g}'
        chosen[name] = {'name': name, 'k': 0, 'contrast_weight': tau, 'combination_type': 'native_logit_temperature', 'source_branches': ['baseline']}
    for delta in [.25, .5, 1., 2., 4.]:
        name = f'control_native_kl_temperature_delta{delta:g}'
        chosen[name] = {'name': name, 'k': 0, 'contrast_weight': 1., 'target_kl': delta,
                        'max_contrast_weight': 64., 'combination_type': 'native_logit_temperature', 'source_branches': ['baseline']}
    selected_branches = [copy.deepcopy(branches[name]) for name in branches if name in required] + list(new_branches.values())
    if required - {b['name'] for b in selected_branches}:
        raise ValueError('Missing required baseline or original branch')
    result.update(output_dir=str(out), example_ids_file=str(confirmation_ids_path),
                  stage='frozen_independent_video_confirmation_v1', branch_conditions=selected_branches,
                  conditions=[{'name': b['name'], 'k': b.get('k', 0), 'source_branches': [b['name']]} for b in selected_branches] + list(chosen.values()))
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--selection', required=True)
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    selection = json.loads(pathlib.Path(args.selection).read_text())
    protocol_path = RESEARCH / 'confirmation_analysis_protocol_v1.json'
    protocol = json.loads(protocol_path.read_text())
    confirm_path = pathlib.Path(protocol['confirmation_ids_file'])
    confirm_ids = json.loads(confirm_path.read_text())
    if fingerprint(confirm_ids) != protocol['ids_sha256']:
        raise ValueError('Confirmation IDs changed')
    development_path = RESEARCH / 'development_v1/development_ids.json'
    if fingerprint(json.loads(development_path.read_text())) != protocol['development_ids_sha256']:
        raise ValueError('Development IDs changed')
    development_ids = json.loads(development_path.read_text())
    labels = {r['example_id']: r for r in read_rows(BASE / 'inputs/labels.jsonl')}
    if set(confirm_ids) & set(development_ids) or ({labels[i]['video_sha256'] for i in confirm_ids} & {labels[i]['video_sha256'] for i in development_ids}):
        raise ValueError('Development/confirmation overlap')
    ranking_videos = {r['video_sha256'] for r in read_rows(BASE / 'inputs/ranking.jsonl')}
    if ranking_videos & {labels[i]['video_sha256'] for i in confirm_ids + development_ids}:
        raise ValueError('Ranking videos overlap development or confirmation')
    cohort_ids = {r['example_id'] for r in read_rows(BASE / 'inputs/cohort.jsonl')}
    if not set(confirm_ids + development_ids) <= cohort_ids:
        raise ValueError('Frozen inference IDs must belong to the grounded cohort')
    validated = [validate_case(case, labels, development_ids) for case in selection['cases']]
    model_protocols = collections.defaultdict(set)
    for cfg, _, _, _ in validated:
        model_protocols[cfg['model']].add(cfg['protocol'])
    if len({(cfg['model'], cfg['protocol']) for cfg, _, _, _ in validated}) != len(validated):
        raise ValueError('Duplicate model/input cases')
    if sum(len(protocols) >= 3 for protocols in model_protocols.values()) < 3:
        raise ValueError('Launch gate unmet: need at least three models with three validated protocols each')
    out_root = RESEARCH / 'confirmation_v1'
    frozen = []
    for cfg, branches, conditions, evidence in validated:
        name = cfg['model'] + '_' + cfg['protocol']
        path = ROOT / f'mydata_bench/configs/v2_crossmodel/addbase_confirmation_v1_{name}.yaml'
        new = build_config(cfg, branches, conditions, evidence, out_root / name, confirm_path)
        frozen.append((path, new, evidence))
    print('Admission passed:', {model: sorted(protocols) for model, protocols in model_protocols.items()}, flush=True)
    if args.validate_only:
        print('Validation only; no confirmation artifacts written or inference launched')
        return
    if out_root.exists() or any(path.exists() for path, _, _ in frozen):
        raise ValueError('Confirmation output already exists; never overwrite or silently reselection')
    manifest = {'time': timestamp(), 'status': 'All final settings frozen before confirmation inference',
                'selection_sha256': fingerprint(selection), 'protocol_sha256': fingerprint(protocol),
                'analysis_protocol': protocol, 'cases': [], 'provenance': provenance({'purpose': 'confirmation_freeze_v1'}),
                'input_file_sha256': {name: hashlib.sha256((BASE / 'inputs' / name).read_bytes()).hexdigest()
                                     for name in ['cohort.jsonl', 'ranking.jsonl', 'labels.jsonl', 'manifest.json']},
                'ranking_development_confirmation_video_disjoint': True}
    for path, cfg, evidence in frozen:
        out = pathlib.Path(cfg['output_dir'])
        ranking = json.loads((pathlib.Path(evidence['folder']) / 'ranking.json').read_text())
        with path.open('x') as handle:
            yaml.safe_dump(cfg, handle, sort_keys=False)
        create_json(out / 'ranking.json', ranking)
        plan = {'time': timestamp(), 'config': cfg, 'config_sha256': fingerprint(cfg),
                'ranking_sha256': fingerprint(ranking), 'development_selection': evidence,
                'confirmation_outcomes_used_for_selection': False}
        create_json(out / 'prospective_plan.json', plan)
        manifest['cases'].append({**evidence, 'config_path': str(path), 'config_sha256': fingerprint(cfg),
                                  'ranking_sha256': fingerprint(ranking), 'output_dir': str(out)})
    create_json(out_root / 'frozen_manifest_v1.json', manifest)
    print(out_root / 'frozen_manifest_v1.json')


if __name__ == '__main__':
    main()
