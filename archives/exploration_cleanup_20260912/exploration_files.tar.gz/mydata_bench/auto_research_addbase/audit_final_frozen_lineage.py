"""Verify final frozen inputs, inference, recipes and saved score lineage."""
from .common import *
from .entropy_evaluation import source_folders


def main():
    final = RESEARCH / 'shared_entropy_evaluation_v1'
    manifest = json.loads((final / 'frozen_manifest_v1.json').read_text())
    original = json.loads((RESEARCH / 'confirmation_v1/frozen_manifest_v1.json').read_text())
    controls = json.loads((RESEARCH / 'shared_entropy_whole_controls_v1/frozen_protocol_v1.json').read_text())
    registry = json.loads((final / 'final_recipe_registry_v1.json').read_text())
    checks = []
    cache = {}

    def check(path, expected, kind='bytes'):
        path = pathlib.Path(path).resolve()
        if not path.is_relative_to(ROOT.resolve()):
            raise ValueError('Lineage audit must stay inside the target repository')
        key = (str(path), kind)
        if key not in cache:
            before = path.stat().st_size
            if kind == 'json':
                actual = fingerprint(json.loads(path.read_text()))
            else:
                h = hashlib.sha256()
                with path.open('rb') as f:
                    while block := f.read(2**20):
                        h.update(block)
                actual = h.hexdigest()
            if before != path.stat().st_size:
                raise ValueError('Input changed during audit: ' + str(path))
            cache[key] = actual
        actual = cache[key]
        checks.append({'path': str(path), 'hash_kind': kind, 'expected': expected,
                       'actual': actual, 'matches': expected == actual})
        if expected != actual:
            raise ValueError('Frozen lineage mismatch: ' + str(path))

    frozen = original['provenance']['source_sha256']
    inference = [n for n in frozen if n.startswith(('mydata_bench/meter_eval/', 'mydata_bench/top_eval/'))
                 or n.rsplit('/', 1)[-1] in {'score_branches.py','combine_scores.py','discrete_runtime.py',
                     'attention.py','native_confidence.py','kl_budget.py','common.py'}]
    for name in inference + ['mydata_bench/auto_research_addbase/' + n for n in ['metrics.py','paired_analysis.py','analyze_development.py']]:
        check(ROOT / name, frozen[name])
    for protocol in [manifest, controls]:
        for name, sha in protocol['source_sha256'].items():
            check(ROOT / 'mydata_bench/auto_research_addbase' / name, sha)
    for name, sha in original['input_file_sha256'].items():
        check(BASE / 'inputs' / name, sha)
    check(BASE / 'inputs/labels.jsonl', manifest['labels_sha256'])
    for partition, path in manifest['partitions'].items():
        check(path, manifest['partition_ids_sha256'][partition], 'json')
    check(manifest['full_ids_path'], manifest['full_ids_sha256'], 'json')
    for case in original['cases']:
        check(pathlib.Path(case['output_dir']) / 'config.json', case['config_sha256'], 'json')
        check(pathlib.Path(case['output_dir']) / 'ranking.json', case['ranking_sha256'], 'json')
    for case in manifest['cases']:
        check(pathlib.Path(case['output_dir']) / 'config.json', case['config_sha256'], 'json')
        check(pathlib.Path(case['output_dir']) / 'ranking.json', case['ranking_sha256'], 'json')
        check(case['development_scores_path'], case['development_scores_sha256'])
        for partition, folder in source_folders(case).items():
            check(folder / 'sweep.jsonl', case['parent_source_sha256'][partition])
        for supplement in case['supplements']:
            check(supplement['path'], supplement['sha256'], 'json')
    check(final / 'frozen_manifest_v1.json', controls['evaluation_manifest_sha256'], 'json')
    check(final / 'frozen_manifest_v1.json', registry['source_manifest_sha256'], 'json')
    for recipe in registry['recipes'].values():
        check(recipe['path'], recipe['sha256'])
    for sources in controls['sources_sha256'].values():
        for path, sha in sources.items():
            check(path, sha)
    summary = json.loads((final / 'summary_v1.json').read_text())
    check(final / 'frozen_manifest_v1.json', summary['manifest_sha256'], 'json')
    coverage = {}
    for name, path in summary['case_files'].items():
        case = json.loads(pathlib.Path(path).read_text())
        for partition in ['development', 'reused_validation', 'full_cohort']:
            assert case['partitions'][partition]['all_three_k_point_acceptance']
            assert case['partitions'][partition]['strict_development_selected_original_acceptance']
            assert case['partitions'][partition]['summaries'][case['primary']]['complete']
        coverage[name] = {'final_primary_complete': True,
                          'all_main_partitions_all_three_k_accepted': True,
                          'retained_control_inclusive_invalid_rows': case['generation_audit']['n_invalid_rows']}
    out = final / 'final_frozen_lineage_audit_v1.json'
    create_json(out, {'time': timestamp(), 'checks': checks, 'n_checks': len(checks),
                     'n_unique_file_hashes': len(cache), 'n_original_inference_files': len(inference),
                     'method_coverage_and_retained_control_errors': coverage,
                     'all_frozen_lineage_checks_passed': True,
                     'scope': 'Frozen neural/metric/postprocess source files, input and partition hashes, actual confirmation/remainder configs and rankings, development and parent sweep files, supplements, nine final recipe files and whole-control neural sources. No new neural execution or performance selection.',
                     'analysis_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    print(out, len(checks), 'checks passed')


if __name__ == '__main__':
    main()
