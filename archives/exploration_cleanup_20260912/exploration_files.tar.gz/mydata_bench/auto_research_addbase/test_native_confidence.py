import unittest
import numpy as np
from .native_confidence import native_completion_confidence,damping_factor
from .combine_scores import combine_logits


class NativeConfidenceTests(unittest.TestCase):
    def test_reward_bins_all_contribute(self):
        self.assertAlmostEqual(native_completion_confidence('qwen',{'score_logits':[0.]*5},{}),.5)
        self.assertGreater(native_completion_confidence('rr',{'score_logits':[0.,0.,0.,2.,0.]},{}),.5)
        self.assertEqual(native_completion_confidence('meter',{}, {'success_probability':.73}),.73)

    def test_gate_never_replaces_predictions(self):
        base=[-.5,.1,.3,.7,-.8];plus=[v+.2 for v in base];minus=[v-.2 for v in base]
        recipe={'contrast_weight':4.,'native_confidence_power':2.}
        np.testing.assert_allclose(combine_logits([base,plus,minus],recipe,1.),base)
        # Zero intervention is identical for every confidence, including 0.
        for confidence in [0.,.2,.8,1.]:
            np.testing.assert_array_equal(combine_logits([base,base,base],recipe,confidence),base)
        self.assertEqual(len(combine_logits([base,plus,minus],recipe,.5)),5)

    def test_damping_has_no_threshold(self):
        self.assertAlmostEqual(damping_factor(.8,2.),.04)
        self.assertGreater(damping_factor(.79,2.),damping_factor(.8,2.))
        with self.assertRaises(ValueError):damping_factor(-.1,1.)
        with self.assertRaises(ValueError):combine_logits([[0.]*5]*3,{'contrast_weight':4.,'native_confidence_power':1.})

    def test_temperature_control_preserves_bin_order_and_uniformity(self):
        z=[-1.,0.,3.,1.,2.]
        for tau in [2.,4.,8.,16.]:
            recipe={'contrast_weight':tau,'combination_type':'native_logit_temperature'}
            actual=combine_logits([z],recipe)
            self.assertEqual(int(np.argmax(actual)),2)
            np.testing.assert_array_equal(combine_logits([[0.]*10],recipe),[0.]*10)


if __name__=='__main__':unittest.main()
