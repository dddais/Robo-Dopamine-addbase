# Robust checkpoint 2026-09-10T13:28:02.865479+08:00

Goal ACTIVE / UNACHIEVED. This turn made PROGRESS and verified live waits. No blocked condition. Continue full original scope; do not mark complete/blocked. Full prior constraints from123415/120611 checkpoints persist.

## Workspace and execution
Only /mnt/public1/dais/workspace/Robo-Dopamine-addbase. Every exec explicit cwd there, login:false. Python /home/dais/miniconda3/envs/robo-dopamine/bin/python. No git, no other local repos, no subagents, no permission questions. Preserve every old data/result/failure. Never edit frozen sources/configs. F1–F6 complete old234 gates0 each; do not rerun unchanged. 493 reused selection afterF6; old846 exposed; reserved2831 unopened. External mixed-grade gains cannot replace original10pp scope.

## Authoritative current state
{
  "time": "2026-09-10T13:28:02.865479+08:00",
  "goal": "ACTIVE/UNACHIEVED",
  "processes": {
    "f7_evaluation": {
      "pid": 2567628,
      "live": true
    },
    "f7_full_old": {
      "pid": 2568642,
      "live": true
    },
    "f7_confirmation": {
      "pid": 2571353,
      "live": true
    },
    "f8_fit": {
      "pid": 2585065,
      "live": true
    },
    "f8_evaluation": {
      "pid": 2597350,
      "live": true
    },
    "f8_full_old": {
      "pid": 2597351,
      "live": true
    },
    "f8_complete_fit_mechanism_audit": {
      "pid": 2598537,
      "live": true
    }
  },
  "workers": {
    "f7_evaluation_gpu0_events_v1.jsonl": {
      "time": "2026-09-10T05:27:42.172368+00:00",
      "event": "launch",
      "case": "qwen_text_image",
      "module": "all_query_reward_gradient_validation",
      "stage": "validation",
      "pid": 2600889,
      "command": [
        "/home/dais/miniconda3/envs/robo-dopamine/bin/python",
        "-u",
        "-m",
        "mydata_bench.auto_research_addbase.all_query_reward_gradient_validation",
        "--config",
        "/mnt/public1/dais/workspace/Robo-Dopamine-addbase/mydata_bench/configs/v2_crossmodel/addbase_robust_all_query_reward_gradient_validation_v1_qwen_text_image.yaml",
        "--stage",
        "validation"
      ],
      "live": true
    },
    "f7_evaluation_gpu3_events_v1.jsonl": {
      "time": "2026-09-10T05:26:28.581883+00:00",
      "event": "launch",
      "case": "meter_text_video",
      "module": "all_query_reward_gradient_validation",
      "stage": "validation",
      "pid": 2600720,
      "command": [
        "/home/dais/miniconda3/envs/robo-dopamine/bin/python",
        "-u",
        "-m",
        "mydata_bench.auto_research_addbase.all_query_reward_gradient_validation",
        "--config",
        "/mnt/public1/dais/workspace/Robo-Dopamine-addbase/mydata_bench/configs/v2_crossmodel/addbase_robust_all_query_reward_gradient_validation_v1_meter_text_video.yaml",
        "--stage",
        "validation"
      ],
      "live": true
    },
    "f8_fit_gpu2_events_v1.jsonl": {
      "time": "2026-09-10T05:26:07.202692+00:00",
      "event": "launch",
      "case": "fit_rr_image_text",
      "pid": 2600581,
      "command": [
        "/home/dais/miniconda3/envs/robo-dopamine/bin/python",
        "-u",
        "-m",
        "mydata_bench.auto_research_addbase.ordinal_reward_gradient_fit",
        "--config",
        "/mnt/public1/dais/workspace/Robo-Dopamine-addbase/mydata_bench/configs/v2_crossmodel/addbase_robust_ordinal_reward_gradient_fit_v1_rr_image_text.yaml"
      ],
      "live": true
    }
  },
  "f7_completed": {
    "development": [
      "qwen_image_text",
      "qwen_interleaved",
      "qwen_text_video",
      "qwen_video_text"
    ],
    "validation": [
      "qwen_image_text",
      "qwen_interleaved",
      "qwen_text_video",
      "qwen_video_text"
    ]
  },
  "f8_fit_completed": [
    "qwen_image_text",
    "qwen_interleaved",
    "qwen_text_image",
    "qwen_text_video",
    "qwen_video_text",
    "rr_text_image",
    "rr_text_video",
    "rr_video_text"
  ],
  "reserved_claim_exists": false,
  "f7_confirmation_policy_v1.json": {
    "sha256": "7fd403ac8bf8f251c35ca83944e6d750ad2e8be75e599a53d691b2ed14ab7611",
    "sources": 72,
    "unchanged": true
  },
  "f8_evaluation_policy_v1.json": {
    "sha256": "f356cc56cb2df3904d3516119690d64707b44153930ead7cddd80159c1f7c390",
    "sources": 83,
    "unchanged": true
  }
}

## F7 (frozen) advancement
All15 fits complete04:51:22UTC, failures[]. CPU complete-fit audit also complete04:51:51, output R/f7_complete_fit_mechanism_audit_v1.json: all15 native logits/CE exactF6/F7,1253 measured gradients/case changed,689noROI kept. Crossprotocol same-sign/positive-worst: Qwen252/111,Meter338/135,RR241/58. RR58 insufficient k64 sharedpositiveheads; no common-head method chosen. Doc CODE/F7_ALL_FIT_AUDIT_20260910.md.
Evaluation auto froze15+15 configs and started GPU0/3. Do not manually freeze or duplicatequeue. Counts/liveIDs above. No current F7 reward metric analysis read; all15 outputs required. Completed qwen_interleaved493 has2native_generation_baseline errors: model said'5', parser requires'ANSWER: <1-5>'. All other complete-case errors inspected at05:22 were wrong-region geometry only. Preserve those2 failures; thatcase cannot meet strict complete gate; no reparse/rerun frozen outputs. Main othercases continue.
F7full846/confirmation conditionalqueues remainlive. Sharedreservedclaim absent.
Finite-bias F7training diagnostics fully complete; unchanged from123415: CODE/F7_FINITE_STEP_FIT_RESULT_20260910.md, QwenCEdown butaccuracy−.1545pp/MAE+.071061. MeterCEdown/accuracy+5.6128pp/MAE−.080309. Both all1942/446, descriptivefit only.

## F8 now FIT + EVALUATION/FULL846 conditional queues frozen
New fitting files launched12:34Shanghai; all3real synthetic grade3 engineeringpassed; 15fitconfigs frozen. Only objective changes fromF7 to cumulative ordinal logloss on ALLnativeCDFboundaries. Native5grades, Meteroriginal10bininterpolation; b1,k32/48/64,primary48,allqueries,first8excluded,groupabs(mu)-1.96SE,-sign; no inferencepostprocess. Sourcefiles/queueplan R/f8_fit_queue_plan_v1.json.
Policy R/f8_evaluation_policy_v1.json SHA f356cc56cb2df3904d3516119690d64707b44153930ead7cddd80159c1f7c390, freezes83 sources includingallF8fit/eval/full846 deps. DO NOTEDIT those83. New files:
- freeze_ordinal_reward_gradient_policy.py (already run successfully; never rerun)
- freeze_ordinal_reward_gradient_development.py + validation.py
- analyze_ordinal_reward_gradient_development.py + validation.py
- f8_reference_comparison.py
- ordinal_reward_gradient_evaluation_queue.py
- freeze_ordinal_reward_gradient_full_old.py / analyze_ordinal_reward_gradient_full_old.py / ordinal_reward_gradient_full_old_queue.py
Shared inference runners/runtime are unchanged F7 all_query_reward_gradient_development/validation/full_old. Config paths/output dirs identifyF8.
EvaluationqueuePID2597350 waitsall15fit; then freezesdev+493beforeanyinference; GPU1/2. SamegatesF7, addsfixedF7CEprimarycontrol via frozenactualF7configs. No F8 labeljoin until all15 F8 AND fixedF7 comparisons have full outputs. EvaluatedF7comparators descriptive, not newacceptancegate.
Full846queuePID2597351 waitsF8jointeligibility (same>=3inputs eachmodel inbothold234/493), thenalleligiblecases846GPU1/2 andfullscopeanalysis. No F8reservedpipeline implemented/scheduled. F7priority persists; mustfreeze newfinalF8protocolif fullscopepassesANDteststillunopened; if F7testopens/failsneed freshindependenttest.
Tests:2newlossCPU passedearlier. 3F8evaltests passed now: incomplete493blockslabelread, F7fixedcomparisonfailurespreserved/mismatchblocked, modelscopecannot bepatchedwithothermodels. Basetemp R/f8_evaluation_testing_v1 NEVERREUSE. PreviousbasetempsR/f8_ordinal_loss_testing_v1,R/f7_finite_bias_diagnostic_testing_v1 alsoNEVERREUSE. 10evalmodulesparse/import andinvalidoutputeffectchecked. No pending exec sessions.

## Extra frozen complete-fit CPU observer
New CODE/audit_ordinal_fit_complete.py nowfrozenatlaunchSHA inR/f8_complete_fit_mechanism_audit_launch_v1.json. PID2598537 (python-c runpy gate thenmain; cmdlinehasmodulename). Waits15F8fits, verifieshashes,F7/F8samefitcfg/native/logits/tracking, recomputesallordinalfitlossCPUtolatol=rtol1e-5, keeps689noROI, reportsheadturnover. No validation/test performance.
Actualcompletedtests onqwen_text_video andvideo_text: all1942/446,1253zeroexact/gradarraysdifferent,689noROI; CPUmaxlossdiff5.722e-6/4.768e-6. R/f8_first_complete_fit_loss_and_zero_audit_v1.json and second...json. Firsttestbeforeextra duplicate/configguards, then secondtestpassedfinalsourcebeforelaunch. Fullobserver expectedR/f8_complete_fit_mechanism_audit_v1.json. Do notduplicate/restart.

## New literature and design audit
CODE/F8_ORDINAL_THEORY_AND_SOURCE_20260910.md: arxiv1901.07884 officialv7PDF9pages downloaded/extracted, relevantsections3.2.2,4.3,supplementread. Corpus R/ordinal_loss_literature_verification_v1. F8notCORALarchitecture; CDFnaturallymonotone. ProperCDF/CEshareidealdistributionoptimum;differentlocalgeometrymayhelp constrainedsparseintervention,butnoMAE/argmaxguarantee. Paper4.3saysvalchosenmodelthenbesttestover200epochs; textualinconsistency notedwithoutaccusing actualtestselectionorclaimingfullyreviewedcode. Not usedasindependentproof.
Mathillustrationtruegrade3,nearprob[.01,.4,.18,.4,.01]vsfar[.4,.01,.18,.01,.4]:sameCE1.714798,ordinalloss.268842vs.519229, notexperiment.
New CODE/audit_fit_instruction_contrasts.py + R/fit_instruction_contrast_support_audit_v1.json;CODE/FIT_INSTRUCTION_CONTRAST_SUPPORT_20260910.md. FIT1334visualgroups/300samevideo-differenttask-andgradegroups/908uniquerows/1038dependentpairs(519bothgrounded),185grade1vs5. Gaps1/2/3/4 counts347/335/171/185. Samevideoanddisplayedframesignaturegroupsidentical. Old846299videos/265informativegroups/808rows/5431vs5pairs;381differentinstructionbutsamegradepairs. Rejectsimple'fitcontainsnocounterfactualpairs' hypothesis. SupportsfuturepairwiselossideaONLY; noF9implemented/selected. Initialinlineauditguessedoldlabelkey'label'andfailedKeyErrorbeforeoutputs; inspectedactual'reward',corrected innewsource; disclosureinJSON. Nothingoverwritten.

## Next useful work
1 Revalidate currentF7/F8workers, allqueuehandles anderrors; keep actualterminalstates distinctfromstalePIDs.
2 Continue F7 all15 evaluation, no partiallabeljoinedmetricclaims. F8remainingfits continueGPU2; evaluation/full846alreadyautomatic andfrozen. MonitorfullCPUobserver.
3 Iftime permits study independenttraining-only mechanism or literature; do not keep spawningcandidatevariantsbasedonpartialvalidation. Pairwiseidea hasfitdatasupport butnotimplemented.
4 Need finalF8confirmation code/policy only prospectively and respectF7once-onlyclaimpriority; never reuse openedtest asfresh. Do not treat reservedexternalresult as substitute for old84610pp.
5 Allfinalgoals/docsexplicit requirementaudit beforecomplete. CurrentreportsCODE/ROBUST_PROGRESS_20260910T132802.md, rootplanandmethoddocs appended. Nextcheckpointshould preserve allthisnewstate.

CODE=mydata_bench/auto_research_addbase;R=results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1.
