"""Prospectively test k68 between the complete k64/k72 development points."""
import argparse, subprocess, time
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, required=True)
    args = parser.parse_args()
    folder = RESEARCH / 'score_temporal_development_full_v1/qwen_video_text'
    config = ROOT / 'mydata_bench/configs/v2_crossmodel/addbase_temporal_full_development_v1_qwen_video_text.yaml'
    assert (folder / 'combination_events.jsonl').exists()
    path = folder / 'k68_temporal_midpoint_supplement_v1.json'
    if not path.exists():
        prefix = 'target_all_frames_b3_k68'
        branches = [{'name': 'original_all_k68', 'k': 68, 'kind': 'bias', 'bias': 6., 'scope': 'all_frames'}]
        for static in [False, True]:
            for sign, bias in [('plus', 3.), ('minus', -3.)]:
                branches.append({'name': ('static_' if static else '') + prefix + '_' + sign,
                                 'k': 68, 'kind': 'visual_preserve', 'bias': bias, 'scope': 'all_frames',
                                 'region': 'target', 'head_group': 'high',
                                 'media_condition': 'static_first' if static else 'observed'})
        conditions = [{'name': c['name'], 'k': 68, 'source_branches': [c['name']]} for c in branches]
        for temporal in [False, True]:
            sources = ['baseline', prefix + '_plus', prefix + '_minus']
            if temporal:
                sources += ['static_' + prefix + '_plus', 'static_' + prefix + '_minus']
            common = {'k': 68, 'scope': 'all_frames', 'region': 'target',
                      'source_branches': sources, 'contrast_weight': 1.,
                      'combination_type': 'temporal_region_contrast' if temporal else 'region_contrast'}
            label = 'temporal_' if temporal else ''
            conditions.append({**common, 'name': f'contrast_target_{label}all_frames_b3_k68_lambda1'})
            for delta in [.25, .5]:
                conditions.append({**common, 'name': f'contrast_target_midpoint_kl_{label}all_frames_b3_k68_delta{delta:g}',
                                   'target_kl': delta, 'max_contrast_weight': 64.})
        supplement = {'time': timestamp(), 'branch_conditions': branches, 'conditions': conditions,
                      'reason': 'Complete development234 temporal all-frame lambda1 improved all four metrics at k64 and k72. Freeze the midpoint k68 before computing it; retain native/zero controls from the same folder and add same-k original and observed-only controls. This adapts within development and is not independent confirmation.',
                      'primary_recipe': 'temporal_region_contrast, all_frames, b3, lambda1',
                      'tested_interval': [64, 68, 72], 'confirmation_metrics_used': False,
                      'existing_branch_sha256': hashlib.sha256((folder / 'score_branches.jsonl').read_bytes()).hexdigest()}
        create_json(path, supplement)
        append(folder / 'analysis_supplements.jsonl', {'time': timestamp(), 'path': str(path), 'sha256': fingerprint(supplement)})
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(args.gpu), OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
    events = folder / 'k68_midpoint_queue_events_v1.jsonl'
    while int(subprocess.check_output(['nvidia-smi', f'--id={args.gpu}', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip()) < 34000:
        append(events, {'time': timestamp(), 'event': 'waiting_free_memory'})
        time.sleep(20)
    commands = [
        ['score_branches', '--config', str(config), '--supplement', str(path)],
        ['combine_scores', '--folder', str(folder), '--supplement', str(path)],
    ]
    for command in commands:
        full = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.' + command[0]] + command[1:]
        append(events, {'time': timestamp(), 'event': 'launch', 'command': full})
        with (folder / 'k68_midpoint_v1.log').open('a') as log:
            child = subprocess.Popen(full, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
            code = child.wait()
        append(events, {'time': timestamp(), 'event': 'exit', 'pid': child.pid, 'returncode': code})
        if code:
            raise RuntimeError('Midpoint supplement failed; inspect raw outputs before resuming')
    print('Qwen temporal k68 midpoint complete', flush=True)


if __name__ == '__main__':
    main()
