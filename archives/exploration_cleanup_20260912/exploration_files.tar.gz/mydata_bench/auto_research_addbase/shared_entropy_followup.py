"""Shared RR entropy-exponent selection; prior frozen versions stay intact."""
import argparse
import math
from .common import *

OUTPUT = RESEARCH / 'shared_entropy_evaluation_v1'
CONTROL_OUTPUT = RESEARCH / 'shared_entropy_whole_controls_v1'
SELECTION = RESEARCH / 'shared_entropy_development_v1'


def prepare():
    parent_path = RESEARCH / 'entropy_evidence_evaluation_v1/frozen_manifest_v1.json'
    parent = json.loads(parent_path.read_text())
    sources = {name: RESEARCH / 'entropy_evidence_development_v1' / name / 'development_analysis_v1.json'
               for name in ['rr_image_text', 'rr_text_image', 'rr_text_video']}
    create_json(SELECTION / 'prospective_plan_v1.json', {
        'time': timestamp(), 'parent_manifest_path': str(parent_path), 'parent_manifest_sha256': fingerprint(parent),
        'development_sources': {name: str(path) for name, path in sources.items()},
        'development_sources_sha256': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in sources.items()},
        'shared_beta_options': [0., .5, 1., 2.],
        'hypothesis': 'The RR checkpoint uses the same five-bin readout across input protocols. Sharing its entropy exponent regularizes input-specific selection while allowing protocol-specific evidence amplitude and original anchoring. It can prevent one protocol choosing a large unmodulated tilt solely for development MAE. This is a structural constraint, not a guarantee of improved validation.',
        'selection': 'For each common beta, retain only already eligible development settings for each of the three RR protocols. Within each protocol choose the largest minimum_required_margin; ties use the prior complexity ordering. A beta is jointly eligible only if all three protocols have an eligible setting. Choose the beta maximizing the weakest selected protocol margin; ties prefer smaller beta. Keep all six Meter/Qwen settings, every original primary and k neighborhood unchanged. Save all shared-beta alternatives.',
        'boundary': 'The earlier entropy version and its RR text_video failure remain unchanged. This shared-parameter rule is proposed after its reused498/full846 outcomes were inspected; hence all follow-up outcomes remain exploratory reused-data evidence. Only development234 summaries are read by selection. No later outcome of the newly selected setting is used to revise this version.',
        'source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    print(SELECTION / 'prospective_plan_v1.json')


def select():
    plan = json.loads((SELECTION / 'prospective_plan_v1.json').read_text())
    if hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest() != plan['source_sha256']:
        raise ValueError('Frozen shared-parameter selector changed')
    sources = {}
    for name, path in plan['development_sources'].items():
        blob = pathlib.Path(path).read_bytes()
        if hashlib.sha256(blob).hexdigest() != plan['development_sources_sha256'][name]:
            raise ValueError('Development summaries changed')
        sources[name] = json.loads(blob)
    def order(candidate):
        p = candidate['parameters']
        return (-round(candidate['minimum_required_margin'], 12),
                sum([p['scale'] != 1, p['beta'] != 0, p['rho'] != 0]), p['beta'], abs(math.log2(p['scale'])), p['rho'])
    candidates = []
    for beta in plan['shared_beta_options']:
        choices = {}
        for name, value in sources.items():
            eligible = sorted([c for c in value['candidates'] if c['eligible'] and c['parameters']['beta'] == beta], key=order)
            choices[name] = {'parameters': eligible[0]['parameters'], 'minimum_required_margin': eligible[0]['minimum_required_margin']} if eligible else None
        eligible = all(choices.values())
        candidates.append({'beta': beta, 'eligible': eligible, 'choices': choices,
                           'minimum_protocol_margin': min(c['minimum_required_margin'] for c in choices.values()) if eligible else None})
    eligible = sorted([c for c in candidates if c['eligible']], key=lambda c: (-round(c['minimum_protocol_margin'], 12), c['beta']))
    selected = eligible[0] if eligible else None
    create_json(SELECTION / 'joint_selection_v1.json', {
        'time': timestamp(), 'plan_sha256': fingerprint(plan), 'candidates': candidates,
        'selected': selected, 'boundary': plan['boundary']})
    print(json.dumps({'candidates': candidates, 'selected': selected}, ensure_ascii=False), flush=True)


def freeze():
    plan = json.loads((SELECTION / 'prospective_plan_v1.json').read_text())
    selection = json.loads((SELECTION / 'joint_selection_v1.json').read_text())
    if fingerprint(plan) != selection['plan_sha256'] or selection['selected'] is None:
        raise ValueError('No unchanged eligible shared selection')
    parent = json.loads(pathlib.Path(plan['parent_manifest_path']).read_text())
    if fingerprint(parent) != plan['parent_manifest_sha256']:
        raise ValueError('Parent manifest changed')
    cases = []
    for case in parent['cases']:
        name = case['model'] + '_' + case['protocol']
        parameters = selection['selected']['choices'][name]['parameters'] if case['model'] == 'rr' else case['parameters']
        cases.append({**case, 'parameters': parameters})
    create_json(OUTPUT / 'frozen_manifest_v1.json', {
        **parent, 'time': timestamp(), 'method_family': 'shared_entropy_scaled_attention_evidence',
        'cases': cases, 'development_plan_sha256': fingerprint(plan), 'development_selection_sha256': fingerprint(selection),
        'parent_evaluation_manifest_sha256': fingerprint(parent), 'shared_rr_beta': selection['selected']['beta'],
        'boundary': plan['boundary'], 'source_sha256': {**parent['source_sha256'],
            'shared_entropy_followup.py': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()},
        'execution_note': 'Reuse unchanged entropy_evaluation.run with OUTPUT set to this new immutable result root. This changes neither inference nor metrics and does not rewrite any preceding frozen manifest or result.'})
    print(OUTPUT / 'frozen_manifest_v1.json')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'select', 'freeze', 'evaluate', 'prepare-controls', 'controls'])
    args = parser.parse_args()
    if args.action == 'prepare': prepare()
    elif args.action == 'select': select()
    elif args.action == 'freeze': freeze()
    elif args.action == 'evaluate':
        from . import entropy_evaluation
        entropy_evaluation.OUTPUT = OUTPUT
        entropy_evaluation.run()
    else:
        from . import entropy_whole_controls
        entropy_whole_controls.OUTPUT = OUTPUT
        entropy_whole_controls.CONTROL_ROOT = CONTROL_OUTPUT
        entropy_whole_controls.prepare() if args.action == 'prepare-controls' else entropy_whole_controls.run()


if __name__ == '__main__': main()
