"""Expand a prospectively screened temporal-region mechanism on development234."""
import argparse,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--protocol',required=True);p.add_argument('--scope',default='all_frames');p.add_argument('--reason',required=True);a=p.parse_args()
    screen=RESEARCH/f'score_temporal_development_v1/{a.model}_{a.protocol}';out=RESEARCH/f'score_temporal_development_full_v1/{a.model}_{a.protocol}'
    cfg=json.loads((screen/'config.json').read_text());ks=[24,32,40,48,56,64,72]
    branches=[{'name':'baseline','k':0},{'name':'native_generation_baseline','k':0,'kind':'native_generation'},
              {'name':'zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame'},
              {'name':'static_baseline','k':0,'media_condition':'static_first'},
              {'name':'static_zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame','media_condition':'static_first'}]
    recipes=[]
    for k in ks:
        branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
        for control in (['target','wrong','low_rank'] if k in [32,64] else ['target']):
            prefix=f'{control}_{a.scope}_b3_k{k}'
            for static in [False,True]:
                for sign,bias in [('plus',3.),('minus',-3.)]:branches.append({'name':('static_' if static else '')+prefix+'_'+sign,'k':k,'kind':'visual_preserve','bias':bias,'scope':a.scope,'region':'wrong' if control=='wrong' else 'target','head_group':'low' if control=='low_rank' else 'high','media_condition':'static_first' if static else 'observed'})
            for weight in [1.,2.,3.,4.]:
                source=['baseline',prefix+'_plus',prefix+'_minus']
                recipes.append({'name':f'contrast_{prefix}_lambda{weight:g}','k':k,'contrast_weight':weight,'scope':a.scope,'region':control,'source_branches':source})
                recipes.append({'name':f'contrast_{control}_temporal_{a.scope}_b3_k{k}_lambda{weight:g}','k':k,'contrast_weight':weight,'scope':a.scope,'region':control,'combination_type':'temporal_region_contrast','source_branches':source+['static_'+prefix+'_plus','static_'+prefix+'_minus']})
    for weight in [1.,2.,4.]:recipes.append({'name':f'contrast_vcd_static_first_lambda{weight:g}','k':0,'contrast_weight':weight,'combination_type':'visual_contrast','source_branches':['baseline','static_baseline']})
    cfg.update(output_dir=str(out),example_ids_file=str(RESEARCH/'development_v1/development_ids.json'),stage='prospectively_frozen_full_temporal_development',branch_conditions=branches,conditions=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes)
    path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_temporal_full_development_v1_{a.model}_{a.protocol}.yaml'
    with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
    create_json(out/'ranking.json',json.loads((screen/'ranking.json').read_text()))
    ids=set(json.loads(pathlib.Path(cfg['example_ids_file']).read_text()));expected={c['name']:c for c in branches};selected={};reuse=[];conflicts=[]
    defaults={'kind':None,'k':0,'scope':'last_frame','region':'target','head_group':'high','media_condition':'observed','query_scope':'all','bias':3.}
    def equivalent(x,y):return all(x.get(k,v)==y.get(k,v) for k,v in defaults.items())
    for source in [RESEARCH/f'score_development_full_v1/{a.model}_{a.protocol}/score_branches.jsonl',screen/'score_branches.jsonl']:
        if not source.exists():continue
        blob=source.read_bytes();digest=hashlib.sha256(blob).hexdigest();count=0
        for line in blob.decode().splitlines():
            r=json.loads(line);key=(r['example_id'],r['condition'])
            if key[0] not in ids or key[1] not in expected or not equivalent(r.get('condition_config',{}),expected[key[1]]):continue
            if key in selected:
                if r.get('score_logits')!=selected[key].get('score_logits') or r.get('status')!=selected[key].get('status'):conflicts.append({'example_id':key[0],'condition':key[1],'lower_priority_source':str(source)})
                continue
            selected[key]={**r,'reused_from':str(source),'reused_source_sha256':digest,'reuse_time':timestamp()};count+=1
        reuse.append({'source':str(source),'sha256':digest,'reused_rows':count})
    for r in selected.values():append(out/'score_branches.jsonl',r)
    create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':a.reason,'config':cfg,'config_sha256':fingerprint(cfg),'reuse':reuse,'duplicate_source_differences':conflicts,'priority':'Existing full-development observed scores take precedence over screen duplicates. No original rows changed.','confirmation_metrics_used':False})
    print(path,'branches',len(branches),'readouts',len(cfg['conditions']),'reused',len(selected),'duplicate differences',len(conflicts))


if __name__=='__main__':main()
