"""Reuse frozen F1 clean branches; run only new noisy branches for F2."""
import json
import pathlib
import torch
from . import robust_runner
from .robust_runner import FrameTransportRuntime, digest
from .common import create_json, read_rows
from .frame_transport_vcd import diffusion_corruption, sample_seed, contrast_logits
from .score_branches import score_readout


class FixedVCDRuntime(FrameTransportRuntime):
    def __init__(self, config):
        source = pathlib.Path(config['clean_source_dir'])
        done = json.loads((source / 'development/completion_v1.json').read_text())
        prediction_path = source / 'development/predictions.jsonl'
        if digest(prediction_path) != done['predictions_sha256']:
            raise ValueError('F1 clean dependency changed')
        source_config = json.loads((source / 'development/config.json').read_text())
        for key in ['model', 'model_path', 'processor_path', 'protocol', 'input_sha256', 'ranking_sha256', 'example_ids_file']:
            if source_config.get(key) != config.get(key):
                raise ValueError('Incompatible clean dependency: ' + key)
        records = list(read_rows(prediction_path))
        self.clean = {(r['example_id'], r['condition']): r for r in records}
        if len(self.clean) != len(records):
            raise ValueError('Duplicate clean records')
        self.engineering_ids = set(json.loads(pathlib.Path(config['engineering_ids_file']).read_text()))
        self.verified = set()
        lineage = dict(clean_path=str(prediction_path), clean_sha256=digest(prediction_path),
                       clean_config_sha256=digest(source / 'development/config.json'),
                       cached_rows=len(records), no_labels_accessed=True)
        dest = pathlib.Path(config['output_dir']) / 'clean_cache_lineage_v1.json'
        if dest.exists():
            if json.loads(dest.read_text()) != lineage:
                raise ValueError('Clean lineage changed between stages')
        else:
            create_json(dest, lineage)
        super().__init__(config)

    def prepare(self, sample, media_condition='observed'):
        clean = super().prepare(sample, media_condition)
        noisy = {**clean, 'inputs': dict(clean['inputs'])}
        seeds = {}
        for key in ['pixel_values', 'pixel_values_videos']:
            if key in noisy['inputs']:
                seeds[key] = sample_seed(sample['video_sha256'], self.config['protocol'], key)
                noisy['inputs'][key] = diffusion_corruption(noisy['inputs'][key], seeds[key])
        if not seeds:
            raise ValueError('No pixel tensor to corrupt')
        clean['f2_noisy_prepared'] = noisy
        clean['f2_seeds'] = seeds
        return clean

    def predict(self, sample, prepared, condition, heads):
        source_name = condition.get('clean_source_condition', condition['name'])
        clean = self.clean[(sample['example_id'], source_name)]
        original_condition = clean['condition_config']
        if clean['status'] != 'ok':
            raise ValueError('Preserved clean branch failure: ' + clean.get('error', 'unknown'))
        # Recompute the predeclared engineering examples in both stages. This
        # verifies that reusing F1 is equivalent to this actual loaded runtime.
        key = (sample['example_id'], source_name)
        if sample['example_id'] in self.engineering_ids and key not in self.verified:
            duplicate = super().predict(sample, prepared, original_condition, heads)
            if any(duplicate.get(field) != clean.get(field) for field in ['score_logits', 'progress', 'native_prediction']):
                raise ValueError('Clean cached-vs-recomputed branch mismatch')
            self.verified.add(key)
        payload = {k: v for k, v in clean.items() if k not in ['time', 'example_id', 'video_sha256', 'condition', 'condition_config', 'status', 'elapsed_seconds']}
        if not condition.get('vcd_weight', 0.):
            return payload
        corrupted = super().predict(sample, prepared['f2_noisy_prepared'], original_condition, heads)
        logits = contrast_logits(clean['score_logits'], corrupted['score_logits'], 1.)
        payload.update(score_logits=logits, **score_readout(logits, self.config['model']))
        for field in ['official_whole_sequence_progress', 'total_probability_of_five_native_choices', 'unrestricted_next_token_id']:
            if field in payload:
                payload['clean_' + field] = payload.pop(field)
        payload.update(clean_score_logits=clean['score_logits'], corrupted_score_logits=corrupted['score_logits'],
                       corruption_seeds=prepared['f2_seeds'], diffusion_step=500, vcd_weight=1.,
                       hook_diagnostics=corrupted['hook_diagnostics'],
                       engine='frame_transport_fixed_vcd_v1',
                       output_score_adjustment='2*z_clean-z_corrupted over all native bins')
        return payload


if __name__ == '__main__':
    # Explicit runtime adapter; the shared runner file is not modified.
    robust_runner.FrameTransportRuntime = FixedVCDRuntime
    robust_runner.main()
