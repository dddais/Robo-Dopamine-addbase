"""Retrieve public primary sources; never upload local research content."""
import concurrent.futures, datetime, hashlib, json, pathlib, re, urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=ROOT/'results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260908/references'
IDS=['2603.02115','2603.28730','2311.02262','2407.21771','2506.14766','2605.04641','2606.14703','2607.17994','2604.09364','2608.17095','2608.03711','2503.06287','2606.09749','1905.09418','2311.16922','2403.14588']
def fetch(a):
    op=urllib.request.build_opener(urllib.request.ProxyHandler({'https':'http://127.0.0.1:7890','http':'http://127.0.0.1:7890'}))
    row={'arxiv_id':a,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'urls':[]}
    for kind,url in [('abs',f'https://arxiv.org/abs/{a}'),('html',f'https://arxiv.org/html/{a}')]:
        dst=OUT/f'{a}_{kind}.html'
        try:
            if dst.exists(): blob=dst.read_bytes()
            else:
                with op.open(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (research source verification)'}),timeout=45) as r: blob=r.read()
                with dst.open('xb') as f:f.write(blob)
            text=blob.decode('utf-8','replace')
            title=re.search(r'<meta\s+name="citation_title"\s+content="([^"]+)"',text)
            row['urls'].append({'url':url,'status':'retrieved','sha256':hashlib.sha256(blob).hexdigest(),'bytes':len(blob),'title':title.group(1) if title else None})
            if kind=='abs':
                block=re.search(r'<blockquote class="abstract[^>]*>(.*?)</blockquote>',text,re.S)
                row['abstract']=re.sub('<[^>]+>',' ',block.group(1)).strip() if block else None
        except Exception as e: row['urls'].append({'url':url,'status':'unverified','error':repr(e)})
    print(json.dumps(row,ensure_ascii=False),flush=True)
    return row
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for row in pool.map(fetch,IDS):
            with (OUT/'source_verification.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
