# Robust research checkpoint 2026-09-10T11:26:00.165218+08:00

Goal remains ACTIVE, UNACHIEVED. Continue until original目标3 genuinely passes and document complete evidence. Latest user asked whether earlier method is cheating; answered with an explicit critique and explanation, did not cancel original auto research. Do not mark goal complete/blocked.

## Constraints

- Target only `/mnt/public1/dais/workspace/Robo-Dopamine-addbase` (logical `/home/dais/workspace/Robo-Dopamine-addbase`); each exec explicit cwd here, login:false.
- No git, no other local code repositories, no subagents, no permission questions. Preserve all old data/results/failures. Never edit frozen sources/configs.
- Python `/home/dais/miniconda3/envs/robo-dopamine/bin/python`; SAM3 other configured env. Foreign GPU work exists; do not stop or inspect its code.
- Original scope: ≥3/4models, each≥3/5inputs, common tested k neighborhood, MAE down, suc/fail up, total≥+10pp and original attention improvement. Current robust rules also both Meter thresholds and stronger originals. External mixed grades never replace original dataset goal.

## Saved material

CODE=`mydata_bench/auto_research_addbase`
R=`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1`
Prior checkpoints1056 and user-provided handoff preserve F1–F6 and training/test audits.
New integrity explanation `CODE/METHOD_INTEGRITY_EXPLANATION_20260910T111808.md`: plain Chinese old vsF7, explicit old confirmation reuse/overfitting critique,11/11 risk scan with unresolved checks disclosed. Root plan and robust protocol appended. Old “goal3 complete” is NOT current claim; no evidence of direct truth-writing found in reviewed paths, not exhaustive proof against all leakage.
Latest progress report mydata_bench/auto_research_addbase/ROBUST_PROGRESS_20260910T112600.md.

## Completed families/data boundaries

F1–F6 each15 old234 complete, whole-case passes0 each. F6 all15fit1942 andvalidation493 complete; bestoldprimary+3.8462pp, jointpasses0. Alloldqueues terminal; F6full846 eligiblefalse noexpansion, reservedtestnotrun. No reruns unchanged.
Fit1942/446groups (1253grounded actualgradient+689noROI zero); validation493/108groups(312/181) is REUSED MODEL-SELECTION data afterF6. Original846 exposed/descriptive; old498 not independentconfirmation. Reserved2831/1172groups1788grounded1043fallback0runtimeerrors, labels-performance unopened. Claim `external_roboreward_reserved_v1/reward_model_confirmation_claim_v1.json` absent. Local sealing conventional; backbonepretrainingcontamination notexcluded.

## F7 method and fitting

Signed native-grade-loss ROI attention-gradient ranking, all causal prefill query intervention, unchanged native readout, backbonefrozen, first8excluded, scoreabs(mu)-1.96SE across446episode means, direction-sign(mu), fixedb1/k32,48,64/primary48/all_frames. Supervised selection, NOTtrainingfree. Noentropy/anchor/gain/endpointassignments. FulltaskguidesROI; noonline-streamingcausalityclaim. Engineering CPU and2realexamples/model passed beforefitting.
Fitting sources5 and15configs frozen fromprevious turn. Fitqueue2553345 stillrunsGPU0/3. Queue stopsafterfitting. Completion `f7_all_fit_queues_completion_v1.json` notyetatcheckpoint. No fitfailure observed.

Actualfit snapshot:
```json
{
  "meter_text_image": {
    "counts": {
      "ok": 716,
      "no_grounding": 365
    },
    "complete": false,
    "failure": false
  },
  "meter_text_video": {
    "counts": {
      "ok": 1253,
      "no_grounding": 689
    },
    "complete": true,
    "failure": false
  },
  "meter_video_text": {
    "counts": {
      "ok": 1253,
      "no_grounding": 689
    },
    "complete": true,
    "failure": false
  },
  "qwen_image_text": {
    "counts": {
      "ok": 1253,
      "no_grounding": 689
    },
    "complete": true,
    "failure": false
  },
  "qwen_interleaved": {
    "counts": {
      "ok": 1253,
      "no_grounding": 689
    },
    "complete": true,
    "failure": false
  },
  "qwen_text_image": {
    "counts": {
      "ok": 626,
      "no_grounding": 314
    },
    "complete": false,
    "failure": false
  },
  "qwen_text_video": {
    "counts": {
      "ok": 1253,
      "no_grounding": 689
    },
    "complete": true,
    "failure": false
  },
  "qwen_video_text": {
    "counts": {
      "ok": 1253,
      "no_grounding": 689
    },
    "complete": true,
    "failure": false
  }
}
```
Atlastpoll GPU0qwen_text_image PID2567741, GPU3meter_text_imagePID2567978; othercompletedvideoPIDsnowterminal. Revalidate actualevents beforeaction. GPU0~25GBfree,GPU3~42GBfree whileworkersloaded; do not interpret currentlyfree as availablebefore next load. Fitqueue launchthreshold32GB remainsfrozen. ActualMeterengineering peak37.8GB prior.

## NEW: F7 evaluation is now FROZEN and QUEUED

`R/f7_evaluation_policy_v1.json` SHA `8a8ffaa90c127851f58ea82ac2b4c334062867199d622025421a20460bee8a06` created beforeANYF7evaluation, with64localPython source hashes/transitive importclosure, content snapshots `f7_evaluation_source_snapshots_v1`,90F6completion/config/prediction comparator hashes. All64 revalidatedunchangedafterchanges. Allthese64 are nowfrozen, including nine newevaluationfiles/helper ANDF7fitfiles plus existingdependencies.
Newfrozen:
- all_query_reward_gradient_runtime.py
- all_query_reward_gradient_development.py
- all_query_reward_gradient_validation.py
- freeze_all_query_reward_gradient_development.py
- freeze_all_query_reward_gradient_validation.py
- analyze_all_query_reward_gradient_development.py
- analyze_all_query_reward_gradient_validation.py
- all_query_reward_gradient_evaluation_queue.py
- reward_control_feasibility.py

Beforefreeze: changed misleading independentprint to “F7 training model-selection validation”; changed firstlabeljoincomment to explicitlyF7-onlyafterpriorF6; devfreezer nowchecks/providesentireevaluationpolicySHA closure. Copiedqueue dispatchbug wasfixedbeforefreeze to F7analyzers; verified.

DurableevalqueuePID2567628, launch `f7_evaluation_queue_launch_v1.json`, plan `f7_evaluation_queue_plan_v1.json`, stdoutemptyexpectedwaiting. Itwaitsactualfitqueuecompletion; failswithoutopeningvalidationifthefitsfail. Whenall15successful: freezesdevthenvalidationbeforeANYeval;GPU0/3run oldengineering→validationengineering→493validation→old234 for15cases; thenF7oldanalyzer andF7validationanalyzer. No846orreservedtestinthisqueue.

14devconditions (somevalidation15ifbestoriginalextra): typed/nativebaseline;originalk32/48/64;F7k32/48/64;zero/wrong/lowk48;raw_all_k48;learned_positive_k48;learned_readout_k48. TargetusesF7allquerykernel;learned_readoutcontrolsameF7heads/directions withF6readoutkernel. Engineeringchecks targetall_causal_queries andcontrolonly_readout_query_changed. Old234baseline/original cacheF1 verifiedbySHA andactualparity.493recomputesconditions. NoROI fallbacktypedbaselineallROImethods,full493denominator.

TypedWrongRegionUnavailable controlssetcontrol_geometry_infeasibleonlyforthatgeometryexception. Feasiblewronghelper reportsconditionalgroundedcomputable-controlcomparison, retainscandidateerrors, separatesothercontrolerrors. Mainfullcohortunchanged; nofalseattributionfrominvalidwrongpenalty. Newhelpert testpassedpriorhandoff, notrerununchanged.

Analyzers compare F6fixedpredictions in additionto sameheadreadout/raw/positive/low. F6predictionSHAsverifiedatpolicyfreeze ANDruntimecompletion. F7oldstrictgateunchanged;493all15completebeforelabeljoin,20kepisodebootstrap seed20260910,primaryIUT/Holm, jointSAMEinputspermodel.493isreusedselection, bootstrap/HolmdoNOTrepairadaptivehistory. AllF7evalnotyetstartedatcheckpoint, so noF7performanceclaim.

## NEW: F7 conditional full846 is FROZEN and QUEUED

FourNEWfilesnowfrozenbysnapshots/launch/queueplan:
- all_query_reward_gradient_full_old.py
- freeze_all_query_reward_gradient_full_old.py
- analyze_all_query_reward_gradient_full_old.py
- all_query_reward_gradient_full_old_queue.py

Launch `R/f7_full_old_queue_launch_v1.json`, snapshots `R/f7_full_old_source_snapshots_v1`, durablePID2568642. WaitsF7evaluation_and_analysis_completion; checksjointeligibilitysame≥3inputs/modelbeforefreezingany846config. Failurewriteseligibilityfalseandreturns; neveropensreservedtest. Ifeligiblealljointpassingcasesrunoldengineeringthenfull846GPU0/3, analyzesallconditionsboththresholdsandscope. UsescorrectF7runtime/rankings/roots,cacheold234SHA/conditionexact;cachedfailuresretained;runtimeerrorspreserved. Engineeringincludeslearned_readoutandchecksqueryscope. Wrongcontrolfullpenaltyexcludedfromprimarycontrolattribution;conditionalfeasibilityreportaddedwithcandidatefailuresretained,othererrorsseparate. Fullgateunchanged.

2 meaningfulCPUtests passed `test_all_query_reward_gradient_full_old.py`: can't substitute9totalfor3permodel;changedcachedconditionrejectedandcachedfailurepreserved. AllfiveASTpassed. Usedpytestbasetemp `R/f7_full_old_testing_v1`; NEVERreuseaspytestdeletesfixtures.

## NEW: F7 final confirmation PREPARED ONLY, UNFROZEN/UNACTIVATED

Four NEWversions of earlier unfrozenF6scaffolding:
- all_query_reward_gradient_confirmation.py
- freeze_all_query_reward_gradient_confirmation.py
- analyze_all_query_reward_gradient_confirmation.py
- all_query_reward_gradient_confirmation_queue.py

TheyuseF7runtime, F7validationfallbackhelper, F7allquery/readoutengineeringchecks,typedgeometryexception,conditionalwrongcontrolanalysis. Full846prerequisite,once-onlysharedreservedclaim,allselected9–15cases/all2831completebeforefirstlabeljoin,20kpairedgroupsbootstrap/IUT/Holm. No kretuneorcasefailuredeletion. OriginalF6fourpreparedfilesremainuntouchedandunactivated.
2CPUtests passed `test_all_query_reward_gradient_confirmation.py`: originalscopeprerequisite and incompleteoutputsblocklabeljoin. FiveASTpass. Pytestbasetemp `R/f7_confirmation_testing_v1`; doNOTreuse. NoF7confirmationpolicy/sourcefreeze/queue/claim/testpredictionscreated. These files remain EDITABLE untilactualfuturefreeze; re-review beforeactivating. Proposedfinalcriteriaarein code, notyetfrozen:all3kMAE/allgradeaccbetterthan2baseline/samek/bestold846, endpointnondegradeboththresholds,primaryIUT/Holm<=.05≥3inputs/model; noexternal+10ppsubstitutionforold846. Mayadaptagain ifF7failsbeforetestopening, withnewfamilyversionandclearlineage.

## Live queues
```json
{
  "fit": {
    "pid": 2553345,
    "command": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.all_query_reward_gradient_fit_queue "
  },
  "evaluation": {
    "pid": 2567628,
    "command": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.all_query_reward_gradient_evaluation_queue "
  },
  "full_old": {
    "pid": 2568642,
    "command": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.all_query_reward_gradient_full_old_queue "
  }
}
```

## Next actions

1. MonitoractualF7fitcompletion/errorsandGPUmemory. All15successautomaticallylaunchesfrozenengineering/evaluation; don'tmanuallyfreezeagainorrunduplicateinference.
2. Onengineering/evalfailureinspectpreservedoutputs,nevereditfrozenfilesorsilentretry. Newversionifrepairneeded; truthfullyseparatenumericalrepairsfromperformancechanges.
3. SaveF7resultswhencomplete;full846conditionalqueuealreadyhandlesjointgate. IfF7fails,keepallfailuresandseek principlednewmethodwithoutopeningreservedtest. No claimreuseddataarenewconfirmation.
4. IfF7qualifiesfull846,reviewpreparedF7finalconfirmation,freezeappropriatepolicy/input/group/labelSHAswithoutlookingatperformance,thenactivateonce-onlyqueue. Currentfinalconfirmationnotqueued.
5. Usergoalstillactive;finalgoalrequiresfulloriginalscopeandindependentfinalevidence+documentation. Statusnotcomplete/notblocked.

No pending exec sessions at checkpoint; three durablequeues pluscurrentfitworkers only. No subagents.
