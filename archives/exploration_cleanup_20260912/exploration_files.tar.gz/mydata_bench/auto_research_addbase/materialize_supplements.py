"""Materialize every frozen offline supplement after native branches finish."""
import argparse,subprocess
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--folder',required=True);a=p.parse_args();folder=pathlib.Path(a.folder)
    if not (folder/'combination_events.jsonl').exists():raise ValueError('Wait for the default combination to finish first')
    ledger=folder/'analysis_supplements.jsonl'
    if not ledger.exists():return
    for entry in read_rows(ledger):
        path=pathlib.Path(entry['path']);supplement=json.loads(path.read_text())
        if fingerprint(supplement)!=entry['sha256']:raise ValueError('Frozen supplement hash mismatch')
        with (folder/(path.stem+'_materialize.log')).open('a') as f:
            subprocess.run([sys.executable,'-m','mydata_bench.auto_research_addbase.combine_scores','--folder',str(folder),'--supplement',str(path)],stdout=f,stderr=subprocess.STDOUT,check=True)
    append(folder/'supplement_materialization_events.jsonl',{'time':timestamp(),'all_current_ledger_entries_materialized':True})
    print(folder.name,'all frozen supplements materialized')


if __name__=='__main__':main()
