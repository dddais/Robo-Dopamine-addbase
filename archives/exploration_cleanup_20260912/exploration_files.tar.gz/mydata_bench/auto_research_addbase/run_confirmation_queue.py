"""Run only frozen confirmation cases, with durable process and coverage logs."""
import argparse
import fcntl
import subprocess
import time

import yaml

from .common import *
from .resume_preserved_score_queue import matching_model_processes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, required=True)
    parser.add_argument('--cases', required=True)
    parser.add_argument('--manifest', default=str(RESEARCH / 'confirmation_v1/frozen_manifest_v1.json'))
    args = parser.parse_args()
    manifest_path = pathlib.Path(args.manifest).resolve()
    manifest = json.loads(manifest_path.read_text())
    cases = {c['model'] + '_' + c['protocol']: c for c in manifest['cases']}
    names = args.cases.split(',')
    if len(set(names)) != len(names) or set(names) - set(cases):
        raise ValueError('Only distinct frozen cases may be scheduled')
    events = manifest_path.parent / f'queue_gpu{args.gpu}_events_v1.jsonl'
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(args.gpu), OMP_NUM_THREADS='2',
               OPENBLAS_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
    append(events, {'event': 'queue_started', 'time': timestamp(), 'pid': os.getpid(),
                    'manifest_sha256': fingerprint(manifest), 'cases': names})
    for name in names:
        case = cases[name]
        config_path = pathlib.Path(case['config_path']).resolve()
        cfg = yaml.safe_load(config_path.read_text())
        out = output_path(case['output_dir'])
        if fingerprint(cfg) != case['config_sha256'] or fingerprint(json.loads((out / 'ranking.json').read_text())) != case['ranking_sha256']:
            raise ValueError('Frozen configuration or ranking changed')
        with (out / 'confirmation_coordinator_v1.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if matching_model_processes(config_path):
                raise RuntimeError('A live inference process already owns this case')
            stages = []
            if not (out / 'completion_events.jsonl').exists():
                if (out / 'launches.jsonl').exists():
                    raise RuntimeError('Prior inference incomplete; engineering review required before resuming')
                stages.append(('score_branches', ['--config', str(config_path)]))
            if not (out / 'combination_events.jsonl').exists():
                stages.append(('combine_scores', ['--folder', str(out)]))
            for stage, arguments in stages:
                if stage == 'score_branches':
                    while True:
                        free = int(subprocess.check_output(['nvidia-smi', f'--id={args.gpu}', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
                        if free >= (24000 if cfg['model'] == 'meter' else 34000):
                            break
                        append(events, {'event': 'waiting_memory', 'time': timestamp(), 'case': name, 'free_mib': free})
                        time.sleep(20)
                else:
                    ids = json.loads(pathlib.Path(cfg['example_ids_file']).read_text())
                    attempted = {(r['example_id'], r['condition']) for r in read_rows(out / 'score_branches.jsonl')}
                    missing = sum((i, b['name']) not in attempted for i in ids for b in cfg['branch_conditions'])
                    if missing:
                        raise RuntimeError(f'{missing} frozen branch attempts are missing')
                command = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.' + stage] + arguments
                with (out / f'confirmation_{stage}_v1.log').open('a') as log:
                    child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                    append(events, {'event': 'launch', 'time': timestamp(), 'case': name, 'stage': stage,
                                    'pid': child.pid, 'command': command})
                    code = child.wait()
                append(events, {'event': 'exit', 'time': timestamp(), 'case': name, 'stage': stage,
                                'pid': child.pid, 'returncode': code})
                if code:
                    raise RuntimeError('Confirmation stage failed; preserve outputs and inspect before resuming')
            append(events, {'event': 'case_completed', 'time': timestamp(), 'case': name})
    append(events, {'event': 'queue_completed', 'time': timestamp()})


if __name__ == '__main__':
    main()
