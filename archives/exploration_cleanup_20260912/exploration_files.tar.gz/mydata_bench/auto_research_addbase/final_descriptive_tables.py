"""Final fixed-method distributions, task heterogeneity and pairwise tables."""
import csv
import collections
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .common import *
from .task_macro_summary import collect
from .summarize_frozen_report import task_directions

SOURCE_ROOT = RESEARCH / 'shared_entropy_evaluation_v1'
OUTPUT = RESEARCH / 'final_descriptive_tables_v1'


def main():
    if OUTPUT.exists():
        raise ValueError('Preserve previous descriptive artifacts')
    overview = json.loads((SOURCE_ROOT / 'summary_v1.json').read_text())
    cases = {name: json.loads(pathlib.Path(path).read_text()) for name, path in overview['case_files'].items()}
    OUTPUT.mkdir(); records = []; reports = {}
    lines = ['# 最终固定方法的分布、任务差异与同视频配对', '',
             '方法为shared_entropy_evaluation_v1的固定primary。以下846为含开发/ranking重叠数据的描述性全cohort；498为重复使用验证集，不构成新的独立确认。所有任务和期待样本保留。', '']
    for partition in ['full_cohort', 'reused_validation']:
        lines += [f'## {partition}：任务宏平均与异质性', '',
                  '任务等权macro与逐样本micro不同，不等于RoboRewardBench的23子集Overall。MAE列对Meter用连续ordinal，对Qwen/RR用原生1–5。方向计数顺序为改善/持平/变差。', '',
                  '|case|task数|MAE macro native→final|准确率 macro native→final|task MAE方向数|task准确率方向数|',
                  '|---|---:|---:|---:|---|---|']
        per_case = {}
        for name, case in cases.items():
            summaries = case['partitions'][partition]['summaries']; primary = summaries[case['primary']]
            native = summaries['native_generation_baseline']; key = 'continuous_ordinal_mae' if case['model'] == 'meter' else 'mae'
            macro = {n: collect(s)['']['metrics'] for n, s in [('native', native), ('final', primary)]}
            directions = {m: task_directions(primary, native, m) for m in [key, 'accuracy']}
            counts = {m: [len(directions[m][d]) for d in ['improved', 'tied', 'worsened']] for m in directions}
            lines.append(f'|{name}|{len(primary["by_task"])}|{macro["native"][key]["macro_task"]:.6f}→{macro["final"][key]["macro_task"]:.6f}|{macro["native"]["accuracy"]["macro_task"]:.4%}→{macro["final"]["accuracy"]["macro_task"]:.4%}|{"/".join(map(str, counts[key]))}|{"/".join(map(str, counts["accuracy"]))}|')
            per_case[name] = {'macro': macro, 'task_directions': directions,
                              'native': {'overall': native['overall'], 'by_split': native['by_split'], 'pairwise': native['pairwise']},
                              'final': {'overall': primary['overall'], 'by_split': primary['by_split'], 'pairwise': primary['pairwise']}}
            for variant, summary in [('native', native), ('final', primary)]:
                for task, splits in summary['by_task_split'].items():
                    for split, values in splits.items():
                        record = {'case': name, 'partition': partition, 'variant': variant, 'task': task, 'split': split}
                        record.update({k: values.get(k) for k in ['n_expected', 'n_valid', 'mae', 'continuous_ordinal_mae', 'accuracy', 'endpoint_accuracy_0.125_0.875', 'endpoint_accuracy_0.2_0.8']})
                        record.update({f'predicted_{i}': values.get('prediction_distribution', {}).get(str(i), 0) for i in range(1, 6)})
                        records.append(record)
        reports[partition] = per_case
        lines += ['', f'## {partition}：成功/失败预测分布', '',
                  '每个格为按1/2/3/4/5档排列的实际计数；中间档没有从结果中删除。', '',
                  '|case|类别|native 1/2/3/4/5|final 1/2/3/4/5|有效/期待|',
                  '|---|---|---|---|---:|']
        for name, case in per_case.items():
            for split in ['suc', 'fail']:
                native = case['native']['by_split'][split]; final = case['final']['by_split'][split]
                counts = lambda s: '/'.join(str(s['prediction_distribution'][str(i)]) for i in range(1, 6))
                lines.append(f'|{name}|{split}|{counts(native)}|{counts(final)}|{final["n_valid"]}/{final["n_expected"]}|')
        lines += ['', f'## {partition}：同视频suc−fail配对', '',
                  '差值计数顺序为负/0/1/2/3/4。仅有cohort内eligible suc的fail能组成配对，其余仍在总体分母中。mean progress gap越大表示平均分离增加，但不能掩盖负序或平分数量增加。', '',
                  '|case|native 负/0/1/2/3/4|final 负/0/1/2/3/4|mean gap native→final|有效/期待配对|',
                  '|---|---|---|---:|---:|']
        for name, case in per_case.items():
            native = case['native']['pairwise']; final = case['final']['pairwise']
            counts = lambda s: '/'.join(str(s['discrete_suc_minus_fail_counts'][k]) for k in ['negative', '0', '1', '2', '3', '4'])
            lines.append(f'|{name}|{counts(native)}|{counts(final)}|{native["mean_progress_gap"]:.6f}→{final["mean_progress_gap"]:.6f}|{final["valid_pairs"]}/{final["expected_pairs_with_suc_in_cohort"]}|')
        lines += ['']
    with (OUTPUT / 'per_task_split_metrics.csv').open('x', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(records[0])); writer.writeheader(); writer.writerows(records)
    first = next(iter(cases.values()))['partitions']['full_cohort']['summaries']
    tasks = sorted(first['native_generation_baseline']['by_task'])
    fig, axes = plt.subplots(1, 2, figsize=(17, 12))
    plots = [('mae', 'MAE difference: final minus native'), ('accuracy', 'Accuracy difference: final minus native (pp)')]
    for ax, (kind, title) in zip(axes, plots):
        matrix = []
        for task in tasks:
            row = []
            for name, case in cases.items():
                summaries = case['partitions']['full_cohort']['summaries']; a = summaries[case['primary']]['by_task'][task]
                b = summaries['native_generation_baseline']['by_task'][task]
                metric = ('continuous_ordinal_mae' if case['model'] == 'meter' else 'mae') if kind == 'mae' else 'accuracy'
                row.append((a[metric] - b[metric]) * (100 if kind == 'accuracy' else 1))
            matrix.append(row)
        matrix = np.array(matrix); limit = max(1e-12, float(np.max(np.abs(matrix))))
        im = ax.imshow(matrix, cmap='RdBu' if kind == 'mae' else 'RdBu_r', vmin=-limit, vmax=limit, aspect='auto')
        ax.set_xticks(range(len(cases)), [n.replace('_', '\n', 1) for n in cases], rotation=45, ha='right', fontsize=8)
        ax.set_yticks(range(len(tasks)), [f'{t} (n={first["native_generation_baseline"]["by_task"][t]["n_expected"]})' for t in tasks], fontsize=9)
        ax.set_title(title, fontsize=11); fig.colorbar(im, ax=ax, fraction=.035, pad=.02)
    fig.suptitle('Final fixed method: all 28 represented tasks and all nine primary cases', fontsize=14)
    fig.text(.02, .018,
             'Full descriptive cohort: 846 examples / 299 video clusters. Includes development and ranking-overlap data; no task pruning.\n'
             'Red indicates improvement and blue deterioration in both panels. Small tasks can have large percentage changes; expected sample sizes are shown.\n'
             'Meter MAE uses continuous ordinal progress; Qwen/RR use native 1-5 scores. Exact task/split values and distributions are in the CSV.', fontsize=9)
    fig.tight_layout(rect=(0, .07, 1, .96))
    for extension in ['png', 'svg']:
        fig.savefig(OUTPUT / ('task_effects.' + extension), dpi=180, bbox_inches='tight')
    plt.close(fig)
    lines += ['## 文件与口径', '',
              '`per_task_split_metrics.csv`保留每case/集合/native或final/task/suc或fail的样本数、两种MAE、两套准确率与五档计数。某task没有某类别时n_expected=0，指标留空，分布计数0不能被当作有样本的零准确率。', '',
              '`task_effects.png/svg`展示完整846中的全部28任务，样本量在纵轴标明；不是选择任务或新的验证。全部task/split矩阵在CSV与原分析中。', '',
              '总体验收并不要求每个任务、每个配对指标都改善。本文件保留这些差异，不能把总体通过扩张为所有任务都稳定有效。', '']
    with (OUTPUT / 'report.md').open('x') as handle:
        handle.write('\n'.join(lines))
    create_json(OUTPUT / 'report.json', {'time': timestamp(), 'partitions': reports,
                'source_sha256': {name: hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() for name, path in overview['case_files'].items()},
                'csv_rows': len(records), 'plot_tasks': tasks, 'all_nine_cases_included': len(cases) == 9,
                'analysis_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
                'scope': 'Descriptive final-primary task and pairing supplement. No parameters, cohorts, endpoints or method choices changed.'})
    print(OUTPUT / 'report.md')
    print('CSV rows', len(records), 'tasks', len(tasks), 'cases', len(cases))


if __name__ == '__main__': main()
