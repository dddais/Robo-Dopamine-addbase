"""Audit completed native score branches without reading outcome labels."""
import argparse
import collections
from .common import *
from mydata_bench.meter_eval.readout import canonicalize


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    folder = pathlib.Path(args.folder).resolve()
    if not (folder / 'completion_events.jsonl').exists():
        raise ValueError('Wait for all native branch attempts to finish')
    cfg = json.loads((folder / 'config.json').read_text())
    ids = set(json.loads(pathlib.Path(cfg['example_ids_file']).read_text()))
    specs = cfg['branch_conditions']
    expected = {(i, b['name']) for i in ids for b in specs}
    blob = (folder / 'score_branches.jsonl').read_bytes()
    indexed, counts, conflicts = {}, collections.Counter(), []
    for line in blob.decode().splitlines():
        row = canonicalize(json.loads(line))
        key = (row['example_id'], row['condition'])
        old = indexed.get(key)
        if old:
            fields = [k for k in ['status', 'error', 'progress', 'score_logits', 'native_prediction', 'raw_output']
                      if old.get(k) != row.get(k)]
            if fields:
                conflicts.append({'example_id': key[0], 'condition': key[1], 'fields': fields})
        indexed[key] = row
        counts[key] += 1
    zero = {}
    for ref, test in [('baseline', 'zero_preserve_k32'), ('static_baseline', 'static_zero_preserve_k32'),
                      ('baseline', 'zero_primary'), ('static_baseline', 'static_zero_primary')]:
        if test not in {b['name'] for b in specs}:
            continue
        bad = [i for i in sorted(ids) if indexed.get((i, ref), {}).get('status') != 'ok'
               or indexed.get((i, test), {}).get('status') != 'ok'
               or any(indexed[(i, ref)].get(k) != indexed[(i, test)].get(k) for k in ['progress', 'score_logits'])]
        zero[test] = {'n_expected': len(ids), 'n_exact': len(ids) - len(bad), 'mismatch_or_invalid_ids': bad}
    changed = [i for i in sorted(ids) if indexed.get((i, 'baseline'), {}).get('status') == 'ok'
               and indexed.get((i, 'native_generation_baseline'), {}).get('status') == 'ok'
               and indexed[(i, 'baseline')]['progress'] != indexed[(i, 'native_generation_baseline')]['progress']]
    errors = collections.defaultdict(collections.Counter)
    for (_, name), row in indexed.items():
        if row.get('status') != 'ok':
            errors[name][row.get('error', 'unknown')] += 1
    create_json(args.output, {'time': timestamp(), 'phase': 'Unlabeled engineering audit only; no performance selection',
        'folder': str(folder), 'config_sha256': fingerprint(cfg), 'source_sha256': hashlib.sha256(blob).hexdigest(),
        'n_expected_unique_branches': len(expected), 'n_unique_branches': len(indexed), 'n_raw_rows': sum(counts.values()),
        'n_valid_expected_branches': sum(indexed.get(k, {}).get('status') == 'ok' for k in expected),
        'missing_keys': sorted(expected - indexed.keys()), 'extra_keys': sorted(indexed.keys() - expected),
        'duplicate_keys': [{'example_id': i, 'condition': c, 'n_rows': n} for (i, c), n in counts.items() if n > 1],
        'scientific_conflicts': conflicts, 'errors_by_condition_and_message': {k: dict(v) for k, v in errors.items()},
        'zero_audits': zero, 'native_generation_vs_matched_readout_different_ids': changed,
        'complete_attempts_and_consistent_duplicates': set(indexed) == expected and not conflicts})
    print(folder.name, 'unique/expected', len(indexed), len(expected), 'conflicts', len(conflicts),
          'zero_exact', {k: v['n_exact'] for k, v in zero.items()}, 'native_readout_differences', len(changed))


if __name__ == '__main__':
    main()
