# Robust research checkpoint — 2026-09-10 01:57 Asia/Shanghai

Goal active and unachieved. This turn is progress. Do not mark complete/blocked. User asked whether the old method was cheating; answered in Chinese that no direct label/endpoint assignment was found in checked score computation, but post-confirmation adaptation invalidates independent-confirmation claims. Old “目标3完成” is too strong for current goal. Added F6 supervised-boundary explanation to METHOD_VALIDITY_AUDIT.

## Continue from previous checkpoint

Read ROBUST_CHECKPOINT_20260910T0134.md plus this file. Only target `/mnt/public1/dais/workspace/Robo-Dopamine-addbase` (logical `/home/dais/workspace/Robo-Dopamine-addbase`); all execs explicit cwd and login:false. No git, no other local code repositories, no subagents, no permission questions. All old results preserved; do not edit frozen sources. Python `/home/dais/miniconda3/envs/robo-dopamine/bin/python`; SAM3 corresponding rewardbench-sam3 env. Academic-research-suite already applied inline. Chinese updates.

R=`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1`.
CODE=`mydata_bench/auto_research_addbase`.

## Major addition: F6 downstream validation is implemented and frozen

New files: reward_validation_metrics.py; reward_gradient_validation.py; freeze_reward_gradient_validation.py; analyze_reward_gradient_validation.py; reward_gradient_evaluation_queue.py. Existing reward_gradient_runtime.py, reward_gradient_development.py and freeze_reward_gradient_development.py are NOW FROZEN too. Four CPU tests passed (test_reward_validation_metrics.py x3, test_reward_gradient_validation.py x1); kernel and ranking four earlier tests unchanged. Syntax parsed five new modules. No actual validation model engineering yet; it runs after all fits.

`R/f6_evaluation_policy_v1.json` SHA `2e589f11d9ffeac573a82b177b9b268bd1bbfde65eee1c74aea8b1c40e40628e` contains **27 frozen source dependencies**, old-F1-selected strongest original condition per case, actual493 validation IDs/108groups, shared b1/k32,48,64, full rules, bootstrap20000 seed20260910. Source content snapshots in `R/f6_evaluation_source_snapshots_v1`. DO NOT EDIT ANY SOURCE LISTED IN THIS POLICY. Fits have their earlier separate frozen sources as well. Version justified fixes rather than mutating live dependencies.

Metrics: mixed1–5 all-grade exact accuracy; Meter standard protocol.progress_to_reward five bins; native continuous ordinal MAE + five-bin MAE; both endpoint threshold sets separately; all grades retained; task/source/grade/grounding strata, task/source/episode macros. Invalid outputs retained in full accuracy denominator; MAE max-error4 reporting penalty plus valid-only diagnostic. Any required invalid result prevents gate. No-ROI rows use typed-baseline fallback for every ROI method/control, retain middle scores; this policy is tested.

Validation gate for all3k: lower ordinal MAE/higher all-grade accuracy versus two baselines, same-k original, fixed best-old-development original. Both endpoint accuracies nondecrease vs both baselines under both Meter thresholds. Whole-zero exact. External mixed-grade +10pp is NOT substituted for original target: old234 must independently satisfy its unchanged strict robust gate, and **the same >=3 input cases per model must pass both old234 and validation**. Analyst computes that intersection. Full old846 description and once-only reserved test still required.

Grouped uncertainty: paired full-source/content bootstrap20000, row-weighted full denominator; each-k marginal percentile95 CIs; primary48 MAE/accuracy zero-improvement centered-bootstrap one-sided p across4 references combined by IUT then Holm over15cases. Approximate, not simultaneous CI or +10pp lower-bound test; does not repair prior adaptive selection. Validation is a selection set, not final confirmation.

Durable evaluation waiter **PID2464770** launched and verified alive. `R/f6_evaluation_queue_launch_v1.json`, plan, stdout log. It waits for **all15 fits** of PID2357092. Requires failures=[]; then freezes dev configs and validation configs before ANY F6 inference. Learned ranking hashes captured then. Runs on GPU0/GPU3 with free>=32GB, same case allocation as fitting. Per case: old engineering -> actual validation engineering(two grounded+onefallback when available) ->493 validation ->old234. All15 complete before validation label join. Scheduled analyses robust_analyze --family f6 then analyze_reward_gradient_validation. Never auto-runs reserved test. Stage errors preserved, no retries.

Expected new outputs: `R/reward_gradient_validation_v1/{case}/{engineering,validation}/...`, `R/reward_gradient_development_v1/{case}/{engineering,development}/...`. Plans `reward_gradient_validation_frozen_plan_v1.json` and `reward_gradient_development_frozen_plan_v1.json` are NOT created yet (require all fits). Policy/waiter are created. Analysis is not runnable yet. Pending fitting waiter unchanged and has NOT started fitting.

## External reserved test grounding COMPLETE, no reward-model scores

Grounder PID2309556 ended normally at UTC17:48:00. Do not restart. Full2831:1788 grounded,1043 baseline fallback,0runtime errors. Fallback reasons314 outside single-target scope,607 no legal first-frame target,122 incomplete tracks. Grounded-input SHA `5f380b7e075036c5e551bb2defe625110bca13a5891517e04498efd33d413df4`.

Full structural audit passed all2831 unique IDs/unchanged input fields and all1788 exact displayed-source-frame coverage; track hashes captured `R/external_grounding_complete_structural_audit_20260910T0154_v1.json`. This was structural, not a new pixel decode. Previous actual proxy pixel engineering remains valid. Original test labels/2831 denominator unchanged;1172groups; **reserved test reward-model performance unopened**.

## Other live work

Training parser PID2425817, preparation queue2337640, fitting waiter2357092 verified alive. Parser observed521/1072 at this checkpoint, all statusok. No training grounder yet. Upon parser completion it automatically grounds2435 eligible rows, then fitting1942/446groups and validation493/108groups. Original 2509-selection/13 unavailable/61 quarantined preserved.

F2 latest analyzed12/15 (all Qwen/RR plus Meter text_video/video_text), zero passing. Qwen interleaved completed, primary MAE−.2863, accuracy−4.2735pp, suc−15.7895pp. Qwen image_text acc+10.6838pp but MAE+.02564 and original gate fails. F2 GPU1 terminal failures[]. F3 latest6/15 including Qwen text_video acc+1.7094pp,suc0; allfail. F4/F5 RR5 only each, allfail. F1 final15 allfail (no reason rerun).

Latest analysis paths:
- f1: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f1_frame_transport_analysis_2026-09-09T172443.406728_0000.json`
- f2: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f2_frame_transport_analysis_2026-09-09T175425.864588_0000.json`
- f3: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f3_frame_transport_analysis_2026-09-09T175421.080374_0000.json`
- f4: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f4_frame_transport_analysis_2026-09-09T165149.021698_0000.json`
- f5: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f5_frame_transport_analysis_2026-09-09T171932.281859_0000.json`

## Next work

1. Revalidate actual queue processes and completions (old PIDs not proof). Training parser and subsequent grounder need monitoring; check first real training grounding rows once available. Do not inspect/stop foreign GPU jobs.
2. Monitor actual F6 fitting gradients, rankings and completion after preparation. Synthetic grade3 probes never prove real fit or performance benefit.
3. Evaluation is now durably scheduled; do not start duplicate schedulers or mutate27 frozen evaluation sources. Verify real validation engineering when it launches; retained failures require explicit versioned fixes, not silent retries.
4. Analyze newly finished F2–F5 cases only; correct experiment roots are frame_transport_vcd_v1, specificity_v1, joint_task_v1, task_interaction_v1 (NOT *_development_v1 for F3–F5). Current counts12/6/5/5. All15 F1 alreadyfinal.
5. On a candidate's joint pass, full846 descriptive inference and independent reserved test freezing/inference/metrics still need implementing. Do not open reserved test as a diagnostic while selecting candidates. All current results fail or remain pending.

No pending exec sessions at writing; durable jobs only. Goal remains active, unachieved.
