"""Export every selected exploratory anchor neighbor without changing selection."""
import argparse
from .common import *
from .summarize_frozen_report import BASELINES, compact, task_directions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    source = pathlib.Path(args.source).resolve()
    manifest = json.loads(source.read_text())
    sources = {str(source): hashlib.sha256(source.read_bytes()).hexdigest()}
    reports = {}
    lines = ['# 确认后探索：全部冻结邻居的描述性补充', '',
             f'方案家族：{manifest.get("method_family", "original_method_anchor")}。', '',
             '498条为重复使用验证集；846条含开发及ranking重叠样本。此表不构成新的独立确认，也不覆盖原v1的失败结论。', '',
             'MAE连续项为|1+4p−y|；五档项为原生1–5或固定适配后的MAE。准确率使用全部期待样本作分母。', '']
    for name, path in manifest['case_files'].items():
        blob = pathlib.Path(path).read_bytes()
        sources[path] = hashlib.sha256(blob).hexdigest()
        case = json.loads(blob)
        partitions = {}
        for part, report in case['partitions'].items():
            summaries = report['summaries']
            neighbors = {}
            parameters = case.get('parameters', {'rho': case['rho']})
            parameter_text = ', '.join(f'{k}={v:g}' for k, v in parameters.items())
            lines += [f'## {name} / {part} / {parameter_text}', '',
                      f'三个k点门槛：{report["all_three_k_point_acceptance"]}；另对开发预选原方法严格检查：{report["strict_development_selected_original_acceptance"]}。', '',
                      '|条件|连续MAE|五档MAE|总准确率|suc|fail|0.2/0.8准确率|有效/期待|',
                      '|---|---:|---:|---:|---:|---:|---:|---:|']
            ordered = [*BASELINES, *report['comparisons']]
            for condition in ordered:
                s = summaries[condition]; o = s['overall']
                label = condition
                if condition in report['comparisons']:
                    index = list(report['comparisons']).index(condition)
                    label = f'k{case["selected_ks"][index]}' + (' primary' if condition == case['primary'] else '')
                lines.append(f'|{label}|{o["continuous_ordinal_mae"]:.6f}|{o["mae"]:.6f}|{o["accuracy"]:.4%}|{s["by_split"]["suc"]["accuracy"]:.4%}|{s["by_split"]["fail"]["accuracy"]:.4%}|{o["endpoint_accuracy_0.2_0.8"]:.4%}|{o["n_valid"]}/{o["n_expected"]}|')
            for condition, comparison in report['comparisons'].items():
                s = summaries[condition]
                neighbors[condition] = {
                    'is_primary': condition == case['primary'], 'summary': compact(s),
                    'all_reference_effects': comparison['effects'],
                    'point_gate': comparison['point_gate'],
                    'five_bin_mae_both_baselines': comparison['five_bin_mae_both_baselines']}
            primary = summaries[case['primary']]
            directions = {b: {m: task_directions(primary, summaries[b], m)
                             for m in ['mae', 'continuous_ordinal_mae', 'accuracy']}
                          for b in BASELINES}
            partitions[part] = {
                'all_three_k_point_acceptance': report['all_three_k_point_acceptance'],
                'strict_development_selected_original_acceptance': report['strict_development_selected_original_acceptance'],
                'all_neighbors_five_bin_mae_both_baselines': all(n['five_bin_mae_both_baselines'] for n in neighbors.values()),
                'baselines': {b: compact(summaries[b]) for b in BASELINES},
                'neighbors': neighbors, 'primary_task_directions': directions,
                'primary_intermediate_bin_count': sum(primary['overall']['prediction_distribution'][str(i)] for i in [2, 3, 4]),
                'all_condition_summaries': {n: compact(s) for n, s in summaries.items()}}
            lines += ['', '所有基线、原方法、父方案及anchor-only对照的效应、逐task方向、预测与配对分布见同名JSON及原始分析。', '']
        reports[name] = {k: case[k] for k in ['model', 'protocol', 'rho', 'primary', 'selected_ks']}
        reports[name]['parameters'] = case.get('parameters', {'rho': case['rho']})
        reports[name]['partitions'] = partitions
    output = output_path(args.output)
    if output.exists() or output.with_suffix('.md').exists():
        raise ValueError('Supplement output already exists; preserve previous artifacts')
    create_json(output, {
        'time': timestamp(), 'sources_sha256': sources, 'cases': reports,
        'all_source_cases_included': sorted(reports) == sorted(manifest['case_files']),
        'method_family': manifest.get('method_family', 'original_method_anchor'),
        'scope': 'Descriptive export of all nine fixed score-distribution recipes and all partitions. Reused498 is not independent; full846 includes development and ranking overlap. No selection or inferential claims added.',
        'analysis_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    with output.with_suffix('.md').open('x') as handle:
        handle.write('\n'.join(lines) + '\n')
    print(output)


if __name__ == '__main__':
    main()
