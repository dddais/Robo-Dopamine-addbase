# 自动研究接续点（2026-09-09 13:07）

目标仍active，不能mark complete；全部工作仅Robo-Dopamine-addbase，无git/删除/覆盖结果，无subagents。

## 本阶段新完成

- SOLE canonical结束符修复、真实tokenizer验证及工程v3已通过。所有201候选用原生融合token52508（%</），不是孤立%。两条×39支路全部有效，两类zero logits精确、native15%/20%与整数MAP一致，合法格式质量约0.9999。有效screen是sole_score_development_v2；旧v1整体在validity_annotations排除。
- 新增audit_added_attention.py，输出BASE/attention_audit_snapshot_20260909T123909.json。所有已完成SOLE零干预的全轨迹/raw/trace精确一致。text_video完整七步已经尝试完846×11，有89错误（72原生格式、17wrong几何）；targetk64有37格式错误。两输入完整七步及text_video终步仍运行。
- BASE/metrics_snapshot_20260909T124540.json与added_attention_completed_checkpoint_v2.md，已追加主summary完整七步3输入表和覆盖率。
- RR temporal text_image234完成且多个相邻k通过，interleaved234还在运行；text_video/video_text初筛通过，已冻结234排队。
- Qwen原region234有3输入稳定范围；新增candidate_inventory.py汇总同参数连续已测k，显式阻断缺失/失败中间k；还描述原bias最好MAE/accuracy包络，不能把该包络冒充一个实际k。
- 新native_confidence.py：q_native只调节区域方向，Meter用原生success head，Qwen/RR用全部5bins的归一化期望。formula z0+lambda*(1-q)^power*D，D为region或temporal。全部bins保留，无真值/路径语义/配对数据读入。score_native_confidence_development_v1全部3×5已完成，lambda4/8/16、power1/2。
- matched-uniform消融发现Meter新image_text/video_text收益来自更大的lambda16，不是置信度调节。两输入初筛都双类+10pp，已冻结234；RR image_text只有gated temporal通过初筛，已冻结234。
- 新native-logit-temperature控制：combine_logits支持native_logit_temperature单源配方。Meter image_text/video_text温度锐化不能解释attention收益；text_video温度tau8仅MAE−0.0829但acc+28.33pp，必须单列读出校准贡献。结果RES/native_temperature_development60_control_v1.json。
- 文档已追加RESEARCH_LOG、LITERATURE、主summary及根auto_explore原因分析。新STATISTICAL_VALIDATION_20260909.md有11/11偏差核验和准确确认边界。
- confirmation_analysis_protocol_v1.json仅冻结分析规则：498样本/179视频簇，最终manifest未选，确认未启动；禁止用确认结果反调参数再冒称独立。

## 正在运行的队列

以RES/live_runs_20260909T1307.json及/proc为准，不因旧tool session失联重启。PY=/home/dais/miniconda3/envs/robo-dopamine/bin/python。

|队列|GPU|主要PID/工具session|状态|
|---|---:|---|---|
|SOLE video_text full七步|3|parent1980506 child1980518|192样本已开始，各条件进度不同，约1664/9306条|
|SOLE interleaved full七步|1|parent1980507 child1984884|约1216/9306条|
|SOLE text_video terminal|0|parent1980508 child1984824|约6731/9306条；5个缺native上下文已显式记录错误|
|SOLE score有效v2五输入|1|parent1992470,screen1993312,child1993315; session12870|image_text约11/60，全部5输入随后|
|RR temporal full TI→interleaved|2|parent1987685 child1989994;旧session26750|interleaved约211/234，快结束|
|RR temporal full TV→VT|2|parent1992764;session51420|等待自身1987685结束，再text_video→video_text|
|local radius三模型五输入|0|parent1988581;旧session24023|Meter text_video最后输入运行，随后RR5→Qwen5|
|Meter full幅度/置信度消融|0|parent1994857 child1994861;session52780|image_text234约31/234→video_text234→text_video234|
|RR image_text full gated temporal|3|parent1995390 child1995563;session87255|约11/234，已在Qwen temporal结束后启动|
|Qwen video_text full temporal|2|parent1996320 child1996323;session41728|约31/234|

SOLE主线实际stdout在BASE/sole_{video_text,interleaved}_all_steps_formal_v1.log与BASE/sole_text_video_terminal_step_formal_v1.log；此前preloaded_queue日志为空。GPU0还有非本任务/既有PID1948655，勿动。各GPU目前均繁忙，无OOM，不必新增并发模型。

## 新开发目录和接下来做什么

1. 等RR interleaved full完成后，analyze_score_development --root RES/score_temporal_development_full_v1（可condition-contains temporal）。继续TV/VT队列；不能只凭同k优于original就掩盖其它original k更好的结果，原包络已经提供。
2. 监控Meterfull三输入和RRimagefull，root=score_native_confidence_development_full_v1。ks24/32/40/48/56/60/64/68/72；lambda4/8/12/16；uniform与power1/2，区域/low/original/zero控制。Meter3各38神经支路/194读出，RRimage66/222。
3. 此root每folder已冻结native_temperature_supplement_v1.json并写analysis_supplements，但默认队列combine不会自动执行supplement！待分支/默认combine完成后，显式combine_scores --folder F --supplement F/native_temperature_supplement_v1.json，再分析。不能把未运行的控制当已完成。初筛15folder温度supplement也都存在，目前只Meter5已materialize；离散模型温度不改argmax是数值不变量。
4. Qwen新版confidence初筛TV/VT已combine并分析（analysis_snapshot_20260909T130331.json），两者通过多点但不必再扩展无必要的候选。此前它们晚materialize，尚无uniform_strength_matched_supplement_v1.json；如需要因果归因，应补同lambda控制。
5. local radius当前Meter前四输入分析analysis_meter_checkpoint_stdout_v1.log已完成，尚需读结果；初筛全15预计后续陆续完成。
6. SOLE score60每输入约2小时，完整七步主线更慢，但正常增长。不要静默重启或替换成terminal。待所有主线输入完成后补metrics/audit和最终baseline文档。
7. 至少三模型各三输入有完整234稳定范围后，冻结最终参数manifest与confirm configs，再一次性运行确认；当前仅Qwen完整达到3输入开发资格，尚不能启动确认。
8. 所有新analysis_snapshot文件是较大JSON。必须等写入进程结束再读取；曾在writer仍写时读最新文件出现JSONDecodeError，后续完成后正常，不能误报科学数据损坏。

## 温度与置信度的关键结论

Meter image_text uniform region all/k64/lambda16：初筛MAE−1.1149、总+28.33pp、suc+30pp、fail+27.5pp；video_text同参数MAE−0.9336、总+38.33pp、suc+5pp、fail+55pp。仅小样本，video_text成功类只多1条，需234验证。
RR image_text gated temporal last/k64/lambda8/power1：初筛MAE−0.85、总+31.67pp、suc+10pp、fail+42.5pp；等强度uniform没有通过。
Qwen temporal video_text all/k64/lambda1：初筛MAE−0.7667、总+33.33pp、suc+25pp、fail+37.5pp，已234扩展，原region最后帧版本保留。

仍未达最终验收。

更新13:12：新增qwen_temporal_image_full_v1队列，GPU2，等待1996320；tool session99240。Qwen image/video的k60/64/68 lambda3/4簇区间已完成，部分suc/MAE跨0，详见研究日志。RR interleaved神经分支已结束，combine正在完成；session195?以事件为准，新的分析+inventory工具会话需等返回再读取snapshot。

更新13:18：RR interleaved234已分析（analysis_snapshot_20260909T131227.json），不满足稳定改良，原k24/32也强于其k72候选。Qwen image/video paired文件完成。新KL-budget第七候选已冻结并运行CPU读出，root=score_kl_development_v1，新源码kl_budget.py/freeze_kl_development.py，combine_scores可只读引用带SHA的score_branch_source，所有旧接口测试通过。此前占位session195?没有对应会话；实际RR完成分析会话16334已正常返回。KL批量combine会话以工具返回为准，结束后再分析，确保不要读正在写的大JSON。

更新13:45：SOLE terminal五输入全部完成，全zero精确；text_video76错误=55缺历史+15wrong几何+6native格式。main1仅interleaved/video_text full还在跑。新Meter video_text last-temporal强度234 queue GPU2，session70036，目录score_kl_development_full_v1/meter_video_text（28branches/95readouts）。KL60与uniform32/64已分析，收益仍多由更大幅度解释。8个full folder新增posterior_budget_and_large_gain_supplement_v1.json；默认combine后要运行materialize_supplements再分析。RRtext_image和Qwentext_video已补；Qwenvideo_text full默认已完成，补读出+分析队列正在工具运行。SOLE官方范围已由论文414–416核实，native有一条101%终值（fail/ljx_lfz_task_3_7/4），不裁剪，审计JSON已保存。原生baseline PNG/SVG图已生成并链接到summary。
