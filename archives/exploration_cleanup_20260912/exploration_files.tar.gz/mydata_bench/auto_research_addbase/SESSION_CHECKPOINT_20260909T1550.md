# 接续检查点（2026-09-09 15:50）

目标仍active，所有主线未完成。只在Robo-Dopamine-addbase操作，不执行git，不删除/覆盖原数据；无subagents。原详细背景承接SESSION_CHECKPOINT_20260909T1307及主summary/RESEARCH_LOG。

## 本段关键进展

- RR video_text b1.5完整234开发已完成，最好总+7.6923pp，仍不达门槛。最终选型`confirmation_candidate_selection_20260909T151434.json`仍九项（Meter/Qwen/RR各三输入）。
- **确认已冻结并启动，禁止再选参数或增删case。** `RESEARCH/confirmation_v1/frozen_manifest_v1.json`为唯一清单；真实validate-only和实际配置依赖检查通过。全部primary/邻居、两个baseline、same-k和开发选定原方法、primary zero/wrong/low/温度/模块对照一次性冻结。
- GPU0确认父2037992：rr_image_text→rr_text_image→rr_text_video；GPU1父2037993：qwen_image_text→qwen_text_video→qwen_video_text；GPU3父2037994：meter_image_text→meter_text_video→meter_video_text。日志各case `confirmation_score_branches_v1.log`，顶层queue_gpu*_events_v1.jsonl。15:48时first cases约171/101/141条。未读取新方法确认性能；只检查工程错误，少量wrong几何不可行如实保留。
- `frozen_cohort_completion_v1/frozen_manifest_v1.json`在未读确认性能时冻结remaining114，保持九方案所有邻居。对应GPU等待父2039243/2039244/2039245，等各自确认三项完成后自动补跑114。之后用原开发234+确认498+114汇总846，**只能描述性统计**。九方案全部保留，不能仅保留确认成功的case。开发源SHA与全部所需condition×234覆盖已预核验。
- `completion_analyses_v1/plan.json`九项完成后分析，守护父2040764。记录events.jsonl与每任务log。自动执行SOLE四项final audit、五输入screen分析、498 confirmation分析、846full分析、主线1最终attention audit和metrics。分析错误记录后不会自动重试，应检查log。

## SOLE状态

- mandatory主线1完整七步video_text/interleaved仍在GPU3/GPU1运行：父1980506/1980507，子1980518/1984884，batch64+preloaded indices+native dynamic。日志BASE/sole_{protocol}_all_steps_formal_v1.log。15:37时video_text offset320，interleaved offset256，仍需数小时，不能因慢标blocked。
- numerical screen父2026510在GPU0已完成text_image并转video_text；父2026511在GPU2已完成interleaved并转text_video。合法后续子PID需实际/proc核验，不能按旧父shell句柄盲目重启。
- SOLE text_image最终审计已关闭双写待办：`completed_score_audit_20260909T153343.json`。score原2450行/2340唯一键，110重复键科学字段冲突0；sweep15000/15000唯一有效，零重复。observed/static zero各60精确；一条native/MAP差异83% vs85%。
- image_text最终审计`completed_score_audit_20260909T152947.json`：2340支路有效、sweep19924行/15000唯一有效，重复科学字段冲突0；两条native/MAP差1pp。
- interleaved最终审计`completed_score_audit_20260909T154210.json`：2340/15000唯一有效无重复，两个zero60精确，native/MAP无差异，格式概率min0.999346。
- 完成三输入的`sole_score_development_v2/analysis_snapshot_20260909T154533.json`：每输入104完整target候选，全部0个通过改良门槛。最大总增益image_text1.67pp、text_image/interleaved10pp，但后两者不同时满足MAE/两类/原方法要求。两视频数值screen继续，15:49 video_text412支路/11样本开始，text_video188支路/5开始，全部ok且持续写出。
- 旧错误百分号token版本保留排除。当前201规范整数−100..100的完整闭合tag联合概率正确；不能把这项固定reasoning末步screen当完整七步干预。

## 新代码（均未改已冻结的科学推理实现）

- run_confirmation_queue.py：指定冻结manifest和case，等显存、排他协调锁、无静默重试，score→combine；也用于114completion。
- freeze_cohort_completion.py、run_frozen_followup.py、analyze_frozen_cohort.py。前两者已执行/排队，分析尚待完整数据。full分析使用匹配来源条件直接拼接，不需重复推理732条。
- audit_sole_screen.py已在三完成输入真实运行通过。
- run_completion_analyses.py已durable启动。
- render_confirmation.py仅已编译，待confirmation_analysis结果完成后`--analysis PATH`生成全部九primary效应与CI PNG/SVG；需实际view_image核验。

## 精确分母

原1213=407视频簇，407/806；grounded846=299簇，268/578；dev234=86簇，76/158；confirm498=179簇，158/340；remaining114=34簇，34/80。Grounded可配对fail543/578，confirm315/340。31/21个grounded/confirm视频簇没有eligible suc；它们仍参与总体准确率。“完整簇”是在eligible grounded集合内保留，不是声称原1213该视频全部条目均已grounded。见`frozen_cohort_completion_v1/partition_pairing_coverage_audit_v1.json`。

## 接下来

1. 按实际进程/输出监控所有队列，不重复启动；相同科学源文件保持冻结。
2. 收取两个剩余SOLEscreen最终审计和全五输入分析；收取九项确认完整分析，报告全部失败、20000视频簇CI、IUT/Holm，不能确认后调参复用同498冒称独立。
3. 114自动补齐后收取完整846描述性汇总，核对其独立性限定。
4. 两项mandatory全七步完成后收取最终BASE metrics/attention audits，补全baseline主summary与图表。
5. 所有主线真正完成才写自洽最终报告、根计划最终有效方案与逐项验收；完成前不标goal complete。若方法未达验收，须如实保留失败并继续合理研究，不假称成功。

ROOT=/home/dais/workspace/Robo-Dopamine-addbase（物理/mnt/public1/dais/workspace/Robo-Dopamine-addbase）；BASE=results/mydata_bench/experiments_v2_addbase/session_20260908；RESEARCH=results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260908；PY=/home/dais/miniconda3/envs/robo-dopamine/bin/python。所有exec显式ROOT cwd、login:false。


## 16:17后续补充

新增REPRODUCTION_GUIDE_20260909.md。补充保存mydata_bench全部141源码SHA；原冻结21推理文件未变。analyze_confirmation/analyze_frozen_cohort新增输入/统计实现/partition IDs完整性检查，实际通过，不改指标或参数；新分析源码hash与理由在confirmation_v1/analysis_integrity_checks_supplement_v1.json。

新核实RoboReward论文2601.00675v2 Section3微平均1..5 MAE公式与本轮一致；论文Table1 Overall另作23benchmark子集等权聚合，不等于本数据34task。task_macro_summary.py可从既有summary递归导出task等权MAE/准确率，已实际跑BASE12:45快照。**最终BASE/confirmation/full846分析结束后，需要手动对新的结果再生成macro补充并报告；九任务watcher尚不包括这项新增描述性补充。** 不能改变冻结确认主指标。

注意官方输入表述：RoboReward代码区分公开HELM text_video与model-card例video_text，无公开独立benchmark evaluator；所选RR text_video有公开请求来源，不能误称所有RR官方输入都未覆盖。Meter所选三输入为适配，官方text_image未入选。


### 2026-09-09 16:23：全部Meter邻居的五档MAE补查

`confirmation_v1/development_all_neighbor_five_bin_mae_audit_v1.json`仅检查开发234，确认性能未读取。Meter三个输入×三个k的五档MAE均相对两套baseline下降：image_text约−1.1410/−1.1111/−1.0769；text_video约−0.6838/−0.6752/−0.6453；video_text约−0.7350/−0.7607/−0.6880。原连续ordinal MAE改善与此相容。最终确认/846总结需逐邻居同时核对并给出两种MAE，不能只写primary或只挑较好口径。既有确认门槛/参数不改；任何更严格的全邻居五档检查须与原冻结point gate分列。


## 2026-09-09 16:35：Qwen调度按后续空余GPU重新分配

资源安排由原先Qwen三个输入都在GPU1串行，改为：当前qwen_image_text模型PID2038007继续在GPU1完成；qwen_text_video待GPU2的SOLE text_video数值screen及其补充结束后启动；qwen_video_text待GPU0的SOLE video_text数值screen及其补充结束后启动。四卡均为A100-SXM4-80GB。这样利用后续释放的资源，并减轻SOLE mandatory全七步interleaved与Qwen队列长期共享GPU1的压力。

事先保存`RESEARCH/confirmation_qwen_gpu_handoff_v1/plan.json`，核对cmdline/cwd/真实模型子进程后，仅停止旧Qwen调度父2037993和旧Qwen 114等待父2039244；未给模型2038007发送信号，接管后仍正常运行。恢复父2062735（上层2062732）只等待该模型真实完成，再做combine，避免重复前向或双写。两个新等待父2062733/2062734分别负责GPU2/GPU0后续输入。各输入确认完成后在自己的GPU接续已冻结114补跑。

RR/Meter原确认父2037992/2037994和114等待父2039243/2039245继续运行。完成后分析守护2040764按各case的真实completion/combination标记执行，仍适用于此次分配。新确认任务可能使同一GPU事件日志出现多个独立队列的事件；完成判断必须按case与输出目录，不能仅把某个queue_completed当成该GPU所有工作已完成。

此次变更只调整未来资源调度。九个case、每项三个k、所有分支/读出/对照、数据ID、ranking和统计口径不改；重新核验原冻结21个推理文件SHA全部相同。全部调度动作、等待条件、PID和阶段退出码都在handoff目录保存，原manifest与预测不修改。


## 16:45–16:50 接续更新：首项确认完成且点门槛通过

RR image_text已全部完成，`confirmation_v1/rr_image_text/individual_case_analysis_v1.json`是首次真实读取确认性能。九项保持冻结，其余八项未完成；该case三个k60/64/68均过两baseline+same-k original点门槛，primary也胜开发选定原方法，strict_original=True。相对native总增益10.24096/11.44578/10.44177pp，suc+1.8987/+3.7975/+3.1646pp，fail+14.1176/+15.0000/+13.8235pp。primary MAE0.833333→0.668675，suc95%CI[-1.2821,+9.0909]pp跨0，IUT p=.121044；尚无九项Holm/总体验收。其余详细CI、全部控制、分布/配对见主summary16:45段。

主primary相对wrong/low/observed-only总+17.4699/+9.2369/+10.0402pp；相对同强度uniform总+15.0602pp，但fail−2.3529pp而suc+52.5316pp。315配对负序43→17、ties25→59，正差数247→239，平均gap上升；不能泛称全部pairwise指标改善。

新增audit_score_engineering.py（无标签原始支路审计）真实跑RR image_text：15438/15438唯一有效，无重复冲突；四zero各498精确；native/readout分数差5条。对应completed_branch_engineering_audit_v1.json。后续完成case可使用该脚本补查原始支路冲突，最终analyze_confirmation主要审计sweep。

发现并修正分析metadata：共享开发contrast函数硬带confirmation:false，首次独立case输出也带入该历史字段。最终分析wrapper已移除该字段，改标evaluation_phase=frozen_confirmation，接受与否仍用单独acceptance布尔。所有首case数字对比实际重新计算并精确相同，metrics.py/paired_analysis.py等未改，推理参数未改。原individual_case_analysis_v1.json保留，通过confirmation_v1/analysis_metadata_correction_v1.json解释旧字段；新分析源码SHA/快照已保存。不要把旧内部confirmation:false误读为该case点验收失败。

RR队列已启动text_image，新模型PID2064357（父2037992）。Qwen image_text模型2038007继续，接管父2062735/上层2062732在等待；后续Qwen两个等待父2062733/2062734按16:35新安排。Meter image_text尚在跑，约440+/498。SOLE video_text/text_video numerical约41/60；mandatory两个全七步仍运行。实际进度/PID请复核。


## 2026-09-09 16:55：Meter image_text冻结独立确认完成

`confirmation_v1/meter_image_text/individual_case_analysis_v1.json`覆盖全部498条。三个冻结邻居通过两baseline及同k原方法点门槛，primary k68也胜开发选定原方法；主参数没有根据确认中k64较高的总准确率重新选择。

|k|连续ordinal MAE|五档MAE|总准确率（0.125/0.875）|suc准确率|fail准确率|总准确率（0.2/0.8）|
|---|---:|---:|---:|---:|---:|---:|
|baseline|2.255305|2.351406|0.0000%|0.0000%|0.0000%|0.0000%|
|64|1.008300|0.959839|51.0040%|34.8101%|58.5294%|61.2450%|
|68|1.042449|1.004016|46.9880%|33.5443%|53.2353%|60.6426%|
|72|1.064509|1.068273|43.9759%|27.2152%|51.7647%|57.2289%|

baseline的0%端点准确率需要作为绝对参照披露：这是image→text自定义适配，498条输出落在17个3档和481个4档，不能把相对大增益误解为官方输入已经达到同样水平。primary真实端点准确率46.9880%，第二阈值60.6426%；连续与全部三个邻居五档MAE均下降。
primary相对native的95%视频簇区间：连续MAE变化[−1.31318,−1.10820]，总准确率变化[+42.4063,+51.6395]pp，suc[+26.3804,+41.0256]pp，fail[+46.8208,+59.7734]pp。四方向IUT Monte Carlo p=1/20001≈0.000050；全九项Holm结果仍等待其余case。

原始8964个期待支路键全部尝试、无重复冲突；8952有效，12个错误来自6条样本的wrong正负分支几何不可行。两个zero（k32与primary k68）各498/498精确，native/readout baseline分数完全一致。主方法与原方法等必需结果完整；wrong对照只在明确492条可行子集上比较，primary的连续MAE比wrong低0.526540，总准确率高41.4634pp。相对low-head的全498比较为MAE−1.163881、总+43.1727pp。
相同强度的native-logit温度及KL温度均未复制目标区域的失败类收益；各温度下fail准确率仍为0%，primary为53.2353%。这支持区域证据方向的作用，仍不能将本适配下的收益推广成所有输入或真实物理任务的因果理解。

primary五档分布为215/179/11/29/64，中间档219条。315配对的negative/0/1/2/3/4由baseline的0/313/2/0/0/0变为7/126/29/23/86/44，mean progress gap从0.006525到0.387053；排序解除了大量平分，同时出现7个负序，保留完整分布。


## 2026-09-09 17:01：SOLE五输入数值screen与最终审计全部完成

`sole_score_development_v2/analysis_snapshot_20260909T165904.json`覆盖同一60条/24视频簇上的全部五种输入。每输入39个神经支路与250个总读出均完成（104个完整target候选），**没有任何target候选通过四向/+10pp及同k原方法改良门槛**。下表报告每输入“最大总准确率增益”的单个实际候选，连同其余指标，避免拼接不同点。

|输入|该点MAE变化|总准确率变化|suc变化|fail变化|完整通过点数/target点数|
|---|---:|---:|---:|---:|---:|
|sole_image_text|-0.085333|1.6667pp|0.0000pp|2.5000pp|0/104|
|sole_interleaved|0.046667|10.0000pp|0.0000pp|15.0000pp|0/104|
|sole_text_image|0.868667|10.0000pp|15.0000pp|7.5000pp|0/104|
|sole_text_video|0.613333|33.3333pp|-20.0000pp|60.0000pp|0/104|
|sole_video_text|-0.002667|43.3333pp|-15.0000pp|72.5000pp|0/104|

text_video最大总增益+33.3333pp时MAE反而+0.613333、suc−20pp；video_text最大总增益+43.3333pp时suc−15pp，MAE仅−0.002667。因此不能以总准确率上升掩盖其他验收失败。这些是固定自身前六步与末步reasoning的201规范数字读出实验，不能推广为所有可能的SOLE全推理干预都无效。

最后两个输入审计：video_text的`completed_score_audit_20260909T165829.json`与text_video的`completed_score_audit_20260909T165602.json`均为2340/2340唯一有效支路、15000/15000唯一有效读出，无重复或科学冲突；observed/static zero各60/60精确。baseline规范格式总概率最小分别0.99988976/0.99987147；前者一条native/MAP差异（fail/ljx_lfz_task_5_1/10：7%/8%），后者无差异。五输入全部baseline的规范格式概率均>.99，不存在旧错误百分号token版本的低格式概率问题。最大概率约1+2.12e−7的浮点累加误差保留原值。

三项此前已完成的审计和110个text_image重复键处理继续有效：重复不计作独立样本，无原数据删除。第4模型在本轮数值对比家族中未取得稳定改良，应作为方法边界保留；三模型×三输入目标仍由冻结的Meter/Qwen/RR九项确认检验。

GPU2的SOLE text_video与GPU0的SOLE video_text数值任务及补充均正常结束，新Qwen text_video/video_text确认按预存资源计划自动启动。**主线1的SOLE interleaved/video_text完整七步attention还在运行**，数值screen完成不能替代这两项mandatory实验。


## 2026-09-09 17:41：剩余114补跑转GPU2与自动raw审计

GPU2的Qwen text_video确认/114均完成后，只剩其它程序约20.6GiB占用，四卡均A100-SXM4-80GB。保存`RESEARCH/cohort_gpu2_handoff_20260909T1740_v1/plan.json`及launch/events，核对/proc命令、cwd和空children后，仅停止原114等待父2039243与2039245；**没有中断RR/Meter/Qwen/SOLE任何正在推理的模型，也没有停止确认父2037992/2037994**。六个Meter/RR 114case均确认此前从未launch，全部仍使用原冻结manifest/YAML/ranking。原冻结推理文件SHA再次全部一致。

新Meter114上层父2081412，在GPU2依次运行image_text/text_video/video_text；新RR114上层父2081413，等Meter image_text114完成后在GPU2依次运行image_text/text_image/text_video，避免同时模型加载。每个队列仍逐项检查实时显存，实际模型PID见该目录events。无需等待同模型全部498确认完成才对固定114前向：样本集不交叉，参数已冻结，114性能不会用于选型。这样可在确认尚运行时提前补齐数据，并在Meter确认结束后让GPU3只执行SOLE full。Qwen image_text114仍在GPU1，video_text确认/114仍按原接管计划GPU0执行。

新增自动raw审计守护PID2081699：`RESEARCH/final_raw_audits_v1/{plan.json,launch.json,events.jsonl}`。对确认九项+remaining114九项共18个case，已有14份audit完成，剩余22份工程/重组合审计将在各case的真实completion/combination标记出现后逐项执行。没有标签选择，不跑新的神经前向；任何错误保留退出码且不会静默重试。

为复用既有守护，`run_completion_analyses.py`只增量添加可选`--plan-root`，默认行为相同；原PID2040764及原九任务plan没有重启或修改。该调度脚本不属于冻结推理21文件，也不属于被冻结的metrics/paired_analysis/analyze_development三个统计实现。最终仍需检查两个watcher均正常、收取全体确认与846、最终BASE；再手动生成macro、`summarize_frozen_report`全邻居补充及图表并查看图片。


### 接续检查点：2026-09-09 17:41:28

已完成6个case的individual_case_analysis_v1.json、completed_branch_engineering_audit_v1.json、completed_recombination_audit_v1.json、readable_supplement_v1.{json,md}。不需重新做这些单case分析。全体Holm仍等另外3case。

|case|point|strict original|IUT p|primary对native MAE变化|总pp|sucpp|failpp|
|---|---|---|---:|---:|---:|---:|---:|
|meter_image_text|True|True|0.000049998|-1.212856|+46.98795|+33.54430|+53.23529|
|meter_text_video|True|True|0.000049998|-0.533805|+45.78313|+32.27848|+52.05882|
|qwen_image_text|True|True|0.007999600|-0.606426|+35.54217|+11.39241|+46.76471|
|qwen_text_video|True|True|0.000049998|-0.475904|+34.33735|+25.31646|+38.52941|
|rr_image_text|True|True|0.121043948|-0.164659|+11.44578|+3.79747|+15.00000|
|rr_text_image|True|False|0.388080596|-0.622490|+30.92369|+1.89873|+44.41176|

RR text_image的重要限制：primary k48对开发选定original k24的MAE+.006024、总−4.41767pp，strict=False；不能换成确认更高的k56来消除失败。RR两项suc CI跨0。Meter text_video强native温度控制的总acc高于primary（tau16 54.8193% vs primary51.2048%），primary MAE更低；准确率收益含校准成分。它的pairwise负序11→23，Meter image_text负序0→7；不可说pairwise全面改善。详见主summary最新各case段。

新脚本summarize_frozen_report.py可处理单case report、全体cases、846 summary case_files；保留所有邻居、task-macro和task方向，final都要跑。confirmation 498实际覆盖27task，原始1213为34task；macro不补缺席task，不等于论文23subset Overall。

audit_score_recombination.py重算所有冻结raw→sweep，现有6case和Qwen text_video114均差异0；只是实际确定性离线组合复算，不是独立神经重跑。剩余由final_raw_audits_v1 watcher2081699自动完成。

正在执行的原始SOLE完整七步还剩video_text/interleaved。数值screen五输入已完成无通过，不能替代full。主线1必须等两full结束。目标仍active且尚未完成。


## 2026-09-09 17:58：数据分区实际task覆盖的完整核对

新增`frozen_cohort_completion_v1/partition_task_coverage_v1.json`，对冻结labels SHA核验后按原始ID统计：

|集合|样本|视频簇|实际有样本的task|
|---|---:|---:|---:|
|原始全量|1213|407|34|
|grounded全cohort|846|299|28|
|development|234|86|27|
|confirmation|498|179|27|
|ranking重叠remaining|114|34|8|

原始34task中，task3_5、task3_9、task4_4、task4_5、task5_5、task5_9没有进入grounded846；这个覆盖限制必须与846/1213的样本覆盖一起披露。开发集另外不含task2_3，确认集另外不含task3_2；两者虽各27task，任务集合不完全相同。remaining114只覆盖8task，完整逐task/suc/fail数量在JSON中。这里的task数量不等于独立视频数量。

此前“每项34task”的baseline macro表只适用于其明确列出的原始1213 baseline，不能扩展解释为grounded/attention/confirmation同样覆盖34task。最终846 task-macro的分母应为28，确认为27；缺席task不补零，也不通过删除表现差的task改变macro。该补充只核对数据覆盖，不触发改参、换case或修改原始分区。


## 2026-09-09 18:09：RR text_video冻结独立确认失败，不能宣布三模型×三输入通过

全部498推理/读出完成、zero与重复审计通过，但`confirmation_case_point_acceptance=False`，strict_original也为False。三个冻结邻居对两套baseline均满足四向/+10pp：相对native的k48/56/64总增益+15.66265/+11.44578/+13.25301pp，MAE变化−.728916/−.775100/−.769076，suc+3.79747/+3.79747/+4.43038pp，fail+21.17647/+15.00000/+17.35294pp。

**失败来自primary k56对same-k原方法的MAE。** 新方法MAE1.32730923695，original k56为1.32530120482，变化+.00200803213，即498条绝对误差总和多1；虽然总准确率比original高13.85542pp，仍未满足预先冻结的MAE严格下降条件。不能因为只差1分而改容差、换成k48/k64或只报告对native的正结果。k48/k64的same-k MAE分别下降.014056/.050201；这也不能替代要求三个冻结邻居都通过。

开发预先选定的original k40更严格对照同样失败：primary MAE+.018072、总准确率+12.248996pp，体现MAE/端点准确率权衡。primary保持k56，官方记录中的scope为**all_frames**；任何简写将其写成last_frame均以冻结YAML和真实condition `contrast_target_temporal_all_frames_b3_k56_lambda4`为准，不更改运行设置。

primary原生baseline→新方法：MAE2.102410→1.327309，总准确率19.8795%→31.3253%，suc62.6582%→66.4557%，fail0%→15%。同读出baseline准确率20.2811%、suc63.9241%，也单独过四向点门槛。成功类MAE由.683544增至.911392，因此不能把总MAE下降写成两类MAE均下降。

primary对native的95%视频簇区间（准确率单位为比例）为`{"mae": [-0.9127007198228129, -0.6365420546916335], "accuracy": [0.07889546351084813, 0.1512770137524558], "suc_accuracy": [-0.050314465408805034, 0.12804878048780488], "fail_accuracy": [0.1069364161849711, 0.195906432748538]}`；对两baseline的四向IUT p=.337733113，成功类改善不确定，九项Holm仍待最后Meter case。

原始支路15438/15438全部尝试，15410有效，无重复或科学冲突；各zero498精确，native/readout分数差6条。全部22866有效读出与42个预期错误传播精确复算，差异0。

当前完成8项，7项通过冻结point、1项失败；RR只有image_text/text_image两项通过point，其中text_image不胜开发选定原方法。**无论最后Meter结果如何，原九项方案都不能取得“独立确认三模型各三输入均通过冻结验收”的结论。** 原确认manifest、参数和所有失败永久保留；完整846的描述性汇总及SOLE mandatory全七步仍继续。后续新方案如使用已见过结果的498，只能明确标为确认后探索/重复使用验证集，不得冒称新的独立确认。


## 2026-09-09 18:16：确认后的新探索——加入原方法的完整评分分布参照

原九项冻结确认已经出现RR text_video的严格同k MAE失败；这些数据、参数、primary和验收不变，后续不会把新方案的结果回写为v1确认成功。按用户要求继续进行理论—实现—实验迭代，同时明确证据阶段：后续498只能叫重复使用验证集上的探索，不能叫新的独立确认。

提出并在计算本候选性能前保存`post_confirmation_anchor_development_v1/prospective_plan_v1.json`及源码SHA。令z_parent为原冻结区域/时间证据方案，z0为同读出无干预分布，z_original为相同k的原强bias分布，新增：

`z_anchor = z_parent + ρ (z_original − z0)`，`ρ∈{0,.25,.5,.75,1}`。

等价于原生分布与原方法分布在logit空间作凸组合，再施加原来的区域证据项；固定原η时，对全部评分档位有`p_anchor(j)∝p0(j)^(1−ρ) p_original(j)^ρ exp(ηD(j))`。该代数表达没有指定某个端点。对ρ的log概率导数是`(z_original−z0)_j−E_p(z_original−z0)`；它描述原方法提供的整体评分方向，不保证任何真值指标单调改善。原强bias可能保留更好的序数信息，也可能再次损害suc，因此两类、两baseline、原方法和整个k邻域仍需一起检验。分布代数可对照本轮已核实的ASCD/VCD机制背景，不能据此冒称独立校准的Bayes证据或引用文献证明本任务效果。

本轮仅在development234上运行：保留原九个模型/输入、每项三个k及中间primary，原radius/scope/gain/置信度/KL配置均不变；新增加的唯一变量是每case共用一个ρ。全部九项、所有五个ρ都保存，ρ0必须精确重现原父方案；先完成无标签评分组合，再join开发labels做评价。所有父sweep的SHA逐项核验，只读复用，不做新神经前向，不改冻结的21个推理文件和三个统计模块。

选型需所有三个k完整、对两baseline四向/+10pp、对同k原方法MAE/总准确率改良、全部邻居五档MAE下降，且primary胜开发预先选定的原方法。在合格ρ中先最大化最弱同k原方法MAE改良余量，再最大化最弱同k准确率余量，平局取较小ρ。**这是观察到v1确认失败后的开发决策，不是最初的预注册，也没有消除后来复用498的适应性偏差。** 当前计划已冻结并实际启动开发CPU组合，尚未宣称新方法成功。


## 2026-09-09 18:41：后续探索设置冻结，补充完整方案控制

开发234上的所有9case×5个ρ×3个k已完成；ρ0在9×3×234=6318个父方案读出上精确一致，全部新候选评分先无标签生成再分析。9项均存在满足该轮开发门槛的ρ；依预先保存的余量规则，选中：

|case|冻结ρ|原primary k（不变）|
|---|---:|---:|
|meter_image_text|1|68|
|meter_text_video|0|48|
|meter_video_text|1|64|
|qwen_image_text|0|40|
|qwen_text_video|0|48|
|qwen_video_text|0|68|
|rr_image_text|0|64|
|rr_text_image|.25|48|
|rr_text_video|.25|56|

开发的最弱same-k原方法MAE改良余量：Meter image_text由ρ0的.520877到ρ1的.524129，Meter video_text由.496034到.512527，RR text_image由.085470到ρ.25的.119658，RR text_video由.047009到.064103。所有ρ结果均在`post_confirmation_anchor_development_v1/{case}/development_analysis_v1.json`，包括RR text_video的ρ.75/1不合格；没有只保留获选行。

完整评估已经一次性冻结于`post_confirmation_anchor_evaluation_v1/frozen_manifest_v1.json`。守护PID2098349，目录`post_confirmation_anchor_evaluation_watcher_v1`，等全部原始9项确认与9项114完成后统一执行`anchor_evaluation.py`。它生成所有选中设置在development234、reused_validation498、ranking_overlap_remainder114上的评分，再统一join labels，分别报告三分区和full846；ρ不再调整。后续498明确为reused validation，不是新的独立确认，原v1失败不回写。

方法解释的两条新增边界：ρ>0时加入原强bias的响应，**只有对称证据支路保持局部视觉总量守恒，不能再把整个后续方案称为全部支路守恒**。一般情况下，父方案的KL预算也不约束额外加ρ项后的整体分布；实际选中带KL的Qwen video_text为ρ0，故其原.5预算保持原样。非零ρ部署时比父区域/时间方案各增加一条original-target模型前向，即区域4条、时间6条；ρ0仍为3/5条。

为了不把“固定正确目标anchor、仅换证据部分”的条件控制误当完整wrong/low控制，又前瞻冻结并启动`post_confirmation_anchor_whole_controls_v1/frozen_manifest_v1.json`。仅四个非零ρcase各498，5条真实支路：matched baseline duplicate、original-target duplicate、original-bias zero、original-bias wrong、original-bias low heads。GPU0父2101487运行Meter两项，GPU2父2101488运行RR两项。没有修改原冻结推理文件，21项SHA已再次核验相同。

分析协议`post_confirmation_anchor_whole_controls_v1/analysis_protocol_v1.json`要求新旧baseline/原target logits与progress精确一致，original-bias zero精确，全target组合重现主评估、全zero重现baseline。结合已保存的父wrong/low证据，可以同时替换两部分为错误区域或低heads，构成完整方案控制；几何不可行按明确子集比较，不删主方法样本。新原始支路及组合审计8项，加全方案分析1项，守护PID2103136，目录`post_confirmation_anchor_whole_control_analyses_v1`。若任何parity失败，保存工程记录并不计算其效应解释。

截至本记录，原114九项全部已完成；原确认仅Meter video_text尚在运行（18:38约371/498），SOLE interleaved/video_text完整七步仍未结束。新方案的完整评估尚未运行，不声称通过最终目标。


## 2026-09-09 18:51 接续：最后汇总工具与控制完成

四组非零ρ完整控制全部完成，八份raw/重组合审计退出码均0。尚待原Meter video_text确认结束后的统一anchor评估和whole-method parity/效果分析，不能提前宣称新方案成功。原确认约441/498；mandatory SOLE两全七步继续，无停止或迁移。

新建`summarize_anchor_report.py`：只导出冻结anchor所有九项、全部三个k与四个partition的描述性补充，包含连续/五档MAE、两阈值、任务macro/方向、分布和配对；不修改冻结分析/推理源码。最终以`--source <anchor summary_v1.json> --output <新的readable_supplement_v1.json>`执行。

另新建`audit_added_record_consistency.py --output <新的BASE JSON>`，仅在两个mandatory full完成后运行，逐文件核验正式baseline/full/terminal的原始行、唯一键、重复科学字段和SHA；不读标签，不删除重复，不替代原zero/full统计审计。两个新工具已编译，实际全量运行待相应输入结束。最终还需BASE/原确认/原846/anchor的task_macro_summary、原九项确认PNG/SVG并view_image、最终综合文档。


## 2026-09-09 19:40 接续：主线3观测门槛已达，剩余主线1

**不要再调参，最终观测方案已固定。整体goal仍active，不能在两项SOLE mandatory结束前complete。**

最终方法：`RESEARCH/shared_entropy_evaluation_v1/frozen_manifest_v1.json`，summary同目录；全部9case×3k在development234、reused_validation498和full_cohort846均point=True且strict_original=True。114单分区仍有RR等失败，不能删它；全846描述性、498为已复用验证，无新的独立确认。原v1确认失败永久False。

最终postprocess：`z0+s h^β(z_parent−z0)+ρ(z_original_same_k−z0)`，h=normalized entropy of native full bins。所有旧primary/k/scope/半径及parentλ/q/KL不变。Meter image_text/video_text s1 β0 ρ1；Meter text_video和Qwen三个输入s1 β0 ρ0；RR image_text s1 β.5 ρ0，RR text_image s4 β.5 ρ.25，RR text_video s4 β.5 ρ0。RoboReward共用β.5由原234开发候选按最弱协议余量选择，选择规则是在上一轮失败后提出，必须如实披露适应性探索。

阶段输出已全部关闭：
- 原确认：`confirmation_v1/confirmation_analysis_20260909T190153.json`。8/9 point，只有Meter/Qwen各3输入；RR text_video失败，RR text_image strict=False。Holm：Meter3项与Qwen text_video=.0004499775；Qwen video_text=.0007499625；Qwen image_text=.0319984001；RR image_text=.3631318434，另两项=.6754662267。
- 原846：`frozen_cohort_completion_v1/full_cohort_analysis_20260909T190156/summary.json`。8/9 point，RR image_text k60总+9.21986pp失败；RR text_video此处通过不覆盖确认失败。
- anchor v1：`post_confirmation_anchor_evaluation_v1/summary_v1.json`。498 point9/9但strict7/9；846 point7/9。完整新神经controls4项，全部parity通过。
- entropy独立输入选型v1：`entropy_evidence_evaluation_v1/summary_v1.json`。498/846均point8/9且strict8/9，RR text_video s4β0ρ0损害suc失败。原64参数×三个RRcase，生成139k左右记录；全部保存。
- shared entropy最终：`shared_entropy_evaluation_v1/summary_v1.json`。上述3分区均9/9point/strict；`shared_entropy_whole_controls_v1/analysis_v1.json`九项target/zero精确，wrong/low使用已审计真实神经支路组合，不是又跑九项神经。其watcher`shared_entropy_completion_watcher_v1/events.jsonl`的evaluation和controls都exit0，PID2128397已结束。

最终共享controls重要边界：RR image_text正确区域vswrong总+11.8474pp但suc−1/158；RR text_video vswrong总−13.2231pp、fail−37.8698pp，但MAE更低/suc更高。不能宣称正确区域全面支配wrong。所有可行子集与错误均保留。

图/补充全部已生成并view_image：原确认新版`confirmation_v1/figures_20260909T190421/primary_effects.{png,svg}`（早一版图例遮挡末行已保留）；anchor图`...anchor_evaluation_v1/figures_20260909T190347/`；entropy图`entropy_evidence_evaluation_v1/figures_20260909T192517/`；最终图`shared_entropy_evaluation_v1/figures_20260909T192735/`。后三图文件名`all_selected_neighbor_effects.{png,svg}`，只有观测点、没有CI。四个主结果都已有`all_nine_readable_supplement_v1.{json,md}`与`all_nine_task_macro_v1.json`，原846在其timestamp子目录；不用重做。

新增不改原数据/冻结源码：
- `summarize_anchor_report.py`、`render_anchor_report.py`支持optional parameters，适用anchor/entropy/shared；格式化工具未冻结，不改推理。
- `entropy_development.py` / `entropy_evaluation.py` / `entropy_whole_controls.py` / `shared_entropy_followup.py`。**这些在最终manifest中已SHA冻结，不改。** shared wrapper只换新输出根复用旧分析函数，旧版本文件不动。
- `audit_added_record_consistency.py`：final baseline raw duplicate/scientific audit，已新建守护PID2132803，`RESEARCH/final_baseline_record_audit_watcher_v1`，等两SOLE full结束，目标`BASE/final_record_consistency_audit_v1.json`。目前待执行。
- 原18确认/114case raw audit全部结束，36份汇总`final_raw_audits_v1/all_eighteen_case_audit_index_v1.json`，全部组合精确/冲突0。

最终配方：九个新增YAML `mydata_bench/configs/v2_crossmodel/addbase_shared_entropy_final_v1_*.yaml`；`shared_entropy_evaluation_v1/final_recipe_registry_v1.json`。它们是完整方法recipe，明确引用真实parent神经配置，不能直接当score_branches runner输入。

最终直接算术验收：`shared_entropy_evaluation_v1/direct_final_acceptance_audit_v1.json`，不用任何性能容差，全部81个分区×邻居点通过；846最小总/suc增益14.1844/2.2388pp，498为13.6546/1.8987pp。`shared_entropy_evaluation_v1/algebraic_invariance_audit_v1.json`复用8个参数未变case的已验证结果，并新测shared RR text_video234向量；最大置换浮点误差3.33955e−13，exact zero/parent nesting全通过。方法报告此前2.77e−13属于entropy v1旧参数测试，最终总报告请用3.34e−13或说明两者来源。

文档已追加根auto-explore、主summary、研究日志、理论、统计、需求证据、复现指南。新独立文档：`FROZEN_AND_ANCHOR_RESULTS_20260909T1908.md`（原确认/846/anchor关闭报告）；`SHARED_ENTROPY_RESULT_20260909T1932.md`（最终观测方法、全9数值、控制与边界）。root最终方案位置已更新“观测门槛已达、主线1收尾中”。

最后必须继续：
1. 等SOLE video_text/interleaved两full真实结束（仍parent1980506/1980507，model1980518/1984884，GPU3/1）。19:37两者已完成offset640全部条件，并进入offset704 baseline。约还有两个64+一个14批次的其余条件，预计还需约1小时以上。native dynamic、batch64、preload indices；无停止或迁移。
2. 原守护2040764 `completion_analyses_v1`已7/9任务exit0，仅等待final attention audit和BASE metrics。收取其最终snapshot，再运行新BASE task_macro（最终baseline macro尚未做）。收取新record audit watcher2132803最终退出码/JSON。
3. 在结果全齐之后，新增清晰自洽的最终研究总报告与baseline summary最终段；纳入10个native baseline、Meter5×846×10、SOLE5 full/terminal×846×11、格式失败、zero/trace、top8及8/32/64重合、模型/输入边界、最终方法、原独立确认失败与新探索成功的区别。最后才可标goal complete。
4. 可补充最终postprocess模块消融（固定最终参数，比较去熵/去额外倍数/去原方法anchor）以加强归因；目前尚未生成此新协议或执行，不能写已做。现有parent/whole/conditional controls已完整，若做消融不得再次调参。


## 2026-09-09 20:22 接续：主方法不再调参，最后SOLE等待与报告工具就绪

本段承接19:40。任务仍active，不能提前complete；没有subagents，不进行git，所有exec cwd=/home/dais/workspace/Robo-Dopamine-addbase、login:false。两个mandatory SOLE model1980518/1984884及watcher2040764/2132803持续存活；20:20左右两者都进入offset768的low_rank_k8。前768条全部11条件已完成，当前64条还在推进，之后最后14条。不能用终步替代，不迁移/终止它们。

新增已完成：
- `final_postprocess_ablations.py`已exit0，结果`RESEARCH/final_postprocess_ablations_v1/analysis_v1.json`。九项846重算精确，消融权衡文档`FINAL_POSTPROCESS_ABLATIONS_20260909T1948.md`已追加主summary/理论/日志。
- `final_descriptive_tables.py`已exit0，`RESEARCH/final_descriptive_tables_v1/{report.md,report.json,per_task_split_metrics.csv,task_effects.png/svg}`。CSV1980行，图已view_image。full846各task宏均改善，但RR image_text10/28task MAE变差；Meter三输入配对负序3→15、23→30、0→57，所有平均gap增加不等于排序全面改善。20:00追加了总结/日志；初始标题误写20:08，已立即追加时间更正保留旧段。
- `audit_final_frozen_lineage.py`已实际exit0，`shared_entropy_evaluation_v1/final_frozen_lineage_audit_v1.json`：173检查、21原冻结推理文件、全部输入/分区/实际配置/ranking/父sweep/开发评分/九最终recipe及whole控制来源均匹配。首版误断言control-inclusive invalid_rows=0失败；保存`final_frozen_lineage_audit_engineering_attempt_v1.json`及首版源码SHA。修正报告检查为保留已知几何失败并单独核验主方法全部完整，未改冻结代码或数据。

**重要新限制必须进入最终报告：两阈值不是都四向通过。** 新增`shared_entropy_evaluation_v1/secondary_threshold_descriptive_audit_v1.json`保留Meter3输入×3k×4分区×2baseline。预定主验收是.125/.875，仍全部通过；.2/.8的Meter text_video在full846 primary suc为58.9552%→44.0299%（−14.9254pp），重复498为56.3291%→44.9367%（−11.3924pp）。全3k均有成功类损失，总/fail仍提高；其它两个Meter输入在此阈值双类提高。不能称两套阈值均达标或阈值无关稳定。该第二阈值按计划属完整敏感性报告，不在见结果后改变已冻结主门槛。此说明已追加root计划、主summary、统计、共享熵文档、需求证据和日志。

新准备但尚未实际运行（只编译，不可写已产出）：
1. `final_added_baseline_report.py --metrics FINAL_METRICS --attention-audit FINAL_ATTENTION_AUDIT --record-audit BASE/final_record_consistency_audit_v1.json --macro FINAL_MACRO --head-overlap BASE/all_four_models_head_overlap_v1.json --output NEW_DIR`。先assert15attention实验全部846尝试、SOLEzero原生/trace精确、记录冲突0、10native各1213、macro180。输出全10native+各组baseline/target表、180组全部task/split两MAE/两阈值分布CSV、180pairwise CSV、45target效应CSV、20top8、30跨模型head交集及source manifest。含全部147490唯一主记录预期说明（不含traces）。输出目录必须不存在。
2. `render_added_final.py --report-root NEW_DIR`。根据45target CSV生成`figures/all_target_effects.png/svg`及来源。15行（Meter5、SOLEfull5、SOLEterminal5）×3k×4指标红/蓝热图；运行后须view_image。
3. `final_completion_audit.py --baseline-report NEW_DIR --research-report FINAL_MD`。等所有文档/图产出再运行；检查两个mandatory watcher全部任务exit0、baseline清单、最终主门槛/控制/消融/18raw/173来源、原独立确认仍False、第二阈值Metertext_video suc仍False，输出`RESEARCH/final_completion_audit_v1.json`。它只确认预定主指标的观测范围，不宣称独立泛化、两阈值所有类、所有task或四模型通过。

两SOLE结束后明确顺序：
- 收取原`completion_analyses_v1`最后两任务日志中的FINAL_METRICS/FINAL_ATTENTION_AUDIT路径与returncode0；另等`final_baseline_record_audit_watcher_v1`记录审计exit0。
- `task_macro_summary --sources FINAL_METRICS --output BASE/task_macro_final_v1.json`（文件不存在）；应180组。
- 运行上述最终baseline报告器，建议output `BASE/final_added_baseline_report_v1`；如报错先查明并保存工程记录，不隐去/静默重试。
- 运行render_added_final并viewimage。
- 新增独立可读最终总报告（例如`mydata_bench/auto_research_addbase/FINAL_RESEARCH_REPORT_20260909.md`），追加主summary完整baseline最终表/root最终方案/需求/复现。别让用户只读历史“尚未完成”。
- 最后completion audit通过才update_goal complete。最终中文答复给总报告与baseline总结链接，说明三模型×三输入在主指标观测达标、独立验证未证明、第二阈值有权衡。

所有最终参数及其它关键文件、原确认失败、官方输入和SOLE数值screen边界仍以19:40段及SHARED_ENTROPY文档为准。


## 2026-09-09 21:09：全部主线完成，最终交付已核验

SOLE interleaved20:55:40、video_text20:58:16均完成846×11；两mandatory模型与父已退出。completion_analyses全部9任务exit0、record watcher任务exit0，两watcher_completed。最终attention snapshot205847、metrics snapshot205912、final_record_consistency_audit_v1均已完成；40文件561517条、0重复/冲突，147490主预测含437错误保留。最后兩full zero846/846与5922步各精确。

task_macro_final_v1.json180组；final_added_baseline_report_v1生成15840指标行、180配对、45target点（原attention全部0/15通过），PNG/SVG已view_image且正常。FINAL_RESEARCH_REPORT_20260909.md独立总报告已写好；根auto-explore、根baseline计划、主summary、需求、日志、统计、复现指南均追加最终状态。

final_completion_audit_v1.json已实际exit0，主线1/2/预定主指标观测验收均True；独立泛化、两套阈值全类提升、四模型/全部任务/全部排序改善均保持False。最终报告28个本地链接全部有效，完成审计列出的10个交付文件SHA再次核验通过（精确数量以工具与JSON为准）。没有本轮推理/调度进程继续运行。可以据真实已完成结果标goal complete，不要重启、调参或覆盖任何数据。
