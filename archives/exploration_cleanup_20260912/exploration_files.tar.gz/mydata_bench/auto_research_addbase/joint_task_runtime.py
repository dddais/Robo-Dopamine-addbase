"""F4 runtime: jointly retain instruction and visual target in selected heads."""
from .score_branches import ScoreRuntime
from .joint_task_attention import task_token_positions, joint_task_steering
from mydata_bench.attention_eval.masking import matched_wrong_position_set


class JointTaskRuntime(ScoreRuntime):
    def prepare(self, sample, media_condition='observed'):
        prepared = super().prepare(sample, media_condition)
        positions, audit = task_token_positions(self.runtime.processor.tokenizer,
            prepared['inputs']['input_ids'][0].tolist(), sample['task'],
            self.config['model'], self.config['protocol'])
        visual = {p for span in prepared['spans'] for p in range(span.start, span.end)}
        if visual & set(positions):
            raise ValueError('Task span overlapped visual keys')
        prepared.update(task_positions=positions, task_alignment_audit=audit)
        return prepared

    def predict(self, sample, prepared, condition, heads):
        if condition.get('kind') not in ['joint_task_region', 'task_only']:
            return super().predict(sample, prepared, condition, heads)
        target, alignment = self.runtime.positions(sample, prepared, 'all_frames')
        if condition.get('region') == 'wrong':
            wrong = []
            for span in prepared['spans']:
                local = [p for p in target if span.start <= p < span.end]
                if not local:
                    continue
                selected = matched_wrong_position_set(span, local, spatial_merge_size=2)
                if selected is None:
                    raise ValueError('No equal-area disjoint same-frame wrong control')
                wrong.extend(selected)
            target = wrong
        visual = [p for span in prepared['spans'] for p in range(span.start, span.end)]
        diag = {}
        with joint_task_steering(self.runtime.layers, heads, target, visual, prepared['task_positions'],
                                 condition['bias'], condition['kind'] == 'task_only', diag):
            result = super().predict(sample, prepared, {}, [])
        result.update(hook_diagnostics=diag, tracking_alignment=alignment,
                      task_alignment_audit=prepared['task_alignment_audit'],
                      engine='joint_task_region_native_residual_v1')
        return result
