# Robust research checkpoint — 2026-09-10 01:34 Asia/Shanghai

The active goal remains unachieved. This turn is **progress**: completed F1 full15 analysis and F5 RR full5 negative results, prepared new supervised training data with actual overlap quarantine, implemented gradient head selection, passed real gradient engineering on all3 models, and launched durable preparation/fitting queues. Do not mark complete/blocked.

## Rules and entry points

Only `/home/dais/workspace/Robo-Dopamine-addbase` (physical `/mnt/public1/dais/workspace/Robo-Dopamine-addbase`), explicit cwd and login:false on execs. No git, no reading other local code repositories, no deleting/overwriting old results, no modifying frozen source/config files. No subagents or permission questions. Python `/home/dais/miniconda3/envs/robo-dopamine/bin/python`; SAM3 `/home/dais/miniconda3/envs/rewardbench-sam3/bin/python`. academic-research-suite already used inline. Chinese updates.

R=`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1`.
CODE=`mydata_bench/auto_research_addbase`.
Previous detailed checkpoint: `ROBUST_CHECKPOINT_20260910T0054.md`.
Full protocol: `ROBUST_RESEARCH_PROTOCOL_20260909.md` (F6 and media audit appended this turn).
New readable progress report: `ROBUST_PROGRESS_20260910T0132.md` (its initial “audit running” status was superseded by an explicit appended completion update).
Old shared-entropy/anchor cannot count as success; old846 all development/descriptive. No reserved external reward-model inference/performance has been opened.

## F1–F5 outcome updates

- F1 all15 full234 completed and analyzed, all whole-case FAIL, zero all exact. All F1 GPU queues terminal failures[]. Latest analysis `f1_frame_transport_analysis_2026-09-09T172443.406728_0000.json`.
- F2 latest analyzed9, all whole-case FAIL: RR5, Qwen text_video/video_text/text_image, Meter text_video. Meter primary accuracy+7.6923pp insufficient; Qwen successes/failures trade off. Latest `f2_frame_transport_analysis_2026-09-09T172444.229651_0000.json`.
- F3 and F4 RR5 done, all whole-case fail. Other models continue unchanged.
- F5 RR5 done, all whole-case fail; all primary MAEs WORSE. Latest `f5_frame_transport_analysis_2026-09-09T171932.281859_0000.json`. Do not rescue it with an added gain or endpoint rule. F5 GPU0/3 queues now terminal failures[]. Qwen/Meter remain behind earlier family queues.
- `robust_analyze.py` now accepts f1–f6; f6 maps to `reward_gradient_development_v1` and reports extra raw_readout/learned_positive controls. Do not call f6 analysis before its result root exists.

## External test preparation, still no model test performance

EXT=`R/external_roboreward_reserved_v1` remains full2831, inputs_without_labels_v4.jsonl, labels unchanged.1172 conservative episode groups,2551 byte hashes. Old/test exact+three-frame sparse overlap0. Cannot prove all training contamination absent.

Parser1043 tasks finished at16:56:58UTC,0runtime errors, SHA `656a4ccfa5ebf6d24352db57459f610233071678532379f92ab845f837af6dc3`. PID2302973 terminal; do not restart.
Grounder PID2309556 actually running onGPU3; first5 real external tracks verified all8 frames. Evidence `R/external_grounding_real_preflight_20260910T0100_v1.json` (old engineer test also passed). Latest count is in snapshot below; no runtime errors observed. Unsupported/missing/incomplete tracks keep baseline fallback on full2831 denominator. Grounded fields never used to assign reward endpoints. Monitor actual process and completion instead of restarting.

## New F6 — supervised signed reward-gradient head selection

This is **supervised auxiliary head selection**, not training-free. The backbone weights are entirely frozen. It uses a separate official TRAIN source, never old234 labels or reserved TEST labels to fit heads.

Mechanism:
- For each head in layers8+, add b_h to ROI visual keys and -b_h to other visual keys ONLY at the actual reward readout query. Other query/head outputs are untouched by the local hook under its current Q/K/V; this is not a claim that later layers equal a separate unmodified network.
- At b=0, measure gradient of supervised native grade loss. Qwen/RR: five-choice CE; Meter: adjacent native ten-bin soft targets for the supplied1–5 grade. All middle grades retained.
- Average gradients within training episode/byte/pixel connected groups, then equally across groups. No-ROI rows contribute zero because the deployed method uses baseline fallback there. Actual gradient runtime errors invalidate that case; never drop them to select heads.
- rank score `abs(mean_gradient)-1.96*SE_episode`; inference direction `-sign(mean_gradient)`. 1.96 is a fixed ranking variability penalty, NOT simultaneous confidence coverage. First8 layers excluded.
- Shared inference magnitude1, k32/48/64, primary48, all_frames, actual reward query. Native readout, no output gain/entropy/KL/anchor/endpoints. Finite b1 may not follow the local gradient benefit; validation is essential.

Primary source reference downloaded/read: Michel, Levy & Neubig2019 arXiv1905.10650, subsection4.1 uses E|dL/dhead_mask| for pruning. Our signed ROI-bias gradient is a different adaptation. Files `R/references_v1/michel_2019_head_importance_html_v1.{html,txt,source.json}`. First local bs4 import failed before downloading; standard-library HTMLParser then succeeded HTTP200 and exact method text was read. No claim of reproducing pruning.

Implemented files:
- `reward_gradient_attention.py`: differentiable native SDPA residual, per-head signed ROI bias at explicit score query, native_grade_loss.
- `reward_gradient_ranking.py`: grouped gradient summary/order/sign.
- `reward_gradient_engineering.py`: real model gradient plumbing using two OLD engineer examples and synthetic grade3 ONLY; does not fit a scientific ranking or use their true labels.
- `reward_gradient_fit.py`: fitting-only runner, complete unique fit IDs, dedicated fit labels, frozen weights, all failures retained.
- `freeze_reward_gradient_fit.py`: creates full fifteen fit configs after no-label training media prep, before any fit result.
- `reward_gradient_training_queue.py`: live waiter, then freeze and run15 fit cases onGPU0/GPU3.

Four meaningful CPU tests passed: kernel zero/locality/gradient-vs-finite-difference + all grade targets, signed direction/group averaging + missing-row rejection/no-ROI zero. Tests files `test_reward_gradient_attention.py`, `test_reward_gradient_ranking.py`.
Actual model engineering passed RR image_text, Qwen text_video, Meter official text_image, two examples each. Zero inference/cache/gradient-forward logits exact;896 finite nonzero gradients, first8zero, all backbone parameters frozen,28 hook calls. Peaks approx19.4/18.4/14.3GiB. Stored under `R/reward_gradient_engineering_v1/{case}/engineering_audit_v1.json`. All engineer processes finished, no training outcomes yet.

Already prepared but **not yet frozen/executed** downstream development code:
- `reward_gradient_runtime.py`: learned signed inference, optional positive-only control, exact zero.
- `reward_gradient_development.py`: adapted existing F4 runner for old234, cached F1 native/original references and real2-example engineering gate.
- `freeze_reward_gradient_development.py`: after ALL15 successful fits, records learned ranking hashes and old234 configs.13 conditions: two baselines, original3k/new3k, wholezero/wrong/low, raw-mass readout-b1-k48, learned-rank positive-only-k48. Do not run until fits complete.
- Independent TRAIN-validation inference/analysis is STILL TO IMPLEMENT. No F6 development scheduler has been launched; the fit queue deliberately stops after fitting. Keep validation separate from fit, no head ranking changes from validation labels.

## Separate public training source and audit

TRAIN=`R/external_training_research_v1`.
Pinned revision same official repo `469b9af76e8539e8d2ac553b081307738fd92ca5`, split=train. `train_metadata_v1.jsonl`45072 rows,10168 source episodes;29 source subsets. Original official labels1–5 all retained. These may already be backbone training examples (especially RoboReward); do not call them unseen by the backbone. Reserved test still not used for our fit/selection.

`prepare_external_head_training.py` selected max20 source episodes/subset by fixed salted SHA, first floor(n/5), min1, validation; remainingfit. All selected episode rows retained. Not label stratified. Selected2509 rows,568 source groups:455fit/113validation. Source-ID comparison with reserved test had0 matches.

`download_external_head_training.py`: all2509 file download attempts complete;13 SSL failures after3 attempts kept,2496 rows ready;1705 unique downloaded byte hashes. FFprobe actual counts plus TWO OpenCV sequential decodes and exact first/last8 sampling;0 decode errors. Do not silently retry/overwrite or change current frozen cohort to replace failures. Media completion `media_preparation_completion_v1.json` at17:28:35UTC. DownloaderPID2322843 terminal.

`audit_external_head_training.py`: completed17:30:04UTC, references2958 unique old/test videos.21 sparse near-match records to reserved test,0 exact reported;14 whole source/content groups quarantined (61rows) plus13 unavailable-media rows. No fit/validation exact cross-group overlap. All2509 rows retained in audit file. Eligible2435:1942fit,493validation; group counts in snapshot below. Crucially no test samples excluded/changed and no labels/model scores used in quarantine.
- `training_inputs_audited_v1.jsonl` SHA `ce0f80491c2263e25c213d1763a8db0a06266dee2aa78e261f54ac679ad03284`.
- `media_overlap_audit_v1.json` includes all flags and eligibility counts.

Training preparation files (captured source hashes, DO NOT EDIT while live):
- `parse_external_head_training.py`: copy of verified parser using eligible training rows only, no labels;1072 unique tasks. Currently running GPU0 PID2425817, first25 parsed0errors at17:31:43UTC. Uses `TRAIN/parse_external_head_training_stdout_v1.log`, `grounding_v1/parser_plan_v1.json`, parsed records/completion.
- `ground_external_head_training.py`: copy of exact8-frame SAM3 grounder for eligible training rows only. Will launch automatically after parser. Unsupported/missing ROI → baseline fallback; quarantined rows never enter grounder but remain in audited input. Uses train OUT, not test OUT.
- `external_head_training_queue.py`: live PID2337640. Overlap stage succeeded, parser nowrunning, grounder pending. GPU0, free memory>=30GB before GPU stages. Captured hashes in `TRAIN/preparation_queue_plan_v1.json`. Events `preparation_queue_events_v1.jsonl`. Own parser launch used by later grounder.

F6 fitting queue PID2357092 alive, waiting for verified training preparation queue completion. Manifest `R/f6_fit_queue_launch_v1.json`, plan `R/f6_fit_queue_plan_v1.json` captures source hashes. After preparation it runs `freeze_reward_gradient_fit` to create dedicated fit/validation IDs and label files, verifies exact separation and all3 engineer audits, freezes15 configs (`addbase_robust_reward_gradient_fit_v1_*.yaml`), then:
- GPU0: RRfive + Qwen text_video/video_text/text_image.
- GPU3: Meterfive + Qwen image_text/interleaved.
Free memory>=32GB before each model. No changes to model weights or reserved test performance. Expected fitting outputs `R/reward_gradient_v1/{case}/fit/{gradient_records_v1.jsonl,ranking_v1.json,completion_v1.json}`.

These fit sources are already captured by live waiter and must not be modified: reward_gradient_attention.py, reward_gradient_fit.py, reward_gradient_ranking.py, reward_gradient_engineering.py, freeze_reward_gradient_fit.py. Source audit `R/f6_pending_sources_audit_20260910T0130_v1.json` passed8 declared dependencies. Fixes require a justified new version and preserving originals, with careful management of verified own jobs.

## Process reminders and next actions

Always revalidate /proc and queue events/completions; PIDs are historical. F1 queues allfinished. F2–F5 GPU0/3 allfinished. F2–F5 GPU1/2 continue; old PIDs in snapshot below. Foreign Robo-Dopamine GPU processes exist; do not inspect code or stop them.

1. Monitor training parser/current grounder and external test grounder. Check correct paths and first real training grounding results; no reward labels/test performance.
2. Analyze newly finished F2–F5 model cases; whole-case failures retained. F1 all15 alreadyfinal negative, no needrepeat itsanalysis withoutnewdata.
3. Finish F6 independent training-validation inference + metrics/uncertainty and scheduler, preserving planned sharedb1/k32,48,64. Freeze inference implementation and learned ranking hashes before validation/development. Old234/846 are descriptive; don't turn old498 into a holdout.
4. When F6 fitting starts, inspect actual gradient records and successful ranking/completion. A synthetic grade3 engineering pass does not prove real supervision works or improve metrics.
5. If F6 fails, continue theory-driven changes using fit/development, never tune on reserved test. If a candidate passes, finalize full846 descriptions and once-only external model inference/label join with1172groups, allgrades, fallback/coverage and strongest original controls.
6. Goal remains active and incomplete. No pending exec sessions from this turn; only durable processes. Do not markcomplete orblocked based on waiting or difficulty.

## Authoritative observation snapshot

```json
{
  "time": "2026-09-09T17:35:16.397693+00:00",
  "completed_cases": {
    "f1": 15,
    "f2": 10,
    "f3": 5,
    "f4": 5,
    "f5": 5
  },
  "external_grounding_rows": 1949,
  "external_grounding_statuses": {
    "ok": 1243,
    "baseline_fallback": 706
  },
  "external_grounding_runtime_errors": 0,
  "training_episode_groups": {
    "fit": 446,
    "validation": 108
  },
  "processes": {
    "2235606": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.frame_transport_vcd_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
    "2235607": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.frame_transport_vcd_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
    "2304131": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.specificity_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
    "2304132": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.specificity_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
    "2308875": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.joint_task_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
    "2308876": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.joint_task_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
    "2312042": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.task_interaction_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
    "2312043": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.task_interaction_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
    "2309556": "/home/dais/miniconda3/envs/rewardbench-sam3/bin/python -u -m mydata_bench.auto_research_addbase.robust_external_ground ",
    "2337640": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.external_head_training_queue ",
    "2425817": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.parse_external_head_training ",
    "2357092": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.reward_gradient_training_queue "
  },
  "goal_complete": false,
  "new_test_performance_opened": false
}
```
