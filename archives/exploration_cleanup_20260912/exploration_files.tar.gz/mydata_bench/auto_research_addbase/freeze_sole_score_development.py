"""Extend the same region/temporal score contrasts to SOLE's native numbers."""
import argparse,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--version',default='v2');a=p.parse_args()
    root=RESEARCH/f'sole_score_development_{a.version}';template=yaml.safe_load((ROOT/'mydata_bench/configs/v2_crossmodel/addbase_score_temporal_development_v1_qwen_text_image.yaml').read_text());plans=[]
    for protocol in ['image_text','text_image','interleaved','video_text','text_video']:
        cfg=yaml.safe_load((ROOT/f'mydata_bench/configs/v2_crossmodel_addbase/sole_{protocol}_v1.yaml').read_text());out=root/f'sole_{protocol}'
        cfg.update(output_dir=str(out),stage='prospectively_frozen_sole_native_integer_score_development',
                   example_ids_file=template['example_ids_file'],branch_conditions=template['branch_conditions'],conditions=template['conditions'],
                   baseline_context_path=str(BASE/f'sole_{protocol}_v1/baseline.jsonl'),attention_engine='native_residual',
                   hypothesis='Apply the same symmetric regional and temporal contrast to every native signed integer progress answer, while holding each example own native preceding history and reasoning text fixed.',
                   native_score_contract='All201 integer percentages -100..100, token-trie joint likelihood through canonical fused percent/end-tag delimiter, and MAP; no endpoint-only choices, clipping or forced first/last score.',
                   intervention_schedule='terminal_answer_distribution_with_fixed_native_history_and_reasoning',
                   selection_rule='Require all234 development and confirmation strict MAE reduction, suc/fail increase and total+10pp versus both native generation and same integer-score readout baseline; superiority to original steering; stable neighboring k.',
                   native_baseline_control='Native full seven-step result is retained alongside reconstructed numeric likelihood baseline; changed readouts are audited, never credited as steering improvement.')
        path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_sole_score_development_{a.version}_{protocol}.yaml'
        with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
        create_json(out/'ranking.json',json.loads((BASE/f'sole_{protocol}_v1/ranking.json').read_text()))
        create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':cfg['hypothesis'],'config':cfg,'config_sha256':fingerprint(cfg),'confirmation_new_method_metrics_used':False})
        plans.append(str(path))
    create_json(root/'prospective_plan.json',{'time':timestamp(),'configs':plans,'sample_phase':'same frozen development60/24 video groups','native_integer_choices':201,'mainline_full_seven_step_attention':'separate mandatory experiment; this new terminal-distribution candidate does not replace it'})
    print(root,'5 inputs including official montage;201 native integer values')


if __name__=='__main__':main()
