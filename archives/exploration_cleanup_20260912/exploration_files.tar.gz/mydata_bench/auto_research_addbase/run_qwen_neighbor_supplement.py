"""Prospective local k neighborhood around the successful k64 development point."""
import argparse,subprocess,time,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);a=p.parse_args()
    log=RESEARCH/'qwen_k64_neighbor_supplement_queue_v1.jsonl'
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(a.gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    for protocol in ['image_text','video_text']:
        cfgpath=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_full_development_v1_qwen_{protocol}.yaml'
        cfg=yaml.safe_load(cfgpath.read_text());out=pathlib.Path(cfg['output_dir']);supppath=out/'k64_local_neighborhood_supplement_v1.json'
        if not supppath.exists():
            branches=[];recipes=[]
            for k in [56,60,68,72]:
                branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
                prefix=f'target_last_frame_b3_k{k}'
                for sign,bias in [('plus',3.),('minus',-3.)]:branches.append({'name':prefix+'_'+sign,'k':k,'kind':'visual_preserve','bias':bias,'scope':'last_frame'})
                for weight in [2.,3.,4.]:recipes.append({'name':f'contrast_{prefix}_lambda{weight:g}','k':k,'contrast_weight':weight,'scope':'last_frame','region':'target','source_branches':['baseline',prefix+'_plus',prefix+'_minus']})
            recipes=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes
            supplement={'time':timestamp(),'reason':'All234 development has a successful k64 point but sparse neighboring k coverage. Test56/60/68/72 prospectively to assess a local interval; no confirmation used.','branch_conditions':branches,'conditions':recipes}
            create_json(supppath,supplement);append(out/'analysis_supplements.jsonl',{'time':timestamp(),'path':str(supppath),'sha256':fingerprint(supplement)})
        while int(subprocess.check_output(['nvidia-smi',f'--id={a.gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())<34000:time.sleep(20)
        commands=[['score_branches','--config',str(cfgpath),'--supplement',str(supppath)],['combine_scores','--folder',str(out),'--supplement',str(supppath)]]
        for args in commands:
            command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.'+args[0]]+args[1:]
            append(log,{'time':timestamp(),'event':'launch','command':command})
            with (out/'k64_neighbor_supplement_v1.log').open('a') as f:proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT);code=proc.wait()
            append(log,{'time':timestamp(),'event':'exit','pid':proc.pid,'returncode':code})
            if code:raise RuntimeError('Supplement process failed')
    append(log,{'time':timestamp(),'event':'queue_completed'})


if __name__=='__main__':main()
