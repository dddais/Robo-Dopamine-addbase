"""Frozen follow-up evaluation; validation498 is explicitly reused, not independent."""
import argparse
import collections
from .common import *
from .anchor_development import PHASE_ROOT, anchored_logits
from .score_branches import score_readout
from mydata_bench.meter_eval.readout import canonicalize

OUTPUT = RESEARCH / 'post_confirmation_anchor_evaluation_v1'


def freeze():
    development = json.loads((PHASE_ROOT / 'prospective_plan_v1.json').read_text())
    selection = json.loads((PHASE_ROOT / 'development_selection_v1.json').read_text())
    if fingerprint(development) != selection['plan_sha256'] or not selection['all_nine_development_eligible']:
        raise ValueError('All nine development selections must be eligible')
    parent = json.loads(pathlib.Path(development['parent_manifest']).read_text())
    if fingerprint(parent) != development['parent_manifest_sha256']:
        raise ValueError('Parent manifest changed')
    confirmation = json.loads(pathlib.Path(parent['confirmation_manifest_path']).read_text())
    cases = []
    for case in parent['cases']:
        name = case['model'] + '_' + case['protocol']
        audit = json.loads((PHASE_ROOT / name / 'generation_audit_v1.json').read_text())
        if not audit['rho0_parent_exact']:
            raise ValueError('Development zero-anchor mismatch')
        cases.append({**case, 'rho': selection['selections'][name]['rho'],
                      'development_anchor_scores': str(PHASE_ROOT / name / 'anchored_scores.jsonl'),
                      'development_anchor_scores_sha256': hashlib.sha256((PHASE_ROOT / name / 'anchored_scores.jsonl').read_bytes()).hexdigest()})
    create_json(OUTPUT / 'frozen_manifest_v1.json', {
        'time': timestamp(), 'phase': 'Post-confirmation exploratory evaluation with reused validation498',
        'development_plan_sha256': fingerprint(development), 'development_selection_sha256': fingerprint(selection),
        'parent_manifest_sha256': fingerprint(parent), 'cases': cases,
        'partitions': {'development': str(RESEARCH / 'development_v1/development_ids.json'),
                       'reused_validation': confirmation['analysis_protocol']['confirmation_ids_file'],
                       'ranking_overlap_remainder': str(RESEARCH / 'frozen_cohort_completion_v1/remaining_ids.json')},
        'partition_ids_sha256': {'development': confirmation['analysis_protocol']['development_ids_sha256'],
                                'reused_validation': confirmation['analysis_protocol']['ids_sha256'],
                                'ranking_overlap_remainder': parent['remaining_ids_sha256']},
        'full_ids_path': str(RESEARCH / 'frozen_cohort_completion_v1/full_cohort_ids.json'),
        'full_ids_sha256': parent['full_cohort_ids_sha256'], 'labels_sha256': development['labels_sha256'],
        'anchor_source_sha256': hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase/anchor_development.py').read_bytes()).hexdigest(),
        'evaluation_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        'metric_source_sha256': {n: hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / n).read_bytes()).hexdigest() for n in ['metrics.py', 'analyze_development.py']},
        'gate': 'All three unchanged k values: full coverage, both-baseline MAE down, suc/fail accuracy up and total accuracy at least +10pp, same-k original MAE/accuracy improvements, all-neighbor five-bin MAE down. Primary vs development-selected original is separately reported as strict acceptance. No reselection from follow-up outcomes.',
        'control_scope': 'On reused498, apply the same selected original-target anchor to every available parent control. These test the incremental evidence component while holding the target anchor fixed; they are not whole-method wrong-region/low-head controls. Also evaluate anchor-only references at each k and unchanged parent recipes.',
        'boundary': development['boundary'], 'v1_confirmation_failure_remains_unchanged': True})
    print(OUTPUT / 'frozen_manifest_v1.json')


def parent_sources(case):
    return {'development': pathlib.Path(case['folder']), 'reused_validation': pathlib.Path(case['confirmation_output_dir']),
            'ranking_overlap_remainder': pathlib.Path(case['output_dir'])}


def main():
    manifest = json.loads((OUTPUT / 'frozen_manifest_v1.json').read_text())
    if hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest() != manifest['evaluation_source_sha256']:
        raise ValueError('Frozen evaluation code changed')
    if hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase/anchor_development.py').read_bytes()).hexdigest() != manifest['anchor_source_sha256']:
        raise ValueError('Frozen anchor implementation changed')
    for n, sha in manifest['metric_source_sha256'].items():
        if hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / n).read_bytes()).hexdigest() != sha:
            raise ValueError('Frozen metric implementation changed')
    parts = {p: json.loads(pathlib.Path(path).read_text()) for p, path in manifest['partitions'].items()}
    full = json.loads(pathlib.Path(manifest['full_ids_path']).read_text())
    if fingerprint(full) != manifest['full_ids_sha256'] or any(fingerprint(ids) != manifest['partition_ids_sha256'][p] for p, ids in parts.items()):
        raise ValueError('Frozen IDs changed')
    if sum(map(len, parts.values())) != len(full) or set().union(*map(set, parts.values())) != set(full):
        raise ValueError('Partition overlap or missing IDs')
    audits = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; out = OUTPUT / name
        if out.exists():
            raise ValueError('Do not overwrite or silently restart follow-up evaluation')
        sources = parent_sources(case)
        if not all((folder / 'combination_events.jsonl').exists() for folder in sources.values()):
            raise ValueError('Wait for all frozen sources')
        dev_blob = pathlib.Path(case['development_anchor_scores']).read_bytes()
        if hashlib.sha256(dev_blob).hexdigest() != case['development_anchor_scores_sha256']:
            raise ValueError('Development anchor source changed')
        dev = {(r['example_id'], r['condition']): r for r in map(json.loads, dev_blob.decode().splitlines()) if r['rho'] == case['rho']}
        audit = {'sources': {}, 'rho0_mismatches': [], 'development_replay_mismatches': []}
        for part, folder in sources.items():
            blob = (folder / 'sweep.jsonl').read_bytes(); digest = hashlib.sha256(blob).hexdigest()
            if part == 'development' and digest != case['sweep_sha256']:
                raise ValueError('Original development source changed')
            rows = collections.defaultdict(dict)
            for line in blob.decode().splitlines():
                row = canonicalize(json.loads(line)); rows[row['condition']][row['example_id']] = row
            audit['sources'][part] = {'folder': str(folder), 'sweep_sha256': digest}
            recipes = []
            for parent_name, k in zip(case['conditions'], case['selected_ks']):
                recipes += [(f'anchor_rho{case["rho"]:g}__{parent_name}', parent_name, k, 'method'),
                            (f'anchor_reference_rho{case["rho"]:g}_k{k}', 'baseline', k, 'anchor_only')]
            if part == 'reused_validation':
                primary_k = case['selected_ks'][case['conditions'].index(case['primary'])]
                recipes += [('anchored_component__' + n, n, primary_k, 'fixed_target_anchor_component_control') for n in rows if n.startswith('control_')]
            for condition, parent_name, k, role in recipes:
                for eid in parts[part]:
                    required = [rows[n].get(eid) for n in [parent_name, 'baseline', f'original_all_k{k}']]
                    result = {'time': timestamp(), 'example_id': eid, 'condition': condition, 'rho': case['rho'],
                              'k': k, 'partition': part, 'role': role, 'parent_condition': parent_name}
                    if any(r is None or r.get('status') != 'ok' or 'score_logits' not in r for r in required):
                        result.update(status='error', error='One or more required native score sources invalid')
                    else:
                        logits = anchored_logits(*(r['score_logits'] for r in required), case['rho'])
                        result.update(status='ok', score_logits=logits, **score_readout(logits, case['model']))
                        fields = ['score_logits', 'progress', 'native_prediction']
                        if case['rho'] == 0 and any(result.get(f) != required[0].get(f) for f in fields):
                            audit['rho0_mismatches'].append([eid, condition])
                        if part == 'development' and role == 'method' and any(result.get(f) != dev[(eid, condition)].get(f) for f in fields):
                            audit['development_replay_mismatches'].append([eid, condition])
                    append(out / 'scores.jsonl', result)
        audit.update(time=timestamp(), all_score_generation_label_free=True,
                     scores_sha256=hashlib.sha256((out / 'scores.jsonl').read_bytes()).hexdigest())
        create_json(out / 'generation_audit_v1.json', audit); audits[name] = audit
        print(name, 'frozen follow-up scores generated', flush=True)
    # Labels are read only after all selected score vectors have been generated.
    from .metrics import summarize
    from .analyze_development import contrast
    label_blob = (BASE / 'inputs/labels.jsonl').read_bytes()
    if hashlib.sha256(label_blob).hexdigest() != manifest['labels_sha256']:
        raise ValueError('Frozen labels changed')
    labels = {r['example_id']: r for r in map(json.loads, label_blob.decode().splitlines())}
    accepted = {p: collections.defaultdict(list) for p in ['full_cohort', *parts]}
    strict = {p: collections.defaultdict(list) for p in accepted}; files = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; out = OUTPUT / name; rows = collections.defaultdict(dict)
        for r in read_rows(out / 'scores.jsonl'):rows[r['condition']][r['example_id']] = r
        refs = list(dict.fromkeys(['baseline', 'native_generation_baseline', *case['conditions'],
                                  *[f'original_all_k{k}' for k in case['selected_ks']], case['best_development_original']]))
        for part, source in audits[name]['sources'].items():
            blob = (pathlib.Path(source['folder']) / 'sweep.jsonl').read_bytes()
            if hashlib.sha256(blob).hexdigest() != source['sweep_sha256']:
                raise ValueError('Parent results changed during evaluation')
            for line in blob.decode().splitlines():
                r = canonicalize(json.loads(line))
                if r['condition'] in refs and r['example_id'] in set(parts[part]):rows[r['condition']][r['example_id']] = r
        method_names = [f'anchor_rho{case["rho"]:g}__{n}' for n in case['conditions']]
        anchor_names = [f'anchor_reference_rho{case["rho"]:g}_k{k}' for k in case['selected_ks']]
        core = refs + method_names + anchor_names; primary = f'anchor_rho{case["rho"]:g}__{case["primary"]}'
        reports = {}
        for part, ids in {'full_cohort': full, **parts}.items():
            summaries = {n: summarize(rows[n].values(), labels, ids) for n in core}
            comparisons = {}
            for n, parent_name, k, anchor in zip(method_names, case['conditions'], case['selected_ks'], anchor_names):
                effects = {b: contrast(summaries[n], summaries[b], case['model'] in {'meter', 'sole'}) for b in
                           dict.fromkeys(['baseline', 'native_generation_baseline', f'original_all_k{k}', case['best_development_original'], parent_name, anchor])}
                for effect in effects.values():
                    effect.pop('confirmation', None); effect['evaluation_phase'] = 'post_confirmation_exploratory_' + part
                original = effects[f'original_all_k{k}']
                gate = all(effects[b].get('point_estimate_10pp_gate', False) for b in ['baseline', 'native_generation_baseline'])
                gate = gate and original.get('complete', False) and original.get('mae_delta', 1) < 0 and original.get('accuracy_delta', -1) > 0
                bins = all(summaries[n]['overall']['mae'] is not None and summaries[b]['overall']['mae'] is not None
                           and summaries[n]['overall']['mae'] < summaries[b]['overall']['mae'] for b in ['baseline', 'native_generation_baseline'])
                comparisons[n] = {'effects': effects, 'point_gate': gate and bins, 'five_bin_mae_both_baselines': bins}
            integrity = not audits[name]['rho0_mismatches'] and not audits[name]['development_replay_mismatches']
            passed = integrity and all(v['point_gate'] for v in comparisons.values())
            best = comparisons[primary]['effects'][case['best_development_original']]
            strict_pass = passed and best.get('complete', False) and best.get('mae_delta', 1) < 0 and best.get('accuracy_delta', -1) > 0
            reports[part] = {'summaries': summaries, 'comparisons': comparisons, 'all_three_k_point_acceptance': passed,
                             'strict_development_selected_original_acceptance': strict_pass}
            if passed:accepted[part][case['model']].append(case['protocol'])
            if strict_pass:strict[part][case['model']].append(case['protocol'])
        controls = {}
        for n in rows:
            if not n.startswith('anchored_component__'):continue
            ids = [i for i in parts['reused_validation'] if rows[n].get(i, {}).get('status') == 'ok' and rows[primary].get(i, {}).get('status') == 'ok']
            c = summarize(rows[n].values(), labels, ids); p = summarize(rows[primary].values(), labels, ids)
            effect = contrast(p, c, case['model'] in {'meter', 'sole'}); effect.pop('confirmation', None)
            controls[n] = {'n_full_reused_validation': 498, 'n_feasible': len(ids), 'primary_summary_on_feasible_subset': p,
                           'control_summary_on_feasible_subset': c, 'effect': effect, 'scope': manifest['control_scope']}
        report = {'time': timestamp(), 'model': case['model'], 'protocol': case['protocol'], 'rho': case['rho'],
                  'primary': primary, 'selected_ks': case['selected_ks'], 'partitions': reports,
                  'conditional_component_controls_reused_validation': controls, 'generation_audit': audits[name], 'boundary': manifest['boundary']}
        files[name] = str(out / 'analysis_v1.json'); create_json(files[name], report)
        print(name, 'acceptance', {p: s['all_three_k_point_acceptance'] for p, s in reports.items()}, flush=True)
    create_json(OUTPUT / 'summary_v1.json', {'time': timestamp(), 'manifest_sha256': fingerprint(manifest), 'case_files': files,
                'accepted_protocols_by_partition': {p: dict(v) for p, v in accepted.items()},
                'three_models_three_inputs_point_by_partition': {p: sum(len(v) >= 3 for v in models.values()) >= 3 for p, models in accepted.items()},
                'strict_accepted_protocols_by_partition': {p: dict(v) for p, v in strict.items()},
                'three_models_three_inputs_strict_by_partition': {p: sum(len(v) >= 3 for v in models.values()) >= 3 for p, models in strict.items()},
                'boundary': manifest['boundary'], 'original_v1_confirmation_not_rewritten': True,
                'statistics': 'Observed descriptive metrics only. No fresh independent test or confirmatory p value is claimed for this post-confirmation adaptive follow-up.'})
    print(OUTPUT / 'summary_v1.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--freeze', action='store_true'); args = parser.parse_args()
    freeze() if args.freeze else main()
