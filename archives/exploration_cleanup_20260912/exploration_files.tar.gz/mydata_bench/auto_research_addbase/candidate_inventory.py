"""Inventory explored development neighborhoods; never reads confirmation data."""
import collections,datetime,json,re,pathlib
from .common import RESEARCH,read_rows,create_json,timestamp,fingerprint


def signature(c):
    # Names and branch spellings do not define a different scientific recipe.
    return json.dumps({'scope':c.get('scope'),'weight':c.get('contrast_weight'),
        'confidence_power':c.get('native_confidence_power',0.),
        'target_kl':c.get('target_kl'),'max_contrast_weight':c.get('max_contrast_weight'),
        'mechanism':c.get('combination_type','region_contrast'),
        'radius':c.get('central_difference_radius',3.),'query_scope':c.get('query_scope','all')},sort_keys=True)


def consecutive_runs(tested,passed):
    runs=[];current=[]
    for k in sorted(tested):
        if k in passed:current.append(k)
        elif current:runs.append(current);current=[]
    if current:runs.append(current)
    return runs


def main():
    roots=['score_development_full_v1','score_temporal_development_full_v1','score_native_confidence_development_full_v1','score_kl_development_full_v1','score_local_radius_development_full_v1']
    inventory={}
    for root_name in roots:
        root=RESEARCH/root_name
        if not root.exists():continue
        merged={}
        for snapshot in sorted(root.glob('analysis_snapshot_*.json')):
            data=json.loads(snapshot.read_text())
            for name,r in data.get('experiments',{}).items():
                entry=merged.setdefault(name,{'contrasts':{}});entry.update({k:v for k,v in r.items() if k!='contrasts'})
                for c,effect in r['contrasts'].items():entry['contrasts'][c]={'effect':effect,'snapshot':str(snapshot)}
        for name,r in merged.items():
            folder=root/name;conditions=list(r['config']['conditions']);ledger=folder/'analysis_supplements.jsonl'
            if ledger.exists():
                for entry in read_rows(ledger):
                    supplement=json.loads(pathlib.Path(entry['path']).read_text())
                    if fingerprint(supplement)!=entry['sha256']:raise ValueError('Supplement hash mismatch')
                    conditions.extend(supplement.get('conditions',[]))
            configs={c['name']:c for c in conditions};groups=collections.defaultdict(dict)
            continuous=r['config']['model'] in {'meter','sole'};loss='continuous_ordinal_mae' if continuous else 'mae'
            original={c:s for c,s in r['summaries'].items() if re.fullmatch(r'original_all_k\d+',c) and s.get('complete')}
            min_original=min((s['overall'][loss] for s in original.values()),default=None)
            max_original=max((s['overall']['accuracy'] for s in original.values()),default=None)
            for cname,c in configs.items():
                if not cname.startswith('contrast_target_'):continue
                value=r['contrasts'].get(cname,{'effect':{},'snapshot':None});d=value['effect']
                s=r['summaries'].get(cname,{}).get('overall',{})
                record={'condition':cname,'k':c['k'],'gate':d.get('full_development_extension_gate',False),
                    'measured_complete':d.get('complete',False),
                    'deltas':{k:d.get(k) for k in ['mae_delta','accuracy_delta','suc_delta','fail_delta']},
                    'snapshot':value['snapshot'],'beats_best_original_mae_and_accuracy_envelope':bool(min_original is not None and s.get(loss,float('inf'))<min_original and s.get('accuracy',0)>max_original)}
                key=signature(c);previous=groups[key].get(c['k'])
                if previous is None or (record['gate'] and not previous['gate']):groups[key][c['k']]=record
            neighborhoods=[]
            for recipe,points in groups.items():
                passed={k for k,v in points.items() if v['gate']}
                for run in consecutive_runs(points,passed):
                    if len(run)<3:continue
                    chosen=[points[k] for k in run]
                    neighborhoods.append({'recipe':json.loads(recipe),'ks':run,'requested_ks':sorted(points),
                        'completed_ks':sorted(k for k,v in points.items() if v['measured_complete']),
                        'points':chosen,'n_passed':len(run),'all_neighbors_beat_original_envelope':all(v['beats_best_original_mae_and_accuracy_envelope'] for v in chosen),
                        'weakest_suc_gain':min(v['deltas']['suc_delta'] for v in chosen),
                        'weakest_fail_gain':min(v['deltas']['fail_delta'] for v in chosen),
                        'minimum_total_gain':min(v['deltas']['accuracy_delta'] for v in chosen)})
            neighborhoods.sort(key=lambda v:(not v['all_neighbors_beat_original_envelope'],-v['n_passed'],-min(v['weakest_suc_gain'],v['weakest_fail_gain']),-v['minimum_total_gain']))
            inventory[root_name+'/'+name]={'model':r['config']['model'],'protocol':r['config']['protocol'],
                'n_expected':r['summaries']['baseline']['overall']['n_expected'],'complete_stable_neighborhoods':neighborhoods,
                'original_comparator_envelope':{'minimum_mae':min_original,'maximum_accuracy':max_original,
                    'interpretation':'Descriptive stricter check against separately optimized original k; may combine different original settings. Same-k control gate is reported separately.'}}
            print(root_name,name,'stable recipes',len(neighborhoods),
                'top',({k:neighborhoods[0][k] for k in ['recipe','ks','all_neighbors_beat_original_envelope']} if neighborhoods else None))
    stamp=datetime.datetime.now().strftime('%Y%m%dT%H%M%S');path=RESEARCH/f'candidate_inventory_{stamp}.json'
    create_json(path,{'time':timestamp(),'phase':'Exploratory development only; no confirmation run or acceptance',
        'stability_definition':'At least three successive passing tested k with all other hyperparameters fixed; gaps listed explicitly. This is not independent evidence for unsampled k.',
        'experiments':inventory});print(path)


if __name__=='__main__':main()
