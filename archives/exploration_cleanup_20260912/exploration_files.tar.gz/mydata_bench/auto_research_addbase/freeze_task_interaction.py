"""Freeze shared F5 interaction formula before evaluating it on old234."""
import json
import yaml
from .common import ROOT, create_json, timestamp
from .robust_prepare import DEST, digest


def main():
    plan = json.loads((DEST / 'frame_transport_frozen_plan_v1.json').read_text())
    cases = []
    for item in plan['configurations']:
        if digest(item['path']) != item['sha256']:
            raise ValueError('Frozen F1 config changed')
        cfg = yaml.safe_load(open(item['path']))
        name = item['model'] + '_' + item['protocol']
        conditions = [dict(name='baseline', k=0, cached_reference=True),
                      dict(name='native_generation_baseline', k=0, kind='native_generation', cached_reference=True)]
        for k in [32, 48, 64]:
            conditions.extend([
                dict(name=f'original_all_k{k}', k=k, kind='bias', bias=6., scope='all_frames', ranking='original', cached_reference=True),
                dict(name=f'task_interaction_k{k}', k=k, kind='task_interaction', bias=6., scope='all_frames')])
        conditions.extend([
            dict(name='task_interaction_zero_k48', k=48, kind='task_interaction', bias=0., scope='all_frames'),
            dict(name='task_interaction_wrong_k48', k=48, kind='task_interaction', bias=6., scope='all_frames', region='wrong'),
            dict(name='task_interaction_low_k48', k=48, kind='task_interaction', bias=6., scope='all_frames', head_group='low'),
            dict(name='task_contrast_only', k=0, kind='task_contrast_only')])
        cfg.update(clean_source_dir=cfg['output_dir'], output_dir=str(DEST / f'task_interaction_v1/{name}'),
                   original_ranking_file=cfg['ranking_file'], original_ranking_sha256=cfg['ranking_sha256'],
                   conditions=conditions, stage='F5_fixed_task_embedding_attention_interaction',
                   output_score_adjustment='original(task)-[original(zero_task_embeddings)-baseline(zero_task_embeddings)]',
                   primary_k=48, k_neighborhood=[32, 48, 64])
        for filename in ['task_interaction.py', 'task_interaction_runtime.py', 'task_interaction_runner.py',
                         'task_interaction_queue.py', 'freeze_task_interaction.py', 'joint_task_attention.py']:
            path = ROOT / 'mydata_bench/auto_research_addbase' / filename
            cfg['source_sha256'][str(path.relative_to(ROOT))] = digest(path)
        path = ROOT / f'mydata_bench/configs/v2_crossmodel/addbase_robust_task_interaction_v1_{name}.yaml'
        with path.open('x') as handle:
            yaml.safe_dump(cfg, handle, sort_keys=False)
        cases.append(dict(model=item['model'], protocol=item['protocol'], path=str(path), sha256=digest(path)))
    create_json(DEST / 'task_interaction_frozen_plan_v1.json', dict(time=timestamp(), configurations=cases,
        formula='z_original_actual - (z_original_task_ablated - z_baseline_task_ablated)',
        interpretation='task-dependent attention interaction, finite neural intervention contrast; not a physical causal effect',
        ablation='zero input embeddings of exactly the current Task field tokens; unchanged input IDs, length, pixels, grid and timestamps',
        shared_parameters=dict(original_bias=6., k_neighborhood=[32, 48, 64], primary_k=48, interaction_weight=1.),
        ranking='original raw_mass order, same in both attention branches',
        no_entropy_confidence_KL_anchor_or_case_specific_gain=True,
        F5_performance_not_seen=True, external_test_performance_not_opened=True,
        controls=['native/readout', 'original three k and best old development original', 'zero', 'wrong ROI both branches', 'low heads both branches', 'task contrast without attention'],
        limitations=['ablated embeddings can be out of distribution', 'ROI still depends on the actual task',
                     'task length and positional signals remain', 'no guarantee that interaction improves reward accuracy']))
    print('F5 frozen', len(cases), 'cases, shared unit interaction weight')


if __name__ == '__main__':
    main()
