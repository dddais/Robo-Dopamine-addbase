"""Development-only selection gates, including native and readout-only controls."""
import argparse,collections,datetime,json,pathlib
from .common import *
from .metrics import summarize
from .analyze_development import contrast
from mydata_bench.meter_eval.readout import canonicalize


def main():
    p=argparse.ArgumentParser();p.add_argument('--root',default=str(RESEARCH/'score_development_v1'));p.add_argument('--models',default='qwen,rr,meter');p.add_argument('--condition-contains',default='');a=p.parse_args();root=pathlib.Path(a.root)
    labels={r['example_id']:r for r in read_rows(BASE/'inputs/labels.jsonl')};report={}
    for folder in sorted(root.iterdir()):
        if not folder.is_dir() or not (folder/'sweep.jsonl').exists():continue
        cfg=json.loads((folder/'config.json').read_text())
        if cfg['model'] not in a.models.split(','):continue
        ids=json.loads(pathlib.Path(cfg['example_ids_file']).read_text());groups=collections.defaultdict(list)
        for r in read_rows(folder/'sweep.jsonl'):groups[r['condition']].append(canonicalize(r))
        summaries={name:summarize(rows,labels,ids) for name,rows in groups.items()};base=summaries.get('baseline');native=summaries.get('native_generation_baseline')
        if base is None or native is None:continue
        continuous=cfg['model'] in {'meter','sole'};deltas={}
        conditions=list(cfg['conditions'])
        ledger=folder/'analysis_supplements.jsonl'
        if ledger.exists():
            for entry in read_rows(ledger):
                supplement=json.loads(pathlib.Path(entry['path']).read_text())
                if fingerprint(supplement)!=entry['sha256']:raise ValueError('Supplement hash mismatch')
                conditions.extend(supplement.get('conditions',[]))
        if len({c['name'] for c in conditions})!=len(conditions):raise ValueError('Duplicate analysis condition')
        for c in conditions:
            name=c['name']
            if name not in summaries or not name.startswith('contrast_'):continue
            if a.condition_contains and a.condition_contains not in name:continue
            effect=contrast(summaries[name],base,continuous);effect['versus_native_generation']=contrast(summaries[name],native,continuous)
            original=summaries.get(f'original_all_k{c["k"]}')
            if original:effect['versus_original_same_k']=contrast(summaries[name],original,continuous)
            versus_original=effect.get('versus_original_same_k',{})
            effect['eligible_target_method']=name.startswith('contrast_target_')
            effect['full_development_extension_gate']=effect['eligible_target_method'] and effect.get('point_estimate_10pp_gate',False) and effect['versus_native_generation'].get('point_estimate_10pp_gate',False) and versus_original.get('complete',False) and versus_original.get('mae_delta',1)<0 and versus_original.get('accuracy_delta',-1)>0
            deltas[name]=effect
        indexed={name:{r['example_id']:r for r in rr} for name,rr in groups.items()}
        audits={}
        audit_names=['native_generation_baseline','zero_preserve_k32']+(['static_zero_preserve_k32'] if 'static_baseline' in indexed else [])
        for name in audit_names:
            reference='static_baseline' if name.startswith('static_') else 'baseline'
            shared=[i for i in ids if indexed[reference].get(i,{}).get('status')=='ok' and indexed.get(name,{}).get(i,{}).get('status')=='ok']
            changed=[i for i in shared if indexed[reference][i]['progress']!=indexed[name][i]['progress']]
            audit={'n_paired':len(shared),'n_progress_changed':len(changed),'changed_ids':changed}
            if 'zero_preserve' in name:audit['n_logits_changed']=sum(indexed[reference][i].get('score_logits')!=indexed[name][i].get('score_logits') for i in shared)
            audits[name]=audit
        report[folder.name]={'config':cfg,'summaries':summaries,'contrasts':deltas,'engineering_controls':audits}
        targets=sorted([(name,d) for name,d in deltas.items() if d['eligible_target_method'] and d.get('complete')],key=lambda x:(not x[1]['full_development_extension_gate'],not x[1].get('point_estimate_10pp_gate'),x[1]['mae_delta'],-x[1]['accuracy_delta']))
        print(folder.name,'n',base['overall']['n_valid'],'MAE',base['overall']['continuous_ordinal_mae' if continuous else 'mae'],'accuracy',base['overall']['accuracy'],'audits',audits)
        for name,d in targets[:6]:print(name,{k:v for k,v in d.items() if k not in ['versus_native_generation','versus_original_same_k']})
    stamp=datetime.datetime.now().strftime('%Y%m%dT%H%M%S');dest=root/f'analysis_snapshot_{stamp}.json';create_json(dest,{'time':timestamp(),'phase':'development only, selection across prospectively declared grid','condition_filter':a.condition_contains,'experiments':report});print(dest)
if __name__=='__main__':main()
