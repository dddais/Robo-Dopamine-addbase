"""Fixed module removals for the final recipe; no method selection follows."""
import argparse
import collections
from .common import *
from .entropy_development import entropy_scaled_logits, name_for
from .entropy_evaluation import source_folders
from .score_branches import score_readout
from mydata_bench.meter_eval.readout import canonicalize

FINAL_ROOT = RESEARCH / 'shared_entropy_evaluation_v1'
OUTPUT = RESEARCH / 'final_postprocess_ablations_v1'


def variants(parameters):
    result = {'final': parameters}
    if parameters['beta'] != 0:
        result['without_entropy'] = {**parameters, 'beta': 0.}
    if parameters['scale'] != 1:
        result['without_extra_amplitude'] = {**parameters, 'scale': 1.}
    if parameters['rho'] != 0:
        result['without_original_anchor'] = {**parameters, 'rho': 0.}
    return result


def prepare():
    manifest = json.loads((FINAL_ROOT / 'frozen_manifest_v1.json').read_text())
    create_json(OUTPUT / 'frozen_protocol_v1.json', {
        'time': timestamp(), 'final_manifest_sha256': fingerprint(manifest),
        'variants_by_case': {c['model'] + '_' + c['protocol']: variants(c['parameters']) for c in manifest['cases']},
        'source_sha256': {n: hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / n).read_bytes()).hexdigest()
                          for n in ['final_postprocess_ablations.py', 'entropy_development.py', 'metrics.py', 'analyze_development.py']},
        'final_scores_sha256': {c['model'] + '_' + c['protocol']: hashlib.sha256((FINAL_ROOT / (c['model'] + '_' + c['protocol']) / 'scores.jsonl').read_bytes()).hexdigest()
                                for c in manifest['cases']},
        'scope': 'All nine frozen primaries retained. Remove each enabled postprocessing module individually with every other parameter fixed. Non-enabled modules have no separate removal row. This is a descriptive explanation of the already-fixed method; no hyperparameter selection, k changes, or independent-efficacy claim follows.',
        'generation_rule': 'Construct all fixed score vectors from stored full native bins before loading labels; require exact final-score replay and retain every expected sample. Parent temporal, native-completion and wrong/low/temperature controls are available separately in the final main analysis.'})
    print(OUTPUT / 'frozen_protocol_v1.json')


def run():
    protocol = json.loads((OUTPUT / 'frozen_protocol_v1.json').read_text())
    manifest = json.loads((FINAL_ROOT / 'frozen_manifest_v1.json').read_text())
    if fingerprint(manifest) != protocol['final_manifest_sha256']:
        raise ValueError('Final method changed')
    for name, sha in protocol['source_sha256'].items():
        if hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / name).read_bytes()).hexdigest() != sha:
            raise ValueError('Frozen ablation or metric source changed')
    parts = {p: json.loads(pathlib.Path(path).read_text()) for p, path in manifest['partitions'].items()}
    full = json.loads(pathlib.Path(manifest['full_ids_path']).read_text())
    if fingerprint(full) != manifest['full_ids_sha256'] or any(fingerprint(ids) != manifest['partition_ids_sha256'][p] for p, ids in parts.items()):
        raise ValueError('Frozen IDs changed')
    generated = {}; audits = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; out = OUTPUT / name
        if out.exists():
            raise ValueError('Preserve all previous outputs; do not silently restart')
        final_blob = (FINAL_ROOT / name / 'scores.jsonl').read_bytes()
        if hashlib.sha256(final_blob).hexdigest() != protocol['final_scores_sha256'][name]:
            raise ValueError('Final reference scores changed')
        final_name = name_for(case['parameters'], case['primary'])
        expected = {r['example_id']: r for r in map(json.loads, final_blob.decode().splitlines()) if r['condition'] == final_name}
        k = case['selected_ks'][case['conditions'].index(case['primary'])]
        wanted = [case['primary'], 'baseline', f'original_all_k{k}']; parents = collections.defaultdict(dict)
        for partition, folder in source_folders(case).items():
            blob = (folder / 'sweep.jsonl').read_bytes()
            if hashlib.sha256(blob).hexdigest() != case['parent_source_sha256'][partition]:
                raise ValueError('Frozen parent neural scores changed')
            for line in blob.decode().splitlines():
                row = canonicalize(json.loads(line))
                if row['condition'] in wanted and row['example_id'] in set(parts[partition]):
                    parents[row['condition']][row['example_id']] = row
        out.mkdir(); rows = collections.defaultdict(dict); bad = []; invalid = []
        with (out / 'scores.jsonl').open('x') as handle:
            for variant, parameters in protocol['variants_by_case'][name].items():
                for eid in full:
                    required = [parents[n].get(eid) for n in wanted]
                    row = {'example_id': eid, 'condition': variant, 'parameters': parameters, 'k': k}
                    if any(r is None or r.get('status') != 'ok' for r in required):
                        row.update(status='error', error='Invalid fixed parent scores'); invalid.append([eid, variant])
                    else:
                        logits, diagnostics = entropy_scaled_logits(*(r['score_logits'] for r in required), **parameters)
                        row.update(status='ok', score_logits=logits, **score_readout(logits, case['model']), **diagnostics)
                    if variant == 'final' and any(row.get(f) != expected.get(eid, {}).get(f) for f in ['status', 'score_logits', 'progress', 'native_prediction']):
                        bad.append(eid)
                    handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n'); rows[variant][eid] = row
            handle.flush(); os.fsync(handle.fileno())
        audits[name] = {'n_expected_primary_samples': len(full), 'final_replay_mismatch_ids': bad,
                        'invalid_scores': invalid, 'n_variants': len(rows),
                        'all_expected_scores_exact_and_valid': not bad and not invalid,
                        'scores_sha256': hashlib.sha256((out / 'scores.jsonl').read_bytes()).hexdigest()}
        create_json(out / 'generation_audit_v1.json', audits[name]); generated[name] = rows
        print(name, 'fixed variants', list(rows), 'exact final replay', not bad, flush=True)
    from .metrics import summarize
    from .analyze_development import contrast
    label_blob = (BASE / 'inputs/labels.jsonl').read_bytes()
    if hashlib.sha256(label_blob).hexdigest() != manifest['labels_sha256']:
        raise ValueError('Frozen labels changed')
    labels = {r['example_id']: r for r in map(json.loads, label_blob.decode().splitlines())}; reports = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; rows = generated[name]; partitions = {}
        for partition, ids in {'full_cohort': full, **parts}.items():
            summaries = {v: summarize(values.values(), labels, ids) for v, values in rows.items()}
            effects = {}
            if audits[name]['all_expected_scores_exact_and_valid']:
                for variant in rows:
                    if variant == 'final': continue
                    effect = contrast(summaries['final'], summaries[variant], case['model'] in {'meter', 'sole'})
                    effect.pop('confirmation', None); effects[variant] = effect
            partitions[partition] = {'summaries': summaries, 'final_minus_ablation': effects}
        reports[name] = {'model': case['model'], 'protocol': case['protocol'], 'parameters': case['parameters'],
                         'primary_parent_condition': case['primary'], 'audit': audits[name], 'partitions': partitions}
    create_json(OUTPUT / 'analysis_v1.json', {'time': timestamp(), 'protocol_sha256': fingerprint(protocol),
                'cases': reports, 'all_nine_final_replays_exact_and_scores_valid': all(v['all_expected_scores_exact_and_valid'] for v in audits.values()),
                'scope': protocol['scope'], 'no_new_method_selection': True})
    print(OUTPUT / 'analysis_v1.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--prepare', action='store_true'); args = parser.parse_args()
    prepare() if args.prepare else run()
