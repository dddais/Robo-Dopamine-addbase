"""Replicate the stronger terminal-temporal evidence on development234."""
import yaml
from .common import *


def main():
    source=RESEARCH/'score_temporal_development_v1/meter_video_text';out=RESEARCH/'score_kl_development_full_v1/meter_video_text'
    cfg=json.loads((source/'config.json').read_text());ks=[56,64,72];scope='last_frame'
    branches=[{'name':'baseline','k':0},{'name':'native_generation_baseline','k':0,'kind':'native_generation'},
        {'name':'zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame'},
        {'name':'static_baseline','k':0,'media_condition':'static_first'},
        {'name':'static_zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame','media_condition':'static_first'}]
    recipes=[]
    for k in ks:
        branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
        for control in (['target','wrong','low_rank'] if k==64 else ['target']):
            prefix=f'{control}_{scope}_b3_k{k}'
            for static in [False,True]:
                for sign,bias in [('plus',3.),('minus',-3.)]:branches.append({'name':('static_' if static else '')+prefix+'_'+sign,
                    'k':k,'kind':'visual_preserve','bias':bias,'scope':scope,'region':'wrong' if control=='wrong' else 'target',
                    'head_group':'low' if control=='low_rank' else 'high','media_condition':'static_first' if static else 'observed'})
            for mechanism in ['region','temporal']:
                sources=['baseline',prefix+'_plus',prefix+'_minus']
                if mechanism=='temporal':sources+=['static_'+prefix+'_plus','static_'+prefix+'_minus']
                common={'k':k,'scope':scope,'region':control,'source_branches':sources,'combination_type':'region_contrast' if mechanism=='region' else 'temporal_region_contrast'}
                for weight in [16.,32.,64.]:recipes.append({**common,'name':f'contrast_{control}_uniform_matched_{mechanism}_{scope}_b3_k{k}_lambda{weight:g}','contrast_weight':weight})
                for delta in [1.,2.,4.]:recipes.append({**common,'name':f'contrast_{control}_kl_{mechanism}_{scope}_b3_k{k}_delta{delta:g}',
                    'contrast_weight':1.,'target_kl':delta,'max_contrast_weight':64.})
    for tau in [2.,4.,8.,16.]:recipes.append({'name':f'readout_temperature_tau{tau:g}','k':0,'contrast_weight':tau,'combination_type':'native_logit_temperature','source_branches':['baseline']})
    for delta in [1.,2.,4.]:recipes.append({'name':f'readout_kl_temperature_delta{delta:g}','k':0,'contrast_weight':1.,'target_kl':delta,'max_contrast_weight':64.,'combination_type':'native_logit_temperature','source_branches':['baseline']})
    cfg.update(output_dir=str(out),example_ids_file=str(RESEARCH/'development_v1/development_ids.json'),
        stage='prospectively_frozen_temporal_strength_full_development',branch_conditions=branches,
        conditions=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes)
    path=ROOT/'mydata_bench/configs/v2_crossmodel/addbase_temporal_strength_full_v1_meter_video_text.yaml'
    with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
    create_json(out/'ranking.json',json.loads((source/'ranking.json').read_text()))
    expected={c['name']:c for c in branches};blob=(source/'score_branches.jsonl').read_bytes();digest=hashlib.sha256(blob).hexdigest();count=0
    defaults={'kind':None,'k':0,'scope':'last_frame','region':'target','head_group':'high','media_condition':'observed','query_scope':'all','bias':3.}
    for line in blob.decode().splitlines():
        row=json.loads(line);name=row['condition']
        if name in expected and all(row.get('condition_config',{}).get(k,v)==expected[name].get(k,v) for k,v in defaults.items()):
            append(out/'score_branches.jsonl',{**row,'reused_from':str(source/'score_branches.jsonl'),'reused_source_sha256':digest,'reuse_time':timestamp()});count+=1
    create_json(out/'prospective_plan.json',{'time':timestamp(),'config':cfg,'config_sha256':fingerprint(cfg),'reused_rows':count,'source_sha256':digest,
        'reason':'On60, temporal-last k64 improves suc25pp at KL4 and uniform64, versus only5pp for observed-all. Uniform64 also improves fail72.5pp and MAE0.9705, so attribution must distinguish temporal scope and scalar amplitude from KL adaptation.',
        'ks':ks,'directions':['region','temporal'],'uniform_strengths':[16,32,64],'kl_budgets':[1,2,4],
        'confirmation_metrics_used':False,'initial_screen_limit':'The25pp suc gain is5/20 examples, still exploratory; all234 and neighboring k must replicate.'})
    print(path,'branches',len(branches),'readouts',len(cfg['conditions']),'reused',count)


if __name__=='__main__':main()
