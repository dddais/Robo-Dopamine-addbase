"""Freeze descriptive cohort completion without reading confirmation outcomes.

The 114 ranking-overlap examples complete 234 development + 498 confirmation.
No recipe is selected here; every frozen confirmation neighbor is retained.
"""
import copy
import yaml
from .common import *


def main():
    confirmation_path = RESEARCH / 'confirmation_v1/frozen_manifest_v1.json'
    confirmation = json.loads(confirmation_path.read_text())
    protocol = confirmation['analysis_protocol']
    development = json.loads((RESEARCH / 'development_v1/development_ids.json').read_text())
    confirm_ids = json.loads(pathlib.Path(protocol['confirmation_ids_file']).read_text())
    cohort = [r['example_id'] for r in read_rows(BASE / 'inputs/cohort.jsonl')]
    remaining = sorted(set(cohort) - set(development) - set(confirm_ids))
    if len(cohort) != 846 or len(remaining) != 114 or set(development) & set(confirm_ids):
        raise ValueError('Unexpected cohort partition')
    out = RESEARCH / 'frozen_cohort_completion_v1'
    if out.exists():
        raise ValueError('Never overwrite a frozen cohort completion plan')
    id_path = out / 'remaining_ids.json'
    prepared = []
    for case in confirmation['cases']:
        source_cfg = yaml.safe_load(pathlib.Path(case['config_path']).read_text())
        if fingerprint(source_cfg) != case['config_sha256']:
            raise ValueError('Frozen confirmation config changed')
        conditions = {c['name']: c for c in source_cfg['conditions']}
        names = ['baseline', 'native_generation_baseline', 'zero_preserve_k32']
        if 'static_baseline' in conditions:
            names += ['static_baseline', 'static_zero_preserve_k32']
        names += [f'original_all_k{k}' for k in case['selected_ks']]
        names += [case['best_development_original']] + case['conditions']
        selected = [copy.deepcopy(conditions[n]) for n in dict.fromkeys(names)]
        sources = {n for c in selected for n in c['source_branches']}
        cfg = copy.deepcopy(source_cfg)
        name = case['model'] + '_' + case['protocol']
        cfg.update(stage='descriptive_ranking_overlap_completion_v1', output_dir=str(out / name),
                   example_ids_file=str(id_path), conditions=selected,
                   branch_conditions=[b for b in cfg['branch_conditions'] if b['name'] in sources])
        if sources != {b['name'] for b in cfg['branch_conditions']}:
            raise ValueError('Missing frozen source branch')
        path = ROOT / f'mydata_bench/configs/v2_crossmodel/addbase_frozen_cohort_completion_v1_{name}.yaml'
        if path.exists():
            raise ValueError('Config already exists')
        prepared.append((case, cfg, path))
    create_json(id_path, remaining)
    create_json(out / 'full_cohort_ids.json', cohort)
    manifest = {'time': timestamp(), 'status': 'Descriptive completion frozen without confirmation outcomes',
                'confirmation_manifest_path': str(confirmation_path),
                'confirmation_manifest_sha256': fingerprint(confirmation),
                'partition_sizes': {'development': len(development), 'confirmation': len(confirm_ids),
                                    'ranking_overlap_remainder': len(remaining), 'full_grounded': len(cohort)},
                'full_cohort_ids_sha256': fingerprint(cohort), 'remaining_ids_sha256': fingerprint(remaining),
                'boundary': '846 includes development and ranking-overlap examples; its statistics are descriptive, not independent confirmation. All nine recipes and every frozen neighbor are retained, regardless of confirmation results.',
                'cases': [], 'provenance': provenance({'purpose': 'frozen_cohort_completion_v1'})}
    for case, cfg, path in prepared:
        folder = pathlib.Path(cfg['output_dir'])
        ranking = json.loads((pathlib.Path(case['output_dir']) / 'ranking.json').read_text())
        with path.open('x') as f:
            yaml.safe_dump(cfg, f, sort_keys=False)
        create_json(folder / 'ranking.json', ranking)
        create_json(folder / 'prospective_plan.json', {'time': timestamp(), 'config': cfg,
                    'config_sha256': fingerprint(cfg), 'source_confirmation_case': case,
                    'confirmation_outcomes_read': False})
        manifest['cases'].append({**case, 'confirmation_output_dir': case['output_dir'],
                                  'config_path': str(path), 'config_sha256': fingerprint(cfg),
                                  'output_dir': str(folder), 'aggregate_conditions': [c['name'] for c in cfg['conditions']]})
    create_json(out / 'frozen_manifest_v1.json', manifest)
    print(out / 'frozen_manifest_v1.json')


if __name__ == '__main__':
    main()
