"""Export primary effects for all frozen cases, including failures and uncertainty."""
import argparse
import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--analysis', required=True)
    args = parser.parse_args()
    source = pathlib.Path(args.analysis).resolve()
    report = json.loads(source.read_text())
    cases = report['cases']
    names = list(cases)
    stamp = datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
    out = source.parent / f'figures_{stamp}'
    out.mkdir()
    fig, axes = plt.subplots(1, 4, figsize=(17, 7), sharey=True)
    metrics = [('mae', 'MAE difference\n(lower is better)', 1),
               ('accuracy', 'Total accuracy difference (pp)', 100),
               ('suc_accuracy', 'Success accuracy difference (pp)', 100),
               ('fail_accuracy', 'Failure accuracy difference (pp)', 100)]
    baselines = [('native_generation_baseline', 'Native generation', '#2266aa', -.12),
                 ('baseline', 'Matched score readout', '#b35900', .12)]
    labels = []
    for name in names:
        case = cases[name]
        status = 'pass' if case['confirmation_case_point_acceptance'] else 'fail'
        baseline_accuracy = case['summaries']['native_generation_baseline']['overall']['accuracy']
        labels.append(f"{case['model']} / {case['protocol']} [{status}; B={baseline_accuracy:.1%}]")
    for ax, (metric, title, scale) in zip(axes, metrics):
        for i, name in enumerate(names):
            case = cases[name]
            for baseline, label, color, offset in baselines:
                effect = case['comparisons'][case['primary']][baseline]['paired'].get('effects', {}).get(metric)
                if not effect or 'delta_candidate_minus_baseline' not in effect:
                    continue
                mean = effect['delta_candidate_minus_baseline'] * scale
                low, high = [v * scale for v in effect['ci95_video_cluster_percentile']]
                ax.hlines(i + offset, low, high, color=color, linewidth=1.5)
                ax.plot(mean, i + offset, 'o', color=color, markersize=4, label=label if i == 0 else None)
        ax.axvline(0, color='#555555', linewidth=.8)
        if metric == 'accuracy':
            ax.axvline(10, color='#777777', linewidth=1, linestyle='--', label='+10 pp point criterion')
        ax.set_title(title, fontsize=10)
        ax.grid(axis='x', alpha=.2)
        ax.set_axisbelow(True)
        ax.spines[['top', 'right']].set_visible(False)
    axes[0].set_yticks(range(len(names)), labels)
    axes[0].invert_yaxis()
    axes[0].legend(loc='upper right', fontsize=8)
    fig.suptitle('Frozen confirmation: all nine primary cases, 498 examples / 179 video clusters', fontsize=13)
    fig.text(.02, .025, 'B: absolute native-baseline accuracy. Meter MAE uses continuous ordinal progress; Qwen/RR use native 1-5 scores.\n'
             'Bars: pointwise 95% whole-video-cluster bootstrap intervals (20,000 draws).\n'
             'Case pass/fail requires all three frozen neighbors, both baselines, original-method improvement, coverage and zero-control audits. '
             'Intervals are not simultaneous Holm-adjusted intervals.', fontsize=8)
    fig.tight_layout(rect=(0, .08, 1, .95))
    for suffix in ['png', 'svg']:
        fig.savefig(out / ('primary_effects.' + suffix), dpi=180, bbox_inches='tight')
    plt.close(fig)
    create_json(out / 'provenance.json', {'time': timestamp(), 'analysis_path': str(source),
                'analysis_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
                'all_cases_included': names, 'no_outcome_dependent_selection': True})
    print(out)


if __name__ == '__main__':
    main()
