import unittest
from types import SimpleNamespace
import torch
from transformers.modeling_utils import ALL_ATTENTION_FUNCTIONS
from .joint_task_attention import joint_task_steering, task_token_positions


class JointTaskTests(unittest.TestCase):
    def test_relative_odds_causality_and_zero(self):
        torch.manual_seed(51)
        q = torch.randn(1, 2, 8, 4)
        k = torch.randn_like(q)
        v = torch.eye(8).expand(1, 2, 8, 8).clone()
        module = SimpleNamespace(layer_idx=0, num_key_value_groups=1,
                                 config=SimpleNamespace(_attn_implementation='sdpa'))
        layers = [SimpleNamespace(self_attn=module)]
        native = ALL_ATTENTION_FUNCTIONS['sdpa']
        base, _ = native(module, q, k, v, None, scaling=.5)
        diag = {}
        with joint_task_steering(layers, [(0, 0)], [2], [1, 2, 3], [5, 6], 3., diagnostics=diag):
            actual, _ = ALL_ATTENTION_FUNCTIONS['addbase_sole_batch_residual_v1'](module, q, k, v, None, scaling=.5)
        self.assertTrue(torch.equal(actual[:, :, 1], base[:, :, 1]))
        expected = base[0, 7, 0, [5, 6]].sum() / base[0, 7, 0, 2]
        ratio = actual[0, 7, 0, [5, 6]].sum() / actual[0, 7, 0, 2]
        torch.testing.assert_close(ratio, expected, rtol=2e-6, atol=2e-6)
        self.assertTrue(torch.equal(actual[0, :5, 0, 5:], torch.zeros_like(actual[0, :5, 0, 5:])))
        self.assertNotIn('visual_counts', diag)
        self.assertEqual(diag['actual_task_text_tokens'], 2)
        with joint_task_steering(layers, [(0, 0)], [2], [1, 2, 3], [5, 6], 0.):
            zero, _ = ALL_ATTENTION_FUNCTIONS['addbase_sole_batch_residual_v1'](module, q, k, v, None, scaling=.5)
        self.assertTrue(torch.equal(base, zero))

    def test_actual_tokenizer_task_span_all_prompt_styles(self):
        from transformers import AutoTokenizer
        tokenizer = AutoTokenizer.from_pretrained('/home/dais/workspace/model/Qwen3-VL-8B-Instruct', local_files_only=True)
        task = 'Put the red cup beside the blue bowl.'
        prompts = [('meter', 'image_text', "The task for the robot is '" + task + "'. Predict progress."),
                   ('rr', 'text_video', 'Rubric: red cup can be mentioned here.\nTask: ' + task),
                   ('qwen', 'interleaved', '<Task>\n`' + task + '`\n</Task>')]
        for model, protocol, prompt in prompts:
            text = '<|im_start|>user\n<|vision_start|><|image_pad|><|vision_end|>' + prompt + '<|im_end|>\n<|im_start|>assistant\n'
            ids = tokenizer.encode(text, add_special_tokens=False) + tokenizer.encode('ANSWER:', add_special_tokens=False)
            selected, audit = task_token_positions(tokenizer, ids, task, model, protocol)
            decoded = tokenizer.decode([ids[i] for i in selected], clean_up_tokenization_spaces=False)
            self.assertIn(task, decoded)
            self.assertTrue(audit['exact_actual_token_prefix_verified'])


if __name__ == '__main__':
    unittest.main()
