# Robust research checkpoint — 2026-09-10 10:56 Asia/Shanghai

Goal ACTIVE and UNACHIEVED. This turn is progress: fully assessed terminal F1–F6, audited actual training grounding, implemented F7, passed CPU plus3 actual-model engineering gates, froze and launched all15 independent fits. Do not mark complete or blocked. New automatic-goal message arrived mid-work; task unchanged.

## Rules

Only `/mnt/public1/dais/workspace/Robo-Dopamine-addbase` (logical `/home/dais/workspace/Robo-Dopamine-addbase`); explicit cwd and login:false for every exec. No git operations, no other local code repositories, no subagents or permission questions. Preserve all old data/results/failures and frozen code/config SHA. Python `/home/dais/miniconda3/envs/robo-dopamine/bin/python`; SAM3 env rewardbench-sam3. Chinese updates. academic-research-suite already applied inline.

R=`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1`; CODE=`mydata_bench/auto_research_addbase`. Previous checkpoints 20260910T0212,0157,0134 preserve implementation details. Latest Chinese progress ROBUST_PROGRESS_20260910T1053.md. Root plan and ROBUST_RESEARCH_PROTOCOL_20260909.md appended; previous text retained.

## Time jump and terminal work

Wall clock advanced overnight while the turn was in progress. Do not rely on earlier02:12 snapshot: now Shanghai10:5x. All F1–F5 experiment queues are COMPLETE,15 cases/family. F2–F5 full analyses newly written around UTC02:36; all15 each whole-case FAIL. F1 earlier final15 allfail. F6 all15 fit1942 completed UTC20:16, all15 validation493 plusold234 completed UTC01:02, analysis01:03. ALL15 old234 F6 whole-case FAIL; maxprimary accuracy improvement+3.8462pp(Qwen video_text), below10pp. Do not keep describing F6 as pending.

F6 `f6_training_validation_analysis_2026-09-10T010258.859172_0000.json`: validation point passes qwen0,rr2(text_video/interleaved),meter1(text_video); joint old234+validation passes0 each; allprimary Holm p1. F6 old analysis `f6_frame_transport_analysis_2026-09-10T010224.215404_0000.json`. Full846 waiter2466415 terminated normally with `f6_full_old_queue_eligibility_v1.json` eligiblefalse, so no full846F6 output. Fit/eval/prep/parser old PIDs ALL TERMINAL. No restarting.

F6 fit each1942 records=1253 measured gradients+689 no-ROI zero contributions,0gradient errors. Ranking penalty scores are positive for285–764/896 heads bycase, so this was not an all-zero ranking problem. Small effect at reward-query-only appears a plausible limitation, not proven cause. All parameters remain unchanged and allfailed results retained.

F6 validation invalids are mostly `reward_gradient_wrong_k48`:100 perdiscretevideo,73 perdiscreteimage/interleaved;79 perMetervideo,45 perMeterimage/interleaved. Actual errors are `No equal-area disjoint same-frame wrong control`. Qwen interleaved native_generation baseline additionally2format errors. MainF6 scoring complete. Do not present wrong-control penalized means as successful attribution: fullpaired control unavailable. Future mechanism analysis should state feasibility and compare on predefined computable-control intersection while keeping full primary denominator intact. No relaxing primary gate to rescue F6.

All latest f1–f6 analysis JSON paths can be located with glob fX_frame_transport_analysis_*.json. f1lastunchanged, f2/3/4 UTC20260910T02364x, f5T023615. No reasonrerun unchanged.

## Training grounding audited after completion

Parser1072complete0errors, grounder2435complete0runtimeerrors atUTC19:21. Actualcounts:1565grounded870fallback; fit1253/689, validation312/181. `R/training_grounding_complete_audit_20260910T1047_v1.json` verifies fullunique2435 and allgrounded exact displayed-source-index coverage; first5 actualtraining proxies decoded8frames each and compared pixel-exact to inputPNGs. No labels read, no claim semantic grounding perfect.

External reserved test unchanged2831/1172groups,1788grounded1043fallback,0runtimeerrors; originalinputSHA and structural audit in earlier checkpoints. **NO reserved reward-model inference/label-performance join. `external_roboreward_reserved_v1/reward_model_confirmation_claim_v1.json` does not exist.**

## F7 active: supervision at ALL causal queries

F7 keeps same1942fit IDs/labels, native1–5/ten-bin loss, frozen backbones, group-average gradient ranking abs(mu)-1.96SE, direction-negative-sign(mu), excludesfirst8layers, fixed b1/k32,48,64/primary48/all_frames. Change: apply learned signed ROI log-bias at ALL causal prefill query positions, not just actualrewardquery; loss still from unchanged native score readout. No gain/entropy/anchor/endpoint rules. Earlier hidden representations canchange, while mask prevents attention to futurekeys. Complete input/task determinessteering, so no online-streaming causality claim. 1.96 remains variability penalty, not simultaneous confidence guarantee.

493validation has now been used by F6. For F7 andlater it is explicitly reusable MODEL-SELECTION data, not a fresh independent confirmation. Fit partition remains isolated fromvalidation. Reserved2831 staysonce-only final.

New files NOW FROZEN (snapshots `R/f7_fit_source_snapshots_v1`; SHA in launch/queueplan/config):
- all_query_reward_gradient_attention.py
- all_query_reward_gradient_engineering.py
- all_query_reward_gradient_fit.py
- freeze_all_query_reward_gradient_fit.py
- all_query_reward_gradient_fit_queue.py

One CPU test passed `test_all_query_reward_gradient_attention.py`: zeroexact, finite-differencegradient, active pre-readoutchanges, unselectedheads unchanged, future-invisible visuals nochange, explicit/implicitcausal masks agreement, configrestore. All real engineering twoOLD examples percase passed RR image_text, Qwen text_video, Meter text_image: cachedbaseline/zero/gradient-forward logits exact,896nonzero finitegradients, first8zero, weightsfrozen. Syntheticgrade3 ONLY, nottrue labels/notfitting. Audits `R/all_query_reward_gradient_engineering_v1/{case}/engineering_audit_v1.json`. Peaks RR23390.5MiB, Qwen20693.9MiB, Meter37790.8MiB. Memory on latertrainingexamples notguaranteed. Firstattempt64kMiB launchguard had only60787MiBfree and launchednothing; thenused56kguardforRRengineering. All oldfailureskept. Fitqueue currentlyuses32kfree threshold (actualMeterengineeringpeak37.8k; monitoravailablememory whenMeterstarts, foreignGPUsvary; don'teditfrozenqueue). GPU0/3 livefits had plentyfree beforeload.

F7 engineer+fit queue **PID2553345**, verifiedlive. Plan `R/f7_fit_queue_plan_v1.json`, launchfile, stdout. RRengineering2551898 terminalpass; queuecompleted Qwenengineering2553352 andMeter2553414. It frozeall15 atUTC02:49:53 into `all_query_reward_gradient_fit_frozen_plan_v1.json` plus15 `addbase_robust_all_query_reward_gradient_fit_v1_*.yaml`. Actualfits:
- GPU0 qwen_text_video **2553594** (thenqwen_video_text/text_image andRRfive)
- GPU3 qwen_image_text **2553595** (thenqwen_interleaved andMeterfive)
At10:53 snapshot qwen_text_video491/1942(329ok162noROI),qwen_image_text966/1942(642ok324noROI), noerrors. Outputs `R/all_query_reward_gradient_v1/{case}/fit/{gradient_records_v1.jsonl,ranking_v1.json,completion_v1.json}`. Allfit recordsrequired; anyactualgradienterror invalidatescase, nodrop/retry. Queuecompletionexpected `f7_all_fit_queues_completion_v1.json`.

**F7 EVALUATION IMPLEMENTATION/SCHEDULING IS STILL MISSING.** Queue intentionallystopsafterfits. NoF7old234 or493 performance read. Nextturnshouldimplement F7 runtime/development/validation/freezers/analyzer/queue BEFORE evaluation. Do notmodify F6frozenfiles; versionnewones. Reuseold F1native/originalcachedreferences withexactengineering; preserveF6predictions/errors asfixedscope-comparison controls. Suggested mechanisticcontrols forfreeze: raw-mass all-query b1, learned positive-only all-query b1, F7learnedheads readout-only b1, zero/wrong/low. F6readoutonlyheadselectionresults already available canbeofflinecontrol. These extraF7controls ARE NOT YET FROZEN orimplemented; donotpretendpolicycommitted. Mainacceptanceremainsoriginalscope; notper-casehyperparamretune.

## Prepared but UNFROZEN/unactivated final confirmation code

This turn beforeF6failurewasinspected added4files:
- reward_gradient_confirmation.py (cloneoflabel-freevalidationrunner adaptedfor2831andexclusiveclaim)
- freeze_reward_gradient_confirmation.py (requiresfull846>=3permodel, selectsallpassingcases, strongestold846original, writesonce-onlyclaim/configs)
- analyze_reward_gradient_confirmation.py (joinslabelsONLYafterallselectedcases/conditionsfull2831complete; paired1172groupbootstrap andprimaryIUT/Holm; reportsallcases/CIs/grade/task/source/coverage; scientificgate doesnotauto-completegoal)
- reward_gradient_confirmation_queue.py (conditionalwaiteronly, notlaunched)
Two tests passed test_reward_gradient_confirmation.py: failedoriginalmodelscope cannotbe rescued byoverallcasecount; incompleteoutputblockslabeljoin. Used `--basetemp R/confirmation_testing_v1`; NEVERreusebasetemp becausepytestdeletesoldfixtures. FourASTpassed. Initialread-only metadata commandguessed nonexistentdownloads_v1.jsonl andstopped; actualneeded source_subsetisalreadyininput. No datachanged.

These4confirmationfiles are NOT inanyfrozenpolicy. `f6_confirmation_policy_v1.json` NOTCREATED, confirmationqueue NOTLAUNCHED, noreservedclaim/config/predictions. F6doesnotqualifysoDONOTactivateitsfinaltest. Theyarepreparatory scaffolding, mayadapttofuturefamilybeforetestopening. Their currentproposedfinalgate hasall3k positiveMAE/allgradeaccvsbaselines/samek/old846bestoriginal, endpointnondecreasevsbaselines underboththresholds, primaryIUT/Holm<=.05 in>=3casespermodel; this finalpolicywasnotfrozen. Needreview/freezeactualfuturemethodandrules beforetest. Native+10pp original846 separatelyrequired. Local sealingnotthird-partyblindtest; pretrainingcontaminationnotexcluded.

## Next actions

1. KeepF7fitqueuealive, inspectactualfitprogress/errors/rankings. AllpreviousF1–F6queuesareterminal; don'tpolloldPIDs aslive.
2. Implement/freezeF7evaluation/durablequeuewhilefitsrun, reusing frozenF1baselines andF6scopecontrolswithoutchangingoldrows. 493isnowselectionnotconfirmation. All15cases, sharedb1/3k, completeprimarydenominators, bothMeterthresholds/strongoriginals preserved.
3. Explicitlyhandlewrong-controlfeasibilityinterpretationwithoutdroppingprimarysamples orwritingendpointfallback. Existinginvalidcontrolrecords stay.
4. IfF7passes, adaptcomplete846andonce-only2831confirmation; currentF6full846/confirmation paths mustnotbemislabeledF7oractivatedwithF6failedranks.
5. Finalgoalstillrequiresoriginalplanfullscopeandrealindependentconfirmation, documentationandrequirement-by-requirementaudit. Notachieved, notblocked.

LivePIDsnapshotUTC2026-09-10T02:56:06.196735+00:00:
```json
{
  "2553345": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.all_query_reward_gradient_fit_queue ",
  "2553594": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.all_query_reward_gradient_fit --config /mnt/public1/dais/workspace/Robo-Dopamine-addbase/mydata_bench/configs/v2_crossmodel/addbase_robust_all_query_reward_gradient_fit_v1_qwen_text_video.yaml ",
  "2553595": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.all_query_reward_gradient_fit --config /mnt/public1/dais/workspace/Robo-Dopamine-addbase/mydata_bench/configs/v2_crossmodel/addbase_robust_all_query_reward_gradient_fit_v1_qwen_image_text.yaml "
}
```
No pending exec sessions; durableF7fitjobs only. Do not edit frozenF7/F6/F1–F5files. Progressreport ROBUST_PROGRESS_20260910T1053.md.
