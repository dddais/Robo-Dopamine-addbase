"""Run F2 after the corresponding F1 GPU queue terminates; never retry failures."""
import argparse
import json
import os
import pathlib
import subprocess
import sys
import time
from .common import ROOT, append, create_json, timestamp
from .robust_prepare import DEST, digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, required=True)
    parser.add_argument('--cases', required=True)
    args = parser.parse_args()
    event_path = DEST / f'f2_queue_gpu{args.gpu}_events_v1.jsonl'
    source_completion = DEST / f'queue_gpu{args.gpu}_completion_v1.json'
    source_launch = next(r for r in json.loads((DEST / 'durable_launches_v1.json').read_text()) if r['gpu'] == args.gpu)
    append(event_path, dict(time=timestamp(), event='queue_start', pid=os.getpid(), preceding_pid=source_launch['pid']))
    while not source_completion.exists():
        # Absence of a completion marker is not proof of a live predecessor.
        process = pathlib.Path('/proc') / str(source_launch['pid']) / 'cmdline'
        if not process.exists() or b'mydata_bench.auto_research_addbase.robust_queue' not in process.read_bytes():
            raise RuntimeError('F1 predecessor disappeared without completion; inspect instead of restarting')
        time.sleep(20)
    selected = set(args.cases.split(','))
    plan = json.loads((DEST / 'frame_transport_vcd_frozen_plan_v1.json').read_text())
    cases = [c for c in plan['configurations'] if c['model'] + '_' + c['protocol'] in selected]
    if len(cases) != len(selected):
        raise ValueError('Unknown F2 cases')
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(args.gpu), OMP_NUM_THREADS='2', OPENBLAS_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
    failures = []
    for case in cases:
        name = case['model'] + '_' + case['protocol']
        if digest(case['path']) != case['sha256']:
            raise ValueError('Frozen F2 config changed')
        if not (DEST / f'frame_transport_v1/{name}/development/completion_v1.json').exists():
            failures.append(dict(case=name, reason='F1 dependency incomplete'))
            continue
        for stage in ['engineering', 'development']:
            while True:
                free = int(subprocess.check_output(['nvidia-smi', f'--id={args.gpu}', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
                if free >= (16000 if case['model'] == 'meter' else 28000):
                    break
                append(event_path, dict(time=timestamp(), event='memory_wait', free_mib=free))
                time.sleep(20)
            command = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.frame_transport_vcd_runner', '--config', case['path'], '--stage', stage]
            with (DEST / f'f2_{name}_{stage}_stdout_v1.log').open('x') as handle:
                proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT)
                append(event_path, dict(time=timestamp(), event='launch', pid=proc.pid, case=name, stage=stage, command=command))
                code = proc.wait()
            append(event_path, dict(time=timestamp(), event='exit', pid=proc.pid, case=name, stage=stage, returncode=code))
            if code:
                failures.append(dict(case=name, stage=stage, returncode=code))
                break
    create_json(DEST / f'f2_queue_gpu{args.gpu}_completion_v1.json', dict(time=timestamp(), failures=failures, cases=sorted(selected)))


if __name__ == '__main__':
    main()
