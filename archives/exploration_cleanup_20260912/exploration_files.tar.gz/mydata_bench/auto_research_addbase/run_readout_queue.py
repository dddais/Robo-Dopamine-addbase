"""Check real-model readout-query zero controls before each model's screen."""
import argparse,subprocess,time,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);p.add_argument('--models',default='meter,rr,qwen');a=p.parse_args()
    root=RESEARCH/'score_readout_development_v1';log=root/f'queue_gpu{a.gpu}_events.jsonl'
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(a.gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    for model in a.models.split(','):
        cfg=yaml.safe_load((ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_readout_development_v1_{model}_text_image.yaml').read_text())
        out=RESEARCH/f'readout_engineering_v1/{model}_text_image';out.mkdir(parents=True,exist_ok=True)
        engineering_path=out/'engineering.yaml'
        if not engineering_path.exists():
            source=pathlib.Path(cfg['output_dir']);ids=json.loads(pathlib.Path(cfg['example_ids_file']).read_text())[:2]
            create_json(out/'example_ids.json',ids);create_json(out/'ranking.json',json.loads((source/'ranking.json').read_text()))
            cfg.update(output_dir=str(out),example_ids_file=str(out/'example_ids.json'),stage='label_free_readout_query_engineering')
            with engineering_path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
        while int(subprocess.check_output(['nvidia-smi',f'--id={a.gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())<(24000 if model=='meter' else 34000):time.sleep(20)
        command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.score_branches','--config',str(engineering_path)]
        append(log,{'time':timestamp(),'event':'engineering_launch','command':command})
        with (out/'engineering.log').open('a') as f:proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT);code=proc.wait()
        if code:raise RuntimeError(f'Engineering process failed: {code}')
        rows={(r['example_id'],r['condition']):r for r in read_rows(out/'score_branches.jsonl')};ids=json.loads((out/'example_ids.json').read_text())
        checks={'zero_score_logits_exact':all(rows[(i,'baseline')]['score_logits']==rows[(i,'zero_preserve_k32')].get('score_logits') for i in ids),
                'target_branches_all_ok':all(r['status']=='ok' for (_,name),r in rows.items() if not name.startswith('wrong_')),
                'all_readout_branches_hit_explicit_query':all(r['hook_diagnostics']['calls']>0 and isinstance(r['hook_diagnostics'].get('readout_query_index'),int) for r in rows.values() if r.get('status')=='ok' and r.get('condition_config',{}).get('query_scope')=='readout')}
        passed=all(checks.values());append(log,{'time':timestamp(),'event':'engineering_audit','model':model,'checks':checks,'passed':passed})
        if not (out/'audit.json').exists():create_json(out/'audit.json',{'time':timestamp(),'checks':checks,'passed':passed,'labels_used':False})
        if not passed:raise RuntimeError('Engineering validation failed; dependent screen not started')
        paths=[str(ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_readout_development_v1_{model}_{protocol}.yaml') for protocol in ['text_image','interleaved','image_text','video_text','text_video']]
        command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.run_score_extensions','--gpu',str(a.gpu),'--name',f'readout_development_{model}_v1','--configs',','.join(paths)]
        append(log,{'time':timestamp(),'event':'screen_launch','model':model,'command':command})
        code=subprocess.call(command,cwd=ROOT,env=env)
        append(log,{'time':timestamp(),'event':'screen_exit','model':model,'returncode':code})
        if code:raise RuntimeError('Dependent screen failed')
    append(log,{'time':timestamp(),'event':'queue_completed'})


if __name__=='__main__':main()
