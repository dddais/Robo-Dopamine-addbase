"""Append-only download and actual-frame decoding of selected training media."""
import concurrent.futures
import hashlib
import json
import pathlib
import subprocess
import time
import urllib.parse
import cv2
import numpy as np
import requests
from .common import append, create_json, read_rows, timestamp
from .prepare_external_head_training import OUT
from .robust_prepare import digest


def fetch(name, revision):
    remote = pathlib.PurePosixPath(name)
    if remote.is_absolute() or '..' in remote.parts or remote.suffix != '.mp4':
        raise ValueError('Unexpected training media path')
    opaque = hashlib.sha256(name.encode()).hexdigest()
    url = 'https://huggingface.co/datasets/teetone/RoboReward/resolve/' + revision + '/train/' + urllib.parse.quote(name, safe='/') + '?download=true'
    attempts = []
    for attempt in range(1, 4):
        path = OUT / 'videos' / (opaque + f'_attempt{attempt}.mp4')
        if path.exists():
            raise FileExistsError('Preserve existing training media attempt')
        try:
            h, size = hashlib.sha256(), 0
            with requests.get(url, timeout=(20, 60), stream=True) as response:
                response.raise_for_status()
                with path.open('xb') as handle:
                    for chunk in response.iter_content(1024*1024):
                        if chunk:
                            handle.write(chunk)
                            h.update(chunk)
                            size += len(chunk)
            attempts.append(dict(attempt=attempt, status='ok', bytes=size))
            return dict(source_key=opaque, status='ok', path=str(path), video_sha256=h.hexdigest(), bytes=size, attempts=attempts)
        except Exception as exc:
            attempts.append(dict(attempt=attempt, status='error', error=repr(exc)))
            time.sleep(attempt)
    return dict(source_key=opaque, status='error', attempts=attempts)


def decode(record):
    folder = OUT / 'frames' / record['video_sha256']
    folder.mkdir(parents=True, exist_ok=True)
    try:
        command = ['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-count_frames', '-show_entries',
                   'stream=nb_read_frames', '-of', 'json', record['path']]
        probe = subprocess.run(command, capture_output=True, text=True, timeout=180)
        if probe.returncode or probe.stderr.strip():
            raise ValueError('FFprobe reported decode errors: ' + probe.stderr[:1000])
        ff_count = int(json.loads(probe.stdout)['streams'][0]['nb_read_frames'])
        cap = cv2.VideoCapture(record['path'])
        count, fps = 0, float(cap.get(cv2.CAP_PROP_FPS))
        reported = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        try:
            if not cap.isOpened() or not np.isfinite(fps) or fps <= 0:
                raise ValueError('Invalid source video/fps')
            while True:
                ok, _ = cap.read()
                if not ok:
                    break
                count += 1
        finally:
            cap.release()
        if count < 1 or count != ff_count:
            raise ValueError('Actual OpenCV/FFprobe counts disagree')
        indices = np.linspace(0, count-1, 8).round().astype(int).tolist()
        wanted, images, pixels = set(indices), {}, {}
        cap = cv2.VideoCapture(record['path'])
        seen = 0
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    break
                if seen in wanted:
                    path = folder / f'frame_{seen:06d}.png'
                    if path.exists():
                        raise FileExistsError('Preserve existing training frame')
                    if not cv2.imwrite(str(path), frame):
                        raise IOError('Cannot write training frame')
                    images[seen] = str(path)
                    pixels[seen] = hashlib.sha256(frame.tobytes()).hexdigest()
                seen += 1
        finally:
            cap.release()
        if seen != count or set(images) != wanted:
            raise ValueError('Second actual decode incomplete')
        result = dict(status='ok', video_sha256=record['video_sha256'],
            image_paths=[images[i] for i in indices], image_source_indices=indices,
            decoded_frame_pixel_sha256=[pixels[i] for i in indices],
            image_sampling_record=dict(terminal_source_index=count-1, selected_source_indices=indices,
                decoded_frame_count=count, source_fps=fps, metadata_frame_count=reported,
                ffprobe_actual_frame_count=ff_count, two_opencv_counts_agree=True))
        create_json(folder / 'manifest_v1.json', result)
        return result
    except Exception as exc:
        return dict(status='error', video_sha256=record['video_sha256'], error=repr(exc))


def main():
    completion = json.loads((OUT/'training_selection_completion_v1.json').read_text())
    selected_path = OUT/'selected_training_metadata_v1.jsonl'
    if digest(selected_path) != completion['selected_metadata_sha256']:
        raise ValueError('Selected training rows changed')
    rows = list(read_rows(selected_path))
    revision = json.loads((OUT/'training_metadata_provenance_v1.json').read_text())['revision']
    create_json(OUT/'media_preparation_plan_v1.json', dict(time=timestamp(), source_sha256=digest(__file__),
        selected_metadata_sha256=digest(selected_path), revision=revision, split='train',
        workers=4, retries=3, label_files_read=False, reserved_test_labels_read=False,
        decode='FFprobe actual count and two OpenCV sequential counts; linspace8 actualfirst/last; no metadata-last assumption',
        failure_policy='preserve all attempts and all expected rows; later head fit uses no unavailable ROI; never select by model performance',
        overlap_audit_required_before_training=True))
    (OUT/'videos').mkdir(exist_ok=True)
    videos = {}
    names = sorted({r['source_name'] for r in rows}, key=lambda n: hashlib.sha256(n.encode()).hexdigest())
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs = [pool.submit(fetch, name, revision) for name in names]
        for i, job in enumerate(concurrent.futures.as_completed(jobs), 1):
            value = job.result()
            videos[value['source_key']] = value
            append(OUT/'download_records_v1.jsonl', dict(time=timestamp(), **value))
            if i % 50 == 0 or i == len(jobs):
                print(json.dumps(dict(time=timestamp(), downloaded=i, expected=len(jobs), failures=sum(v['status']!='ok' for v in videos.values()))), flush=True)
    unique = {v['video_sha256']: v for v in videos.values() if v['status']=='ok'}
    decoded = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        jobs = [pool.submit(decode, record) for record in unique.values()]
        for i, job in enumerate(concurrent.futures.as_completed(jobs), 1):
            value = job.result()
            decoded[value['video_sha256']] = value
            append(OUT/'decode_records_v1.jsonl', dict(time=timestamp(), **value))
            if i % 50 == 0 or i == len(jobs):
                print(json.dumps(dict(time=timestamp(), decoded=i, expected=len(jobs), failures=sum(v['status']!='ok' for v in decoded.values()))), flush=True)
    path = OUT/'inputs_without_labels_v1.jsonl'
    ready = 0
    with path.open('x') as handle:
        for row in rows:
            video = videos[row['source_key']]
            frame = decoded.get(video.get('video_sha256'), {})
            ok = video['status']=='ok' and frame.get('status')=='ok'
            sample = {k:row[k] for k in ['example_id','task','source_subset','source_episode_sha256','training_partition']}
            sample.update(preparation_status='ok' if ok else 'error', video_path=video.get('path'), video_sha256=video.get('video_sha256'))
            if ok:
                sample.update({k:v for k,v in frame.items() if k not in ['status','video_sha256']})
                ready += 1
            handle.write(json.dumps(sample, ensure_ascii=False)+'\n')
    create_json(OUT/'media_preparation_completion_v1.json', dict(time=timestamp(), expected=len(rows), ready=ready,
        unique_downloaded_bytes=len(unique), inputs_sha256=digest(path), labels_not_read=True,
        training_not_started=True, overlap_audit_still_required=True))


if __name__ == '__main__':
    main()
