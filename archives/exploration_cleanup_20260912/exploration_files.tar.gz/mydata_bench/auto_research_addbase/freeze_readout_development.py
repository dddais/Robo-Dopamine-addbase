"""Prospectively freeze native-readout-only central difference experiments."""
import yaml
from .common import *


def main():
    root=RESEARCH/'score_readout_development_v1';root.mkdir(parents=True,exist_ok=True)
    branches=[{'name':'baseline','k':0},{'name':'native_generation_baseline','k':0,'kind':'native_generation'},
              {'name':'zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame','query_scope':'readout'}]
    for k in [32,64]:branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
    recipes=[]
    for bias in [1.5,3.]:
        for scope in ['last_frame','all_frames']:
            for k in [32,64]:
                for control in (['target','wrong','low_rank'] if bias==1.5 and k==32 else ['target']):
                    prefix=f'{control}_readout_{scope}_b{bias:g}_k{k}'
                    for sign,value in [('plus',bias),('minus',-bias)]:
                        branches.append({'name':f'{prefix}_{sign}','k':k,'kind':'visual_preserve','bias':value,'scope':scope,
                                         'query_scope':'readout','region':'wrong' if control=='wrong' else 'target','head_group':'low' if control=='low_rank' else 'high'})
                    for gain in [3.,6.,12.,24.]:
                        recipes.append({'name':f'contrast_{prefix}_gamma{gain:g}','k':k,'scope':scope,'region':control,
                                        'central_difference_radius':bias,'direction_gain':gain,'contrast_weight':gain/(2*bias),
                                        'source_branches':['baseline',f'{prefix}_plus',f'{prefix}_minus']})
    recipes=[{'name':b['name'],'k':b['k'],'source_branches':[b['name']]} for b in branches]+recipes
    configs=[]
    for model in ['meter','rr','qwen']:
        for protocol in ['text_image','interleaved','image_text','video_text','text_video']:
            source=RESEARCH/f'score_development_v1/{model}_{protocol}';out=root/f'{model}_{protocol}'
            cfg=yaml.safe_load((ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_development_v1_{model}_{protocol}.yaml').read_text())
            cfg.update(output_dir=str(out),stage='prospectively_frozen_readout_query_development',branch_conditions=branches,conditions=recipes,
                combination='z0 + gamma * (z(+b)-z(-b))/(2b), at native score query only; every native score bin retained',
                selection_rule='Same full-data, four-directions, +10pp versus both native and typed baselines and superiority to original bias; extend on development234, freeze before confirmation498.',
                hypothesis='All-query steering modifies task-text and visual token representations. Isolating the native evaluation query preserves their computations and changes only how task-conditioned reward state gathers visual evidence. Smaller finite-difference radius checks nonlinear perturbation damage.',
                inference_query='Last trained prog token for Meter; final common ANSWER prefix token for discrete models. Never assume the final prompt token is the Meter readout.')
            path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_readout_development_v1_{model}_{protocol}.yaml'
            with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            rankpath=source/'ranking.json'
            if not rankpath.exists():rankpath=BASE/f'meter_{protocol}_v1/ranking.json' if model=='meter' else RESEARCH/f'development_v1/{model}_{protocol}/ranking.json'
            ranking=json.loads(rankpath.read_text());ranking.update(copied_from=str(rankpath),source_sha256=fingerprint(ranking));create_json(out/'ranking.json',ranking)
            create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':cfg['hypothesis'],'config':cfg,'config_sha256':fingerprint(cfg),'confirmation_metrics_used':False})
            configs.append(str(path))
    create_json(root/'prospective_plan.json',{'time':timestamp(),'configs':configs,'n_branches':len(branches),'n_readouts':len(recipes),'data':'Same frozen 60 examples /24 complete video clusters','no_confirmation_used':True})
    print(root,len(branches),len(recipes))


if __name__=='__main__':main()
