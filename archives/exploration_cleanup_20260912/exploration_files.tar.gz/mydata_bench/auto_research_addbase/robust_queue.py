"""Durable sequential jobs; failures preserved, no automatic retries."""
import argparse
import json
import os
import pathlib
import subprocess
import sys
import time
from .common import ROOT, append, timestamp, create_json
from .robust_prepare import DEST, digest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--gpu', type=int, required=True)
    parser.add_argument('--cases', required=True)
    args = parser.parse_args()
    plan = json.loads((DEST / 'frame_transport_frozen_plan_v1.json').read_text())
    chosen = set(args.cases.split(','))
    entries = [c for c in plan['configurations'] if c['model'] + '_' + c['protocol'] in chosen]
    if len(entries) != len(chosen):
        raise ValueError('Unknown/duplicate cases')
    log = DEST / f'queue_gpu{args.gpu}_events_v1.jsonl'
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(args.gpu), OMP_NUM_THREADS='2',
               OPENBLAS_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
    failures = []
    append(log, dict(time=timestamp(), event='queue_start', pid=os.getpid(), cases=sorted(chosen)))
    for case in entries:
        if digest(case['path']) != case['sha256']:
            raise ValueError('Frozen config changed')
        for stage in ['engineering', 'development']:
            while True:
                free = int(subprocess.check_output(['nvidia-smi', f'--id={args.gpu}',
                    '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
                if free >= (16000 if case['model'] == 'meter' else 28000):
                    break
                append(log, dict(time=timestamp(), event='memory_wait', free_mib=free))
                time.sleep(30)
            command = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.robust_runner',
                       '--config', case['path'], '--stage', stage]
            name = case['model'] + '_' + case['protocol']
            with (DEST / f'{name}_{stage}_stdout_v1.log').open('x') as handle:
                proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=handle, stderr=subprocess.STDOUT)
                append(log, dict(time=timestamp(), event='launch', pid=proc.pid, case=name, stage=stage, command=command))
                code = proc.wait()
            append(log, dict(time=timestamp(), event='exit', pid=proc.pid, case=name, stage=stage, returncode=code))
            if code:
                failures.append(dict(case=name, stage=stage, returncode=code))
                break
    create_json(DEST / f'queue_gpu{args.gpu}_completion_v1.json', dict(time=timestamp(), failures=failures, cases=sorted(chosen)))


if __name__ == '__main__':
    main()
