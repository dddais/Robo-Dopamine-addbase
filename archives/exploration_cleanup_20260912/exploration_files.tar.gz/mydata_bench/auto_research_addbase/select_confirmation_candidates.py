"""Rank complete development neighborhoods using an explicit maximin rule.

This proposes parameters; freeze_confirmation independently validates admission.
The rule is itself a development decision, not a retrospective preregistration.
"""
import argparse, collections, datetime, re
from .common import *

RULE = {
    'phase': 'Adaptive development selection; fixed before any confirmation inference',
    'window': 'Three consecutive measured k under identical remaining recipe parameters; primary is the middle k',
    'eligibility': 'Every point passes full234 vs both baselines and same-k original; primary also beats the single minimum-development-MAE original in MAE and total accuracy and lowers five-bin MAE for continuous models',
    'objective': 'Maximize the smallest of suc gain, fail gain, and total gain minus0.10, across the three k and both native/readout baselines',
    'ties': 'Fewer neural source branches, no confidence damping, no KL adaptation, larger average MAE improvement, then lexicographic stable identity',
    'motivation': 'Protect the weakest acceptance margin instead of selecting a large aggregate gain obtained at the expense of one class',
    'uncertainty': 'No p-value threshold or confirmation performance used for parameter selection; report selection bias and all frozen primary cases',
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--inventory')
    args = parser.parse_args()
    inventory_path = pathlib.Path(args.inventory) if args.inventory else sorted(RESEARCH.glob('candidate_inventory_*.json'))[-1]
    inventory = json.loads(inventory_path.read_text())
    cache = {}
    ranked = collections.defaultdict(list)
    for source, entry in inventory['experiments'].items():
        name = entry['model'] + '_' + entry['protocol']
        for neighborhood in entry['complete_stable_neighborhoods']:
            points = neighborhood['points']
            for offset in range(len(points) - 2):
                window = points[offset:offset + 3]
                primary = window[1]
                snapshot = primary['snapshot']
                if snapshot not in cache:
                    cache[snapshot] = json.loads(pathlib.Path(snapshot).read_text())
                r = cache[snapshot]['experiments'][name]
                summaries = r['summaries']
                continuous = entry['model'] in {'meter', 'sole'}
                loss = 'continuous_ordinal_mae' if continuous else 'mae'
                originals = [c for c, s in summaries.items() if re.fullmatch(r'original_all_k\d+', c) and s['complete']]
                best_original = min(originals, key=lambda c: (summaries[c]['overall'][loss], -summaries[c]['overall']['accuracy'], int(c.rsplit('k', 1)[1])))
                best = summaries[best_original]['overall']
                selected = summaries[primary['condition']]['overall']
                if not (selected[loss] < best[loss] and selected['accuracy'] > best['accuracy']):
                    continue
                if continuous and not all(selected['mae'] < summaries[b]['overall']['mae'] for b in ['baseline', 'native_generation_baseline']):
                    continue
                margins = []
                mae_gains = []
                for point in window:
                    value = r['contrasts'][point['condition']]
                    for contrast in [value, value['versus_native_generation']]:
                        margins.extend([contrast['suc_delta'], contrast['fail_delta'], contrast['accuracy_delta'] - .1])
                        mae_gains.append(-contrast['mae_delta'])
                recipe = neighborhood['recipe']
                complexity = (5 if recipe['mechanism'] == 'temporal_region_contrast' else 3,
                              int(bool(recipe['confidence_power'])), int(recipe['target_kl'] is not None))
                ranked[name].append({'folder': str(RESEARCH / source), 'primary': primary['condition'],
                                     'conditions': [p['condition'] for p in window], 'ks': [p['k'] for p in window],
                                     'recipe': recipe, 'minimum_acceptance_margin': min(margins),
                                     'average_mae_improvement': sum(mae_gains) / len(mae_gains), 'complexity_tiebreaker': complexity,
                                     'best_development_original': best_original, 'source_snapshot': snapshot})
    cases = []
    for name, choices in sorted(ranked.items()):
        choices.sort(key=lambda x: (-round(x['minimum_acceptance_margin'], 12), x['complexity_tiebreaker'],
                                   -round(x['average_mae_improvement'], 12), x['folder'], x['primary']))
        winner = choices[0]
        cases.append({key: winner[key] for key in ['folder', 'primary', 'conditions']})
        print(name, winner['recipe'], winner['ks'], 'weakest_margin', round(winner['minimum_acceptance_margin'], 4), flush=True)
    counts = collections.Counter(name.split('_', 1)[0] for name in ranked)
    stamp = datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
    path = RESEARCH / f'confirmation_candidate_selection_{stamp}.json'
    create_json(path, {'time': timestamp(), 'status': 'Development proposal only; independent freeze/admission required',
                       'rule': RULE, 'inventory_path': str(inventory_path), 'inventory_sha256': fingerprint(inventory),
                       'counts_by_model': dict(counts), 'preliminary_coverage_gate': sum(n >= 3 for n in counts.values()) >= 3,
                       'cases': cases, 'all_ranked_windows': dict(ranked)})
    print(path)


if __name__ == '__main__':
    main()
