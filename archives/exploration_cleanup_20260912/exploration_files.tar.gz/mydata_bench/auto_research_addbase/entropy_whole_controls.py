"""Whole-method exploratory controls from previously audited neural branches."""
import argparse
import collections
import numpy as np
from .common import *
from .entropy_development import entropy_scaled_logits, name_for
from .entropy_evaluation import OUTPUT
from .score_branches import score_readout
from mydata_bench.meter_eval.readout import canonicalize

CONTROL_ROOT = RESEARCH / 'entropy_evidence_whole_controls_v1'


def prepare():
    manifest = json.loads((OUTPUT / 'frozen_manifest_v1.json').read_text())
    sources = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']
        parent = pathlib.Path(case['confirmation_output_dir'])
        paths = [parent / n for n in ['sweep.jsonl', 'completed_branch_engineering_audit_v1.json', 'completed_recombination_audit_v1.json']]
        if case['parameters']['rho']:
            original = RESEARCH / 'post_confirmation_anchor_whole_controls_v1' / name
            paths += [original / n for n in ['sweep.jsonl', 'whole_method_control_engineering_audit_v1.json']]
        sources[name] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    create_json(CONTROL_ROOT / 'frozen_protocol_v1.json', {
        'time': timestamp(), 'evaluation_manifest_sha256': fingerprint(manifest), 'sources_sha256': sources,
        'source_sha256': {n: hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / n).read_bytes()).hexdigest()
                          for n in ['entropy_whole_controls.py', 'entropy_development.py', 'metrics.py', 'analyze_development.py']},
        'protocol': 'All nine cases retained. Verify parent raw-zero and recombination audits. Nonzero-rho cases require previously exact original-target/baseline/zero neural duplicates. Compute full target, full zero, full wrong and full low using the frozen selected entropy parameters, with both evidence and original anchor changed for wrong/low. Require exact target replay and zero. Compare only named feasible control subsets; retain all primary samples.',
        'boundary': 'Post-confirmation reused498 controls, constructed from actual previously recorded and audited neural branches. No new neural run is claimed here. Zero is a composition of audited observed/static zero-evidence branches and, when needed, the original-bias zero forward. Entropy is computed from the same unchanged native baseline.'})
    print(CONTROL_ROOT / 'frozen_protocol_v1.json')


def indexed(path):
    result = collections.defaultdict(dict)
    for row in read_rows(path):
        row = canonicalize(row); result[row['condition']][row['example_id']] = row
    return result


def run():
    protocol = json.loads((CONTROL_ROOT / 'frozen_protocol_v1.json').read_text())
    manifest = json.loads((OUTPUT / 'frozen_manifest_v1.json').read_text())
    if not (OUTPUT / 'summary_v1.json').exists() or fingerprint(manifest) != protocol['evaluation_manifest_sha256']:
        raise ValueError('Wait for unchanged complete evaluation')
    for name, sha in protocol['source_sha256'].items():
        if hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / name).read_bytes()).hexdigest() != sha:
            raise ValueError('Frozen analysis source changed')
    ids = json.loads(pathlib.Path(manifest['partitions']['reused_validation']).read_text())
    if fingerprint(ids) != manifest['partition_ids_sha256']['reused_validation']:
        raise ValueError('Frozen reused-validation IDs changed')
    generated = {}; checks = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; parameters = case['parameters']; out = CONTROL_ROOT / name
        if out.exists():
            raise ValueError('Do not overwrite or silently restart control generation')
        for path, sha in protocol['sources_sha256'][name].items():
            if hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest() != sha:
                raise ValueError('Audited neural source changed')
        folder = pathlib.Path(case['confirmation_output_dir']); parent = indexed(folder / 'sweep.jsonl')
        raw = json.loads((folder / 'completed_branch_engineering_audit_v1.json').read_text())
        recombination = json.loads((folder / 'completed_recombination_audit_v1.json').read_text())
        if not raw['complete_attempts_and_consistent_duplicates'] or not recombination['all_frozen_outputs_reproduced_exactly']:
            raise ValueError('Parent engineering audit failed')
        if not raw['zero_audits'] or any(z['n_exact'] != len(ids) for z in raw['zero_audits'].values()):
            raise ValueError('Parent zero audit failed')
        primary_k = case['selected_ks'][case['conditions'].index(case['primary'])]
        original_names = {'target': f'original_all_k{primary_k}', 'zero': 'baseline', 'wrong': 'baseline', 'low': 'baseline'}
        original = parent; original_parity = 'rho0: original term is absent'
        if parameters['rho']:
            original_folder = RESEARCH / 'post_confirmation_anchor_whole_controls_v1' / name
            proof = json.loads((original_folder / 'whole_method_control_engineering_audit_v1.json').read_text())
            if not proof['all_required_parity_exact']:
                raise ValueError('Required original-branch neural parity failed')
            original = indexed(original_folder / 'sweep.jsonl')
            original_names = {'target': 'original_target_primary', 'zero': 'zero_primary',
                              'wrong': 'original_wrong_primary', 'low': 'original_low_rank_primary'}
            original_parity = proof
        primary = name_for(parameters, case['primary'])
        evaluated = {r['example_id']: r for r in read_rows(OUTPUT / name / 'scores.jsonl')
                     if r['condition'] == primary and r['partition'] == 'reused_validation'}
        evidence_names = {'target': case['primary'], 'zero': 'baseline',
                          'wrong': 'control_wrong_primary', 'low': 'control_low_rank_primary'}
        out.mkdir(); rows = collections.defaultdict(dict); target_bad = []; zero_bad = []
        with (out / 'scores.jsonl').open('x') as handle:
            for role, evidence in evidence_names.items():
                for eid in ids:
                    required = [parent[evidence].get(eid), parent['baseline'].get(eid), original[original_names[role]].get(eid)]
                    row = {'example_id': eid, 'condition': 'whole_' + role, 'parameters': parameters,
                           'parent_evidence_condition': evidence, 'original_condition': original_names[role]}
                    if any(r is None or r.get('status') != 'ok' for r in required):
                        row.update(status='error', error='One or more whole-method control sources invalid')
                    else:
                        logits, diagnostics = entropy_scaled_logits(*(r['score_logits'] for r in required), **parameters)
                        row.update(status='ok', score_logits=logits, **score_readout(logits, case['model']), **diagnostics)
                    fields = ['status', 'score_logits', 'progress', 'native_prediction']
                    if role == 'target' and any(row.get(f) != evaluated.get(eid, {}).get(f) for f in fields):
                        target_bad.append(eid)
                    if role == 'zero' and any(row.get(f) != parent['baseline'][eid].get(f) for f in fields):
                        zero_bad.append(eid)
                    handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n'); rows[row['condition']][eid] = row
            handle.flush(); os.fsync(handle.fileno())
        values = [r['evidence_multiplier'] for r in rows['whole_target'].values() if r['status'] == 'ok']
        checks[name] = {'parent_raw_and_recombination_verified': True, 'parent_zero_audits': raw['zero_audits'],
                        'original_neural_parity': original_parity, 'target_replay_mismatch_ids': target_bad,
                        'whole_zero_mismatch_ids': zero_bad, 'all_required_parity_exact': not target_bad and not zero_bad,
                        'evidence_multiplier': {'n': len(values), 'min': min(values), 'median': float(np.median(values)),
                                                'mean': float(np.mean(values)), 'max': max(values)},
                        'scores_sha256': hashlib.sha256((out / 'scores.jsonl').read_bytes()).hexdigest()}
        create_json(out / 'engineering_audit_v1.json', checks[name]); generated[name] = rows
        print(name, 'whole target/zero exact', checks[name]['all_required_parity_exact'], flush=True)
    from .metrics import summarize
    from .analyze_development import contrast
    label_blob = (BASE / 'inputs/labels.jsonl').read_bytes()
    if hashlib.sha256(label_blob).hexdigest() != manifest['labels_sha256']:
        raise ValueError('Frozen labels changed')
    labels = {r['example_id']: r for r in map(json.loads, label_blob.decode().splitlines())}; reports = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; rows = generated[name]; comparisons = {}
        if checks[name]['all_required_parity_exact']:
            for condition in ['whole_wrong', 'whole_low']:
                feasible = [i for i in ids if rows[condition][i]['status'] == 'ok' and rows['whole_target'][i]['status'] == 'ok']
                target = summarize(rows['whole_target'].values(), labels, feasible)
                control = summarize(rows[condition].values(), labels, feasible)
                effect = contrast(target, control, case['model'] in {'meter', 'sole'}); effect.pop('confirmation', None)
                comparisons[condition] = {'n_expected': len(ids), 'n_feasible': len(feasible),
                    'excluded_ids': [i for i in ids if i not in set(feasible)], 'target_on_feasible_subset': target,
                    'control_on_feasible_subset': control, 'target_minus_control': effect}
        reports[name] = {'parameters': case['parameters'], 'engineering': checks[name],
                         'whole_method_summaries': {n: summarize(r.values(), labels, ids) for n, r in rows.items()},
                         'comparisons_if_parity_valid': comparisons}
    create_json(CONTROL_ROOT / 'analysis_v1.json', {
        'time': timestamp(), 'protocol_sha256': fingerprint(protocol), 'cases': reports,
        'all_nine_required_parity_audits_pass': all(c['all_required_parity_exact'] for c in checks.values()),
        'boundary': protocol['boundary']})
    print(CONTROL_ROOT / 'analysis_v1.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--prepare', action='store_true'); args = parser.parse_args()
    prepare() if args.prepare else run()
