"""Freeze development234 amplitude/confidence ablations and neighboring heads."""
import argparse,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--protocol',required=True)
    p.add_argument('--scope',default='all_frames');p.add_argument('--mechanism',choices=['region','temporal'],default='region');p.add_argument('--reason',required=True);a=p.parse_args()
    name=f'{a.model}_{a.protocol}';screen=RESEARCH/f'score_native_confidence_development_v1/{name}';out=RESEARCH/f'score_native_confidence_development_full_v1/{name}'
    cfg=json.loads((screen/'config.json').read_text());ks=[24,32,40,48,56,60,64,68,72]
    branches=[{'name':'baseline','k':0},{'name':'native_generation_baseline','k':0,'kind':'native_generation'},
        {'name':'zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame'}]
    if a.mechanism=='temporal':branches.extend([{'name':'static_baseline','k':0,'media_condition':'static_first'},
        {'name':'static_zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame','media_condition':'static_first'}])
    recipes=[]
    for k in ks:
        branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
        for control in (['target','wrong','low_rank'] if k in [32,64] else ['target']):
            prefix=f'{control}_{a.scope}_b3_k{k}';sources=['baseline',prefix+'_plus',prefix+'_minus']
            for static in ([False,True] if a.mechanism=='temporal' else [False]):
                for sign,bias in [('plus',3.),('minus',-3.)]:branches.append({'name':('static_' if static else '')+prefix+'_'+sign,
                    'k':k,'kind':'visual_preserve','bias':bias,'scope':a.scope,'region':'wrong' if control=='wrong' else 'target',
                    'head_group':'low' if control=='low_rank' else 'high','media_condition':'static_first' if static else 'observed'})
            if a.mechanism=='temporal':sources+=['static_'+prefix+'_plus','static_'+prefix+'_minus']
            for weight in [4.,8.,12.,16.]:
                recipe={'name':f'contrast_{control}_uniform_matched_{a.mechanism}_{a.scope}_b3_k{k}_lambda{weight:g}',
                    'k':k,'scope':a.scope,'region':control,'contrast_weight':weight,'source_branches':sources,
                    'combination_type':'region_contrast' if a.mechanism=='region' else 'temporal_region_contrast'}
                recipes.append(recipe)
                for power in [1.,2.]:recipes.append({**recipe,'name':recipe['name'].replace('_uniform_matched_','_confidence_')+f'_power{power:g}','native_confidence_power':power})
    cfg.update(output_dir=str(out),stage='prospectively_frozen_full_development_confidence_and_matched_amplitude',
        example_ids_file=str(RESEARCH/'development_v1/development_ids.json'),branch_conditions=branches,
        conditions=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes)
    path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_confidence_full_development_v1_{name}.yaml'
    with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
    create_json(out/'ranking.json',json.loads((screen/'ranking.json').read_text()))
    ids=set(json.loads(pathlib.Path(cfg['example_ids_file']).read_text()));expected={c['name']:c for c in branches};selected={};reuse=[];conflicts=[]
    defaults={'kind':None,'k':0,'scope':'last_frame','region':'target','head_group':'high','media_condition':'observed','query_scope':'all','bias':3.}
    for source in [RESEARCH/f'score_temporal_development_full_v1/{name}/score_branches.jsonl',
        RESEARCH/f'score_development_full_v1/{name}/score_branches.jsonl',screen/'score_branches.jsonl']:
        if not source.exists():continue
        blob=source.read_bytes();digest=hashlib.sha256(blob).hexdigest();count=0
        for line in blob.decode().splitlines():
            r=json.loads(line);key=(r['example_id'],r['condition'])
            if key[0] not in ids or key[1] not in expected:continue
            if any(r.get('condition_config',{}).get(k,v)!=expected[key[1]].get(k,v) for k,v in defaults.items()):continue
            if key in selected:
                if any(r.get(k)!=selected[key].get(k) for k in ['status','score_logits','success_probability']):conflicts.append({'example_id':key[0],'condition':key[1],'lower_priority_source':str(source)})
                continue
            selected[key]={**r,'reused_from':str(source),'reused_source_sha256':digest,'reuse_time':timestamp()};count+=1
        reuse.append({'source':str(source),'sha256':digest,'reused_rows':count})
    for r in selected.values():append(out/'score_branches.jsonl',r)
    create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':a.reason,'config':cfg,'config_sha256':fingerprint(cfg),
        'ks':ks,'uniform_weight_matched_ablation':True,'reuse':reuse,'duplicate_source_differences':conflicts,
        'priority':'existing full development first, then screen; original outputs untouched','confirmation_metrics_used':False})
    print(path,'neural branches',len(branches),'readouts',len(cfg['conditions']),'reused',len(selected),'conflicts',len(conflicts))


if __name__=='__main__':main()
