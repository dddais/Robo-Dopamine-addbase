"""Final completion evidence, preserving failed independent confirmation."""
import argparse
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline-report', required=True)
    parser.add_argument('--research-report', required=True)
    args = parser.parse_args()
    baseline = pathlib.Path(args.baseline_report).resolve()
    final_report = pathlib.Path(args.research_report).resolve()
    paths = {}
    def get(relative):
        path = RESEARCH / relative
        paths[relative] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        return json.loads(path.read_text())
    watch = {}
    for name in ['completion_analyses_v1', 'final_baseline_record_audit_watcher_v1']:
        plan = get(name + '/plan.json')
        events = list(read_rows(RESEARCH / name / 'events.jsonl'))
        exits = {e['name']: e['returncode'] for e in events if e['event'] == 'exit'}
        jobs = plan['tasks']
        assert all(exits.get(job['name']) == 0 for job in jobs), (name, exits)
        watch[name] = exits
    b = json.loads((baseline / 'source_manifest.json').read_text())
    assert b['completion_checks_passed'] and b['pairwise_rows'] == 180 and b['target_effect_rows'] == 45
    for item in b['inputs'].values():
        assert hashlib.sha256(pathlib.Path(item['path']).read_bytes()).hexdigest() == item['sha256']
    a = json.loads(pathlib.Path(b['inputs']['attention_audit']['path']).read_text())
    assert len(a['experiments']) == 15
    assert all(e['all_expected_conditions_attempted'] for e in a['experiments'].values())
    records = json.loads(pathlib.Path(b['inputs']['record_audit']['path']).read_text())
    assert records['all_scientific_duplicate_records_consistent']
    original = get('confirmation_v1/confirmation_analysis_20260909T190153.json')
    assert not original['at_least_three_models_with_three_point_accepted_protocols']
    assert not original['cases']['rr_text_video']['confirmation_case_point_acceptance']
    shared = get('shared_entropy_evaluation_v1/summary_v1.json')
    for partition in ['development', 'reused_validation', 'full_cohort']:
        assert shared['three_models_three_inputs_point_by_partition'][partition]
        assert shared['three_models_three_inputs_strict_by_partition'][partition]
    direct = get('shared_entropy_evaluation_v1/direct_final_acceptance_audit_v1.json')
    assert direct['all_main_sample_gates_pass']
    assert get('shared_entropy_evaluation_v1/final_frozen_lineage_audit_v1.json')['all_frozen_lineage_checks_passed']
    assert get('shared_entropy_evaluation_v1/algebraic_invariance_audit_v1.json')['all_pass']
    assert get('shared_entropy_whole_controls_v1/analysis_v1.json')['all_nine_required_parity_audits_pass']
    assert get('final_postprocess_ablations_v1/analysis_v1.json')['all_nine_final_replays_exact_and_scores_valid']
    assert get('final_raw_audits_v1/all_eighteen_case_audit_index_v1.json')['all_exact_no_scientific_conflicts']
    secondary = get('shared_entropy_evaluation_v1/secondary_threshold_descriptive_audit_v1.json')
    mtv = secondary['cases']['meter_text_video']
    assert mtv['partitions']['full_cohort'][mtv['primary']]['native_generation_baseline']['delta']['suc'] < 0
    required = [baseline / 'report.md', baseline / 'figures/all_target_effects.png', baseline / 'figures/all_target_effects.svg',
                final_report, ROOT / 'mydata_bench/exp_plan_addbase_summary.md', ROOT / 'exp_plan_addbase_auto_explore.md',
                ROOT / 'mydata_bench/auto_research_addbase/LITERATURE_AND_HYPOTHESES_20260908.md',
                ROOT / 'mydata_bench/auto_research_addbase/REPRODUCTION_GUIDE_20260909.md',
                RESEARCH / 'final_descriptive_tables_v1/report.md', RESEARCH / 'final_descriptive_tables_v1/per_task_split_metrics.csv']
    assert all(p.is_file() and p.stat().st_size > 0 for p in required)
    text = final_report.read_text()
    assert all(term in text for term in ['0.125', '0.2', '独立', '复用', 'SOLE', '846', '1213'])
    out = RESEARCH / 'final_completion_audit_v1.json'
    create_json(out, {'time': timestamp(), 'mainline1_all_planned_attempts_and_reports_complete': True,
                     'mainline2_literature_and_theory_documented': True,
                     'mainline3_frozen_primary_metric_observed_gate_met': True,
                     'all_three_mainlines_closed_with_stated_scope': True,
                     'independent_generalization_established': False,
                     'both_thresholds_all_classes_improved': False,
                     'four_models_passed': False,
                     'all_tasks_or_pairwise_metrics_improved': False,
                     'mandatory_watcher_exit_codes': watch,
                     'evidence': paths,
                     'deliverables': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in required},
                     'scope': 'Completion is the requested experiments, literature, theory, implementation and dataset observation gate under the frozen primary 0.125/0.875 continuous-model endpoint metric. Reused validation is exploratory. Independent confirmation failure and secondary-threshold, SOLE, task, official-input and pairwise limits remain explicit.',
                     'analysis_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()})
    print(out)


if __name__ == '__main__':
    main()
