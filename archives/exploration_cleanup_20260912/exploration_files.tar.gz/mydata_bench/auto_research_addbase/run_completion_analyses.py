"""Run fixed analyses once their complete scientific sources are available."""
import argparse
import subprocess
import time
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan-root', default=str(RESEARCH / 'completion_analyses_v1'))
    args = parser.parse_args()
    root = output_path(args.plan_root)
    plan = json.loads((root / 'plan.json').read_text())
    events = root / 'events.jsonl'
    completed = set()
    if events.exists():
        history = list(read_rows(events))
        if any(e['event'] == 'launch' for e in history):
            raise RuntimeError('This watcher already launched analyses; inspect prior run before resuming')
    append(events, {'event': 'watcher_started', 'time': timestamp(), 'pid': os.getpid(), 'plan_sha256': fingerprint(plan)})
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    while len(completed) < len(plan['tasks']):
        for task in plan['tasks']:
            if task['name'] in completed or not all(pathlib.Path(p).exists() for p in task['requires']):
                continue
            command = [sys.executable, '-u', '-m', 'mydata_bench.auto_research_addbase.' + task['module']] + task.get('args', [])
            with (root / (task['name'] + '.log')).open('x') as log:
                child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
                append(events, {'event': 'launch', 'time': timestamp(), 'name': task['name'], 'pid': child.pid, 'command': command})
                code = child.wait()
            append(events, {'event': 'exit', 'time': timestamp(), 'name': task['name'], 'returncode': code})
            completed.add(task['name'])
            # An analysis error is retained and reported; unrelated completed
            # sources can still be audited. Never select/retry parameters here.
        if len(completed) < len(plan['tasks']):
            time.sleep(20)
    append(events, {'event': 'watcher_completed', 'time': timestamp()})


if __name__ == '__main__':
    main()
