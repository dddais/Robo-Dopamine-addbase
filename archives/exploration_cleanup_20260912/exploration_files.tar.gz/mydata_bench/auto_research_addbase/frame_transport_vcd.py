"""Fixed VCD-style visual prior correction on frame-local transport.

No label, endpoint, entropy, fitted scale, or per-case hyperparameter enters
the calculation. All native score bins remain present.
"""
import hashlib
import torch


def diffusion_corruption(tensor, seed, noise_step=500):
    if noise_step != 500:
        raise ValueError('F2 prospectively fixes diffusion step 500')
    betas = torch.sigmoid(torch.linspace(-6, 6, 1000)) * (.005-1e-5) + 1e-5
    alpha = torch.cumprod(1-betas, 0)[noise_step]
    generator = torch.Generator(device='cpu').manual_seed(seed)
    noise = torch.randn(tensor.shape, generator=generator, dtype=torch.float32)
    return (alpha.sqrt().to(tensor.device)*tensor.float() +
            (1-alpha).sqrt().to(tensor.device)*noise.to(tensor.device)).to(tensor.dtype)


def sample_seed(video_sha256, protocol, pixel_field):
    # Identical videos under different instructions have identical corruption.
    payload = 'robust-F2-seed0:' + video_sha256 + ':' + protocol + ':' + pixel_field
    return int(hashlib.sha256(payload.encode()).hexdigest()[:15], 16)


def contrast_logits(clean, corrupted, weight=1.):
    if weight not in (0., 1.):
        raise ValueError('F2 permits fixed weight1 or the zero control only')
    a, b = torch.tensor(clean, dtype=torch.float64), torch.tensor(corrupted, dtype=torch.float64)
    if a.ndim != 1 or a.shape != b.shape or not torch.isfinite(a).all() or not torch.isfinite(b).all():
        raise ValueError('Complete finite equal-size native logit vectors required')
    if weight == 0.:
        return list(clean)
    return (a + (a-b)).tolist()
