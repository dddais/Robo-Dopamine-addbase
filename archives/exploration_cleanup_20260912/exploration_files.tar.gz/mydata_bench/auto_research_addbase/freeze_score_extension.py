"""Create a new full-development extension with both readout controls."""
import argparse,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--model',required=True);p.add_argument('--protocol',required=True);p.add_argument('--scopes',default='last_frame');p.add_argument('--reason',required=True);a=p.parse_args()
    source=RESEARCH/f'score_development_v1/{a.model}_{a.protocol}';out=RESEARCH/f'score_development_full_v1/{a.model}_{a.protocol}';out.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((source/'config.json').read_text());scopes=a.scopes.split(',')
    branches=[{'name':'baseline','k':0},{'name':'native_generation_baseline','k':0,'kind':'native_generation'}]
    for k in [32,64]:branches.append({'name':f'zero_preserve_k{k}','k':k,'kind':'visual_preserve','bias':0.,'scope':'last_frame'})
    for k in [8,24,32,40,48,64]:branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
    recipes=[]
    for scope in scopes:
        for k in [24,32,40,48,64]:
            for control in (['target','wrong','low_rank'] if k in [32,64] else ['target']):
                prefix=f'{control}_{scope}_b3_k{k}'
                for sign,bias in [('plus',3.),('minus',-3.)]:branches.append({'name':f'{prefix}_{sign}','k':k,'kind':'visual_preserve','bias':bias,'scope':scope,'region':'wrong' if control=='wrong' else 'target','head_group':'low' if control=='low_rank' else 'high'})
                for weight in [1.,2.,3.,4.]:recipes.append({'name':f'contrast_{prefix}_lambda{weight:g}','k':k,'contrast_weight':weight,'scope':scope,'region':control,'source_branches':['baseline',f'{prefix}_plus',f'{prefix}_minus']})
    recipes=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes
    cfg.update(output_dir=str(out),example_ids_file=str(RESEARCH/'development_v1/development_ids.json'),stage='full_development_after_prospective_score_screen',branch_conditions=branches,conditions=recipes)
    path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_full_development_v1_{a.model}_{a.protocol}.yaml'
    with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
    ranking=json.loads((source/'ranking.json').read_text());ranking.update(copied_from=str(source/'ranking.json'),source_sha256=fingerprint(ranking));create_json(out/'ranking.json',ranking)
    create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':a.reason,'config_sha256':fingerprint(cfg),'config':cfg,'confirmation_new_method_metrics_used_for_selection':False})
    print(path,len(branches),'branches',len(recipes),'readouts')
if __name__=='__main__':main()
