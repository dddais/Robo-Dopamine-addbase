"""Freeze and run all F6 fitting cases after verified training preparation."""
import concurrent.futures
import json
import os
import pathlib
import subprocess
import sys
import time
from .common import ROOT, append, create_json, timestamp
from .prepare_external_head_training import OUT
from .robust_prepare import DEST, digest


def worker(gpu,cases):
    events=DEST/f'f6_fit_queue_gpu{gpu}_events_v1.jsonl'
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    failures=[]
    for item in cases:
        name=item['model']+'_'+item['protocol']
        if digest(item['path'])!=item['sha256']:
            raise ValueError('F6 fit configuration changed')
        while True:
            free=int(subprocess.check_output(['nvidia-smi',f'--id={gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
            if free>=32000:
                break
            append(events,dict(time=timestamp(),event='memory_wait',free_mib=free))
            time.sleep(20)
        command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.reward_gradient_fit','--config',item['path']]
        with (DEST/f'f6_fit_{name}_stdout_v1.log').open('x') as handle:
            p=subprocess.Popen(command,cwd=ROOT,env=env,stdout=handle,stderr=subprocess.STDOUT)
            append(events,dict(time=timestamp(),event='launch',case=name,pid=p.pid,command=command))
            code=p.wait()
        append(events,dict(time=timestamp(),event='exit',case=name,pid=p.pid,returncode=code))
        if code:
            failures.append(dict(case=name,returncode=code))
    create_json(DEST/f'f6_fit_queue_gpu{gpu}_completion_v1.json',dict(time=timestamp(),failures=failures,cases=[c['model']+'_'+c['protocol'] for c in cases]))
    return failures


def main():
    sources=['reward_gradient_attention.py','reward_gradient_fit.py','reward_gradient_ranking.py','reward_gradient_engineering.py','freeze_reward_gradient_fit.py']
    hashes={name:digest(ROOT/'mydata_bench/auto_research_addbase'/name) for name in sources}
    create_json(DEST/'f6_fit_queue_plan_v1.json',dict(time=timestamp(),pid=os.getpid(),source_sha256=digest(__file__),dependency_sha256=hashes,
        role='fit on independent public training only; no reward-model evaluation on reserved test',gpus=[0,3]))
    launch=json.loads((OUT/'preparation_queue_launch_v1.json').read_text())
    while not (OUT/'preparation_queue_completion_v1.json').exists():
        p=pathlib.Path('/proc')/str(launch['pid'])/'cmdline'
        if not p.exists() or b'mydata_bench.auto_research_addbase.external_head_training_queue' not in p.read_bytes():
            raise RuntimeError('Training preparation queue vanished without completion; inspect')
        time.sleep(20)
    for name,expected in hashes.items():
        if digest(ROOT/'mydata_bench/auto_research_addbase'/name)!=expected:
            raise ValueError('Prospective F6 fitting source changed')
    command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.freeze_reward_gradient_fit']
    with (DEST/'f6_fit_freeze_stdout_v1.log').open('x') as handle:
        result=subprocess.run(command,cwd=ROOT,stdout=handle,stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError('F6 fit freeze failed; preserve and inspect')
    plan=json.loads((DEST/'reward_gradient_fit_frozen_plan_v1.json').read_text())
    a=[c for c in plan['configurations'] if c['model']=='rr' or c['model']=='qwen' and c['protocol'] in ['text_video','video_text','text_image']]
    b=[c for c in plan['configurations'] if c not in a]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        jobs=[pool.submit(worker,0,a),pool.submit(worker,3,b)]
        failures=[row for job in jobs for row in job.result()]
    create_json(DEST/'f6_all_fit_queues_completion_v1.json',dict(time=timestamp(),failures=failures,
        fitting_only=True,validation_development_and_reserved_test_evaluation_still_required=True))


if __name__=='__main__':
    main()
