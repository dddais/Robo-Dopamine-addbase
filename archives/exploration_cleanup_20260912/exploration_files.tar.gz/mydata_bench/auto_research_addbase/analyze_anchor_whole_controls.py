"""Whole-method controls for the four nonzero-anchor exploratory recipes."""
import collections
from .common import *
from .anchor_development import anchored_logits
from .score_branches import score_readout
from mydata_bench.meter_eval.readout import canonicalize


def main():
    root = RESEARCH / 'post_confirmation_anchor_whole_controls_v1'
    manifest = json.loads((root / 'frozen_manifest_v1.json').read_text())
    anchor_path = pathlib.Path(manifest['anchor_manifest_path'])
    anchor = json.loads(anchor_path.read_text())
    if fingerprint(anchor) != manifest['anchor_manifest_sha256']:
        raise ValueError('Anchor recipe changed')
    if not (anchor_path.parent / 'summary_v1.json').exists():
        raise ValueError('Wait for complete frozen anchor evaluation')
    protocol = json.loads((root / 'analysis_protocol_v1.json').read_text())
    if hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest() != protocol['analysis_source_sha256']:
        raise ValueError('Frozen whole-control analysis changed')
    for name, sha in protocol['metric_source_sha256'].items():
        if hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / name).read_bytes()).hexdigest() != sha:
            raise ValueError('Frozen metrics changed')
    ids = json.loads(pathlib.Path(anchor['partitions']['reused_validation']).read_text())
    if fingerprint(ids) != anchor['partition_ids_sha256']['reused_validation']:
        raise ValueError('Frozen validation IDs changed')
    checks = {}; generated = {}; parent_views = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; folder = pathlib.Path(case['output_dir'])
        if not (folder / 'combination_events.jsonl').exists():raise ValueError('Wait for all neural controls')
        source = pathlib.Path(case['parent_confirmation_output_dir']) / 'sweep.jsonl'
        wanted = {'baseline', case['parent_original_condition'], case['parent_primary'], 'control_wrong_primary', 'control_low_rank_primary'}
        parent = collections.defaultdict(dict)
        parent_blob = source.read_bytes()
        for line in parent_blob.decode().splitlines():
            row = canonicalize(json.loads(line))
            if row['condition'] in wanted:parent[row['condition']][row['example_id']] = row
        control_blob = (folder / 'sweep.jsonl').read_bytes()
        controls = collections.defaultdict(dict)
        for line in control_blob.decode().splitlines():
            row = canonicalize(json.loads(line)); controls[row['condition']][row['example_id']] = row
        eval_blob = (anchor_path.parent / name / 'scores.jsonl').read_bytes()
        primary = f'anchor_rho{case["rho"]:g}__{case["parent_primary"]}'
        evaluated = {r['example_id']: r for r in map(json.loads, eval_blob.decode().splitlines())
                     if r['condition'] == primary and r['partition'] == 'reused_validation'}
        parity = {}
        fields = ['score_logits', 'progress', 'native_prediction']
        for label, left, right in [('native_baseline_duplicate', controls['baseline'], parent['baseline']),
                                    ('original_target_duplicate', controls['original_target_primary'], parent[case['parent_original_condition']]),
                                    ('original_bias_zero', controls['zero_primary'], controls['baseline'])]:
            bad = [eid for eid in ids if left.get(eid, {}).get('status') != 'ok' or right.get(eid, {}).get('status') != 'ok'
                   or any(left[eid].get(f) != right[eid].get(f) for f in fields)]
            parity[label] = {'n_expected': len(ids), 'n_exact': len(ids) - len(bad), 'mismatch_or_invalid_ids': bad}
        new_rows = collections.defaultdict(dict)
        recipes = [('full_anchored_target', case['parent_primary'], 'original_target_primary'),
                   ('full_anchored_zero', 'baseline', 'zero_primary'),
                   ('full_anchored_wrong', 'control_wrong_primary', 'original_wrong_primary'),
                   ('full_anchored_low_rank', 'control_low_rank_primary', 'original_low_rank_primary')]
        replay_bad = []; zero_bad = []
        for condition, evidence_name, original_name in recipes:
            for eid in ids:
                required = [parent[evidence_name].get(eid), parent['baseline'].get(eid), controls[original_name].get(eid)]
                row = {'time': timestamp(), 'example_id': eid, 'condition': condition, 'rho': case['rho'],
                       'parent_evidence_condition': evidence_name, 'new_original_control': original_name}
                if any(r is None or r.get('status') != 'ok' for r in required):
                    row.update(status='error', error='One or more component controls invalid')
                else:
                    logits = anchored_logits(*(r['score_logits'] for r in required), case['rho'])
                    row.update(status='ok', score_logits=logits, **score_readout(logits, case['model']))
                    if condition == 'full_anchored_target' and any(row.get(f) != evaluated.get(eid, {}).get(f) for f in fields):replay_bad.append(eid)
                    if condition == 'full_anchored_zero' and any(row.get(f) != parent['baseline'][eid].get(f) for f in fields):zero_bad.append(eid)
                append(folder / 'whole_method_control_scores_v1.jsonl', row)
                new_rows[condition][eid] = row
        checks[name] = {'sources_sha256': {'parent_sweep': hashlib.sha256(parent_blob).hexdigest(),
                       'new_controls_sweep': hashlib.sha256(control_blob).hexdigest(), 'anchor_evaluation_scores': hashlib.sha256(eval_blob).hexdigest()},
                       'parity': parity, 'target_replay_mismatch_ids': replay_bad, 'whole_zero_mismatch_ids': zero_bad,
                       'all_required_parity_exact': all(v['n_exact'] == len(ids) for v in parity.values()) and not replay_bad and not zero_bad}
        create_json(folder / 'whole_method_control_engineering_audit_v1.json', checks[name])
        generated[name] = new_rows; parent_views[name] = parent
        print(name, 'whole-method parity exact', checks[name]['all_required_parity_exact'], flush=True)
    # No labels were accessed while constructing or auditing the new controls.
    from .metrics import summarize
    from .analyze_development import contrast
    label_blob = (BASE / 'inputs/labels.jsonl').read_bytes()
    if hashlib.sha256(label_blob).hexdigest() != anchor['labels_sha256']:raise ValueError('Frozen labels changed')
    labels = {r['example_id']: r for r in map(json.loads, label_blob.decode().splitlines())}
    reports = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; rows = generated[name]
        comparisons = {}
        if checks[name]['all_required_parity_exact']:
            for condition in ['full_anchored_wrong', 'full_anchored_low_rank']:
                feasible = [i for i in ids if rows[condition][i]['status'] == 'ok' and rows['full_anchored_target'][i]['status'] == 'ok']
                target = summarize(rows['full_anchored_target'].values(), labels, feasible)
                control = summarize(rows[condition].values(), labels, feasible)
                effect = contrast(target, control, case['model'] in {'meter', 'sole'}); effect.pop('confirmation', None)
                comparisons[condition] = {'n_expected': len(ids), 'n_feasible': len(feasible),
                    'excluded_ids': [i for i in ids if i not in set(feasible)], 'target_on_feasible_subset': target,
                    'control_on_feasible_subset': control, 'target_minus_control': effect}
        reports[name] = {'rho': case['rho'], 'primary_k': case['primary_k'], 'engineering': checks[name],
                         'whole_method_summaries': {n: summarize(r.values(), labels, ids) for n, r in rows.items()},
                         'comparisons_if_parity_valid': comparisons}
    create_json(root / 'whole_method_control_analysis_v1.json', {'time': timestamp(), 'manifest_sha256': fingerprint(manifest),
                'analysis_protocol_sha256': fingerprint(protocol), 'cases': reports,
                'all_four_required_parity_audits_pass': all(v['all_required_parity_exact'] for v in checks.values()),
                'scope': 'Both parent evidence and the original-method anchor use wrong regions or low heads in these full controls. Invalid geometry is retained and only explicit feasible subsets are compared. The zero combines cached parent zero-evidence parity with a new original-bias zero forward. These are post-confirmation exploratory controls on reused498, not a fresh independent efficacy confirmation.'})
    print(root / 'whole_method_control_analysis_v1.json', flush=True)


if __name__ == '__main__':main()
