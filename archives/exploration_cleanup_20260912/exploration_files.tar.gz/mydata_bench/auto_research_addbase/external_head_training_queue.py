"""Run training media overlap audit, noun parsing and grounding in order."""
import json
import os
import pathlib
import subprocess
import sys
import time
from .common import ROOT, append, create_json, timestamp
from .prepare_external_head_training import OUT
from .robust_prepare import digest


def main():
    modules = ['audit_external_head_training', 'parse_external_head_training', 'ground_external_head_training']
    hashes = {name:digest(ROOT/f'mydata_bench/auto_research_addbase/{name}.py') for name in modules}
    create_json(OUT/'preparation_queue_plan_v1.json',dict(time=timestamp(),pid=os.getpid(),source_sha256=digest(__file__),modules_sha256=hashes,
        media_preparation_required=True,eligible_rows_only_after_overlap_audit=True,
        training_labels_not_read=True,test_labels_and_model_performance_not_read=True))
    launch = json.loads((OUT/'media_preparation_launch_v1.json').read_text())
    while not (OUT/'media_preparation_completion_v1.json').exists():
        p = pathlib.Path('/proc')/str(launch['pid'])/'cmdline'
        if not p.exists() or b'mydata_bench.auto_research_addbase.download_external_head_training' not in p.read_bytes():
            raise RuntimeError('Training media process disappeared without completion; preserve and inspect')
        time.sleep(20)
    env = dict(os.environ,CUDA_VISIBLE_DEVICES='0',OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    events = OUT/'preparation_queue_events_v1.jsonl'
    for name in modules:
        if digest(ROOT/f'mydata_bench/auto_research_addbase/{name}.py') != hashes[name]:
            raise ValueError('Frozen training-preparation source changed')
        if name!='audit_external_head_training':
            while True:
                free = int(subprocess.check_output(['nvidia-smi','--id=0','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
                if free>=30000:
                    break
                append(events,dict(time=timestamp(),event='memory_wait',free_mib=free))
                time.sleep(20)
        python = '/home/dais/miniconda3/envs/rewardbench-sam3/bin/python' if name=='ground_external_head_training' else sys.executable
        command = [python,'-u','-m','mydata_bench.auto_research_addbase.'+name]
        with (OUT/(name+'_stdout_v1.log')).open('x') as handle:
            p = subprocess.Popen(command,cwd=ROOT,env=env,stdout=handle,stderr=subprocess.STDOUT)
            append(events,dict(time=timestamp(),event='launch',module=name,pid=p.pid,command=command))
            if name=='parse_external_head_training':
                create_json(OUT/'parser_launch_v1.json',dict(time=timestamp(),pid=p.pid,command=command))
            code = p.wait()
        append(events,dict(time=timestamp(),event='exit',module=name,pid=p.pid,returncode=code))
        if code:
            create_json(OUT/'preparation_queue_failure_v1.json',dict(time=timestamp(),module=name,returncode=code))
            raise RuntimeError('Training preparation stage failed; inspect without blind retry')
    create_json(OUT/'preparation_queue_completion_v1.json',dict(time=timestamp(),failures=[],head_training_not_started=True,test_performance_not_opened=True))


if __name__ == '__main__':
    main()
