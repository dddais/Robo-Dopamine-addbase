# Robust research checkpoint — 2026-09-10 02:12 Asia/Shanghai

Goal active and unachieved. Previous turn was progress (F6 validation implemented/frozen). This turn also made progress: original-full846 conditional workflow added/frozen and new F2/F3 negative cases analyzed. No goal completion or blocking claim.

Read preceding ROBUST_CHECKPOINT_20260910T0157.md and ROBUST_CHECKPOINT_20260910T0134.md. Their rules remain: target Robo-Dopamine-addbase only; explicit cwd/login:false every exec; no git/other local code repos/subagents/permission questions; preserve all old data/results and frozen sources. Python robo-dopamine env; SAM3 rewardbench-sam3 env. Chinese updates. R=`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1`.

## New frozen original846 follow-up

Four additional source files are NOW FROZEN by live waiter: reward_gradient_full_old.py, freeze_reward_gradient_full_old.py, analyze_reward_gradient_full_old.py, reward_gradient_full_old_queue.py. Snapshots `R/f6_full_old_source_snapshots_v1`. SHA captured `R/f6_full_old_queue_plan_v1.json` and launch file. Do not edit them or the27 earlier evaluation-policy sources or earlier fitting/preparation sources. Fixes need justified versions and preservation.

Conditional full846 waiter **PID2466415**, `R/f6_full_old_queue_launch_v1.json`, plan, stdout. Verified live. Waits evaluation queue2464770's `f6_evaluation_and_analysis_completion_v1.json`. If same>=3 input cases per each3 models do not jointly pass old234 and independent-training-validation, saves `f6_full_old_queue_eligibility_v1.json` eligiblefalse and exits normally. If pass, freezes ALL jointly eligible cases before full846 outputs, then engineering/full846 GPU0/3, analyzes. Never changes learned ranking/b1/k32,48,64; never opens reserved external test.

Full846 runner verifies old234 config/condition/input/model/learned&original ranking compatibility and cached-prediction SHA. Reuses exact cached rows, including original errors (not dropped/retried); computes remaining observations and any missing fixed-best-original condition. Actual engineering reruns baseline/original48/F6k48/zero48 on two frozen OLD engineering examples and requires all4 cached values exact. Then full846 must preserve every IDxcondition and exact zero. Data role is wholly previously exposed DESCRIPTIVE, not independent.

Full analyzer applies original MAE/suc/fail/total+10pp gate across3k/two baselines, stronger original MAE/accuracy comparison, both Meter thresholds. Reports native five-bin and continuous ordinal MAE, full task/split distributions and task macro, same-video success-failure negative/0/1/2/3/4 gap histogram, top8 and top8/32/64 head-index overlaps (not functional equality), control effects and invalid counts. No p-values for reused old846. Outputs when eligible: `R/reward_gradient_full_old_v1/frozen_plan_v1.json`, `{case}/{engineering,full846}/...`, `analysis_v1.json`, `REPORT_v1.md`. Not created/run yet: F6 prerequisite outcomes absent.

Two meaningful CPU tests passed in test_reward_gradient_full_old.py: same>=3 joint inputs in each model required; cached failures preserved and changed conditions rejected. Run used `--basetemp R/full_old_testing_v1`; **do not reuse that basetemp for future pytest, which would delete existing fixture artifacts**. Four module AST checks passed;27 earlier frozen dependency hashes unchanged. No actual full846 engineering yet.

## Current evidence

F1 final15 allfail (do not reanalyze unchanged). F2 newly13/15 allfail: includes allQwen/RR and Meter text_video/video_text/text_image. New Meter officialtext_image primary MAE−.308073, acc0pp,suc−22.3684pp,fail+10.7595pp. F3 newly7/15 allfail: new Qwen video_text MAE+.414530,acc−14.1026pp,suc−27.6316pp,fail−7.5949pp. F4/F5 stillRR5 eachallfail. Latest files:
- f1: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f1_frame_transport_analysis_2026-09-09T172443.406728_0000.json`
- f2: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f2_frame_transport_analysis_2026-09-09T180747.598110_0000.json`
- f3: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f3_frame_transport_analysis_2026-09-09T180742.039489_0000.json`
- f4: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f4_frame_transport_analysis_2026-09-09T165149.021698_0000.json`
- f5: `results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f5_frame_transport_analysis_2026-09-09T171932.281859_0000.json`

Training parser2425817 still live, observed801/1072 records,allstatusok. Prep2337640/fit2357092/evaluation2464770 waiters alive. No actualF6 fitting yet; training grounder follows parser automatically. Final train eligibility1942fit/446groups and493validation/108groups, same frozen cohorts.

External test grounder terminal normal: all2831,1788grounded1043fallback,0runtime errors, full structural audit passed (prior checkpoint). No need restart/re-audit unchanged outputs. No reward-model test predictions/performance opened; original test labels/1172episode grouping preserved.

## Next actions

1. Monitor training parser completion, then real grounder; verify first actual TRAIN tracks cover all8 observations. Do not restart live processes based on age/observation timeout.
2. Inspect actualF6 gradients/rankings when training prep ends. Synthetic oldgrade3 engineering is not real supervised performance.
3. Validation and conditional old846 are durably queued. Do not launch duplicate jobs or edit frozen dependencies. Check actual engineering/parity and preserve runtime failures; version repairs when necessary.
4. Analyze newly completed F2/F3/F4/F5 only. All have0 wholecase passes so far; keep original family configs unchanged.
5. Once candidate passes old234+493validation+old846, final reserved2831 once-only model inference/analysis/freezing STILL NEED IMPLEMENTING. Must retain allgrades/full denominator/coverage/two Meter thresholds/strong originals/group uncertainty. Do not consume test as a diagnostic to tune new families. No candidate currently qualifies.

Live process snapshot (UTC2026-09-09T18:12:15.439506+00:00):
```json
{
  "2235607": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.frame_transport_vcd_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
  "2304131": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.specificity_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
  "2304132": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.specificity_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
  "2308875": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.joint_task_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
  "2308876": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.joint_task_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
  "2312042": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.task_interaction_queue --gpu 1 --cases qwen_text_video,qwen_video_text,qwen_text_image,qwen_image_text,qwen_interleaved ",
  "2312043": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.task_interaction_queue --gpu 2 --cases meter_text_video,meter_video_text,meter_text_image,meter_image_text,meter_interleaved ",
  "2337640": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.external_head_training_queue ",
  "2425817": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.parse_external_head_training ",
  "2357092": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.reward_gradient_training_queue ",
  "2464770": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.reward_gradient_evaluation_queue ",
  "2466415": "/home/dais/miniconda3/envs/robo-dopamine/bin/python -u -m mydata_bench.auto_research_addbase.reward_gradient_full_old_queue "
}
```

No pending exec sessions at writing. Goal remains active and unachieved. No need permission; useful work is waiting on verified live jobs and preparing required once-only final evaluation without opening performance.
