"""Freeze posterior-KL-controlled regional evidence on existing development60."""
import yaml
from .common import *


def main():
    root=RESEARCH/'score_kl_development_v1';plan={'time':timestamp(),
        'hypothesis':'A fixed raw-logit gain is not commensurate across native heads and input layouts. Normalize the posterior movement using the convex exponential-tilt KL geometry rather than a class label or endpoint rule.',
        'formula':'p_lambda=softmax(z0+lambda*D); choose largest lambda in[0,64] with KL(p0||p_lambda)<=delta. Constant D or delta0 returns baseline exactly.',
        'derivation':'After centering D by E_p0[D], KL=logsumexp(z0+lambda*D_centered)-logsumexp(z0). Its derivative is E_p_lambda[D_centered], nonnegative for lambda>=0. The local curvature is Var_p0[D]. Bisection uses only native score vectors.',
        'deltas_nats':[.25,.5,1.,2.,4.],'max_contrast_weight':64.,'bisection_steps':64,
        'models':['meter','rr','qwen'],'protocols':['text_image','interleaved','image_text','video_text','text_video'],
        'ks':[32,64],'scopes':['all_frames','last_frame'],'directions':['region','temporal'],
        'controls':'native/readout baseline,zero-preserve,KL-zero-budget,original bias,wrong/low matched KL; native-temperature direction with exactly the same KL budget',
        'native_heads':'all5 reward or all10 progress bins retained; no bin clipping,endpoint remapping,or true-label access',
        'known_limit':'Forcing posterior movement can amplify uninformative direction; bounded maximum gain and wrong/low controls test this limitation. No effectiveness claim before measurement.',
        'phase':'same frozen60/24-video-group development screen; no new neural forward or training','confirmation_metrics_used':False}
    create_json(root/'prospective_plan.json',plan)
    for model in plan['models']:
        for protocol in plan['protocols']:
            source=RESEARCH/f'score_temporal_development_v1/{model}_{protocol}';out=root/source.name
            if not (source/'completion_events.jsonl').exists():raise ValueError('Complete source experiments required')
            cfg=json.loads((source/'config.json').read_text());src=source/'score_branches.jsonl';blob=src.read_bytes();digest=hashlib.sha256(blob).hexdigest()
            keep={'baseline','native_generation_baseline','zero_preserve_k32','static_baseline','static_zero_preserve_k32','original_all_k32','original_all_k64'}
            conditions=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in cfg['branch_conditions'] if c['name'] in keep]
            for control in ['target','wrong','low_rank']:
                for scope in plan['scopes']:
                    for k in (plan['ks'] if control=='target' else [32]):
                        prefix=f'{control}_{scope}_b3_k{k}'
                        for mechanism in plan['directions']:
                            branches=['baseline',prefix+'_plus',prefix+'_minus']
                            if mechanism=='temporal':branches+=['static_'+prefix+'_plus','static_'+prefix+'_minus']
                            for delta in plan['deltas_nats']:
                                conditions.append({'name':f'contrast_{control}_kl_{mechanism}_{scope}_b3_k{k}_delta{delta:g}',
                                    'k':k,'scope':scope,'region':control,'contrast_weight':1.,'target_kl':delta,'max_contrast_weight':64.,
                                    'combination_type':'region_contrast' if mechanism=='region' else 'temporal_region_contrast','source_branches':branches})
            for delta in plan['deltas_nats']:conditions.append({'name':f'readout_kl_temperature_delta{delta:g}','k':0,
                'contrast_weight':1.,'target_kl':delta,'max_contrast_weight':64.,'combination_type':'native_logit_temperature','source_branches':['baseline']})
            conditions.append({'name':'kl_zero_budget','k':32,'contrast_weight':1.,'target_kl':0.,'max_contrast_weight':64.,
                'combination_type':'region_contrast','source_branches':['baseline','target_all_frames_b3_k32_plus','target_all_frames_b3_k32_minus']})
            cfg.update(output_dir=str(out),stage='prospectively_frozen_posterior_kl_development',conditions=conditions,
                score_branch_source=str(src),score_branch_source_sha256=digest,kl_plan_sha256=fingerprint(plan),readout_only=True)
            path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_kl_development_v1_{model}_{protocol}.yaml'
            with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            create_json(out/'config.json',cfg);create_json(out/'ranking.json',json.loads((source/'ranking.json').read_text()))
            create_json(out/'prospective_plan.json',{'time':timestamp(),'config':cfg,'config_sha256':fingerprint(cfg),
                'global_plan_sha256':fingerprint(plan),'source_sha256':digest,'confirmation_metrics_used':False,'readout_only':True})
    print(root,'15 cases; no new neural inference; frozen KL and gain cap')


if __name__=='__main__':main()
