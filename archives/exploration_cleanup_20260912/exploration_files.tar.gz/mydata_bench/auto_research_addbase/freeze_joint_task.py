"""Freeze F4 joint instruction/region steering at the original bias strength."""
import json
import yaml
from .common import ROOT, create_json, timestamp
from .robust_prepare import DEST, digest


def main():
    plan = json.loads((DEST / 'frame_transport_frozen_plan_v1.json').read_text())
    cases = []
    for item in plan['configurations']:
        cfg = yaml.safe_load(open(item['path']))
        name = item['model'] + '_' + item['protocol']
        conditions = [dict(name='baseline', k=0, cached_reference=True),
                      dict(name='native_generation_baseline', k=0, kind='native_generation', cached_reference=True)]
        for k in [32, 48, 64]:
            conditions.extend([
                dict(name=f'original_all_k{k}', k=k, kind='bias', bias=6., scope='all_frames', ranking='original', cached_reference=True),
                dict(name=f'joint_task_k{k}', k=k, kind='joint_task_region', bias=6., scope='all_frames')])
        conditions.extend([
            dict(name='joint_task_zero_k48', k=48, kind='joint_task_region', bias=0., scope='all_frames'),
            dict(name='joint_task_wrong_k48', k=48, kind='joint_task_region', bias=6., scope='all_frames', region='wrong'),
            dict(name='joint_task_low_k48', k=48, kind='joint_task_region', bias=6., scope='all_frames', head_group='low'),
            dict(name='task_only_k48', k=48, kind='task_only', bias=6., scope='all_frames')])
        cfg.update(clean_source_dir=cfg['output_dir'], output_dir=str(DEST / f'joint_task_v1/{name}'),
                   original_ranking_file=cfg['ranking_file'], original_ranking_sha256=cfg['ranking_sha256'],
                   conditions=conditions, stage='F4_shared_joint_instruction_visual_steering',
                   output_score_adjustment='none', primary_k=48, k_neighborhood=[32, 48, 64],
                   original_task_to_target_odds_preserved_locally=True,
                   entire_network_relative_odds_conservation_claim=False)
        for filename in ['joint_task_attention.py', 'joint_task_runtime.py', 'joint_task_runner.py', 'freeze_joint_task.py']:
            path = ROOT / 'mydata_bench/auto_research_addbase' / filename
            cfg['source_sha256'][str(path.relative_to(ROOT))] = digest(path)
        path = ROOT / f'mydata_bench/configs/v2_crossmodel/addbase_robust_joint_task_v1_{name}.yaml'
        with path.open('x') as handle:
            yaml.safe_dump(cfg, handle, sort_keys=False)
        cases.append(dict(model=item['model'], protocol=item['protocol'], path=str(path), sha256=digest(path)))
    create_json(DEST / 'joint_task_frozen_plan_v1.json', dict(time=timestamp(), configurations=cases,
        rule='task and target visual keys +6; other visual keys -6; other text unchanged; actual causal mask retained',
        shared_parameters=dict(bias=6., k_neighborhood=[32, 48, 64], primary_k=48),
        ranking='original raw_mass order; no F3 reranking mixed in', output_score_transform='none',
        task_span_rule='explicit prompt task field, exact tokenizer offsets, exact actual input token prefix verification',
        F4_performance_not_seen=True, external_test_performance_not_opened=True,
        development_trigger='strong visual focus can suppress task text; F1/F2 incomplete gains and F3 first RR text_video loss of success accuracy',
        controls=['unmodified native/readout', 'visual-only original steering at same k', 'task-only k48', 'whole zero', 'wrong ROI', 'low heads']))
    print('F4 frozen', len(cases), 'cases; no output-score transformation')


if __name__ == '__main__':
    main()
