"""Describe all 846 examples using the unchanged nine confirmation recipes."""
import collections
import datetime
from .common import *
from .metrics import summarize
from .analyze_development import contrast
from .paired_analysis import paired
from mydata_bench.meter_eval.readout import canonicalize


def main():
    folder = RESEARCH / 'frozen_cohort_completion_v1'
    manifest = json.loads((folder / 'frozen_manifest_v1.json').read_text())
    confirmation = json.loads(pathlib.Path(manifest['confirmation_manifest_path']).read_text())
    if fingerprint(confirmation) != manifest['confirmation_manifest_sha256']:
        raise ValueError('Confirmation manifest changed')
    for name, expected in confirmation['input_file_sha256'].items():
        if hashlib.sha256((BASE / 'inputs' / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Frozen input file changed: {name}')
    full_ids = json.loads((folder / 'full_cohort_ids.json').read_text())
    if fingerprint(full_ids) != manifest['full_cohort_ids_sha256']:
        raise ValueError('Full cohort changed')
    parts = {'development': json.loads((RESEARCH / 'development_v1/development_ids.json').read_text()),
             'confirmation': json.loads(pathlib.Path(confirmation['analysis_protocol']['confirmation_ids_file']).read_text()),
             'ranking_overlap_remainder': json.loads((folder / 'remaining_ids.json').read_text())}
    if fingerprint(parts['development']) != confirmation['analysis_protocol']['development_ids_sha256']:
        raise ValueError('Frozen development IDs changed')
    if fingerprint(parts['confirmation']) != confirmation['analysis_protocol']['ids_sha256']:
        raise ValueError('Frozen confirmation IDs changed')
    if fingerprint(parts['ranking_overlap_remainder']) != manifest['remaining_ids_sha256']:
        raise ValueError('Frozen remainder IDs changed')
    if sum(map(len, parts.values())) != len(full_ids) or set().union(*map(set, parts.values())) != set(full_ids):
        raise ValueError('Invalid disjoint partition')
    labels = {r['example_id']: r for r in read_rows(BASE / 'inputs/labels.jsonl')}
    stamp = datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
    out = folder / f'full_cohort_analysis_{stamp}'
    reports = {}
    accepted = collections.defaultdict(list)
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']
        sources = {'development': pathlib.Path(case['folder']),
                   'confirmation': pathlib.Path(case['confirmation_output_dir']),
                   'ranking_overlap_remainder': pathlib.Path(case['output_dir'])}
        names = case['aggregate_conditions']
        indexed = {n: {} for n in names}
        audit = {}
        conflicts = []
        for part, source in sources.items():
            if not (source / 'combination_events.jsonl').exists():
                raise ValueError(f'Incomplete source: {source}')
            blob = (source / 'sweep.jsonl').read_bytes()
            digest = hashlib.sha256(blob).hexdigest()
            if part == 'development' and digest != case['sweep_sha256']:
                raise ValueError('Selected development source changed since confirmation freezing')
            ids = set(parts[part])
            seen = {}
            for line in blob.decode().splitlines():
                row = canonicalize(json.loads(line))
                condition, eid = row['condition'], row['example_id']
                if condition not in indexed:
                    continue
                if eid not in ids:
                    raise ValueError('Unexpected source example')
                key = (condition, eid)
                previous = seen.get(key)
                if previous and previous.get('status') == 'ok' and any(previous.get(k) != row.get(k) for k in ['status', 'progress', 'score_logits', 'native_prediction']):
                    conflicts.append({'partition': part, 'condition': condition, 'example_id': eid})
                seen[key] = row
            missing = [(i, n) for i in ids for n in names if (n, i) not in seen]
            if missing:
                raise ValueError(f'{len(missing)} source attempts missing in {name}/{part}')
            audit[part] = {'folder': str(source), 'sweep_sha256': digest, 'n_expected': len(ids),
                           'complete_attempt_coverage': True}
            for (condition, eid), row in seen.items():
                if eid in indexed[condition]:
                    raise ValueError('Partition overlap')
                indexed[condition][eid] = row
        summaries = {n: summarize(rows.values(), labels, full_ids) for n, rows in indexed.items()}
        partitions = {part: {n: summarize(rows.values(), labels, ids) for n, rows in indexed.items()}
                      for part, ids in parts.items()}
        continuous = case['model'] in {'meter', 'sole'}
        comparisons = {}
        zero_audits = {}
        for reference, zero in [('baseline', 'zero_preserve_k32'), ('static_baseline', 'static_zero_preserve_k32')]:
            if zero not in indexed:
                continue
            bad = [i for i in full_ids if indexed[reference][i].get('status') != 'ok'
                   or indexed[zero][i].get('status') != 'ok'
                   or any(indexed[reference][i].get(k) != indexed[zero][i].get(k) for k in ['score_logits', 'progress'])]
            zero_audits[zero] = {'n_expected': len(full_ids), 'n_exact': len(full_ids) - len(bad), 'mismatch_or_invalid_ids': bad}
        for n, k in zip(case['conditions'], case['selected_ks']):
            comparison = {}
            for base in dict.fromkeys(['baseline', 'native_generation_baseline', f'original_all_k{k}', case['best_development_original']]):
                comparison[base] = {'contrast': contrast(summaries[n], summaries[base], continuous),
                                    'paired': paired(indexed[n], indexed[base], labels, full_ids, continuous)}
            comparison['point_gate_vs_both_baselines'] = all(comparison[b]['contrast'].get('point_estimate_10pp_gate', False)
                                                            for b in ['baseline', 'native_generation_baseline'])
            original = comparison[f'original_all_k{k}']['contrast']
            comparison['improves_same_k_original'] = original.get('complete', False) and original['mae_delta'] < 0 and original['accuracy_delta'] > 0
            comparisons[n] = comparison
        primary = case['primary']
        bins = not continuous or all(summaries[primary]['overall']['mae'] is not None
                                     and summaries[b]['overall']['mae'] is not None
                                     and summaries[primary]['overall']['mae'] < summaries[b]['overall']['mae']
                                     for b in ['baseline', 'native_generation_baseline'])
        point_pass = not conflicts and all(not z['mismatch_or_invalid_ids'] for z in zero_audits.values()) and bins and all(
            c['point_gate_vs_both_baselines'] and c['improves_same_k_original'] for c in comparisons.values())
        best = comparisons[primary][case['best_development_original']]['contrast']
        if point_pass:
            accepted[case['model']].append(case['protocol'])
        reports[name] = {'model': case['model'], 'protocol': case['protocol'], 'primary': primary,
                         'selected_ks': case['selected_ks'], 'source_audit': audit, 'duplicate_success_conflicts': conflicts,
                         'summaries': summaries, 'partitions': partitions, 'comparisons': comparisons,
                         'zero_audits': zero_audits, 'primary_five_bin_mae_improves': bins,
                         'all_frozen_neighbors_descriptive_point_acceptance': point_pass,
                         'primary_beats_development_selected_original': best.get('complete', False) and best['mae_delta'] < 0 and best['accuracy_delta'] > 0}
        create_json(out / f'{name}.json', reports[name])
        print(name, 'full846 descriptive point acceptance', point_pass, flush=True)
    create_json(out / 'summary.json', {'time': timestamp(), 'manifest_sha256': fingerprint(manifest),
                'boundary': manifest['boundary'], 'partition_sizes': manifest['partition_sizes'],
                'accepted_protocols_by_model': dict(accepted),
                'at_least_three_models_with_three_descriptive_point_accepted_protocols': sum(len(v) >= 3 for v in accepted.values()) >= 3,
                'case_files': {name: str(out / f'{name}.json') for name in reports},
                'statistics_note': 'Intervals are descriptive because 846 includes development and ranking-overlap data. They do not replace frozen498 confirmation or its family-wise correction. No post-confirmation recipe selection.'})
    print(out / 'summary.json', flush=True)


if __name__ == '__main__':
    main()
