"""Create prospective configs before obtaining any method outcomes."""
from .common import *
import collections,hashlib,json,yaml

def main():
    splits=json.loads((BASE/'inputs/splits.json').read_text());allowed=set(splits['development'])
    samples=[s for s in read_rows(BASE/'inputs/cohort.jsonl') if s['example_id'] in allowed]
    groups=collections.defaultdict(list)
    for s in samples:groups[s['video_sha256']].append(s['example_id'])
    # Initial screen uses 24 content-hashed groups, preserving every instruction
    # associated with the selected videos and never choosing by model outcomes.
    groups_ordered=sorted(groups,key=lambda g:hashlib.sha256(('screen-v1:'+g).encode()).hexdigest())
    screen_ids=[i for g in groups_ordered[:24] for i in groups[g]]
    dest=RESEARCH/'development_v1';dest.mkdir(parents=True,exist_ok=True)
    create_json(dest/'screen_ids.json',screen_ids);create_json(dest/'development_ids.json',splits['development']);create_json(dest/'confirmation_ids.json',splits['confirmation'])
    conditions=[{'name':'baseline','k':0}]
    for k in [8,32,64]:
        conditions.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames','query_scope':'all'})
        for scope in ['all_frames','last_frame']:
            for b in [.5,1.5,3.]:
                conditions.append({'name':f'preserve_{scope}_b{b:g}_k{k}','k':k,'kind':'visual_preserve','bias':b,'scope':scope,'query_scope':'all'})
        for b in [1.5,3.]:
            conditions.append({'name':f'target_only_all_b{b:g}_k{k}','k':k,'kind':'target_only','bias':b,'scope':'all_frames','query_scope':'all'})
    models={'qwen':'Qwen3-VL-8B-Instruct','rr':'RoboReward-8B','meter':'Robometer-4B'}
    cases=[]
    for model,checkpoint in models.items():
        for protocol in ['text_video','video_text','text_image','image_text','interleaved']:
            cfg={'model':model,'model_path':f'/home/dais/workspace/model/{checkpoint}','protocol':protocol,'scope':'all_frames','skip_early_layers':8,'ranking_metric':'raw_mass','output_dir':str(dest/f'{model}_{protocol}'),'example_ids_file':str(dest/'screen_ids.json'),'stage':'exploratory_screen','screen_video_groups':24,'max_new_tokens':128,'conditions':conditions,'sample_frames':8,'video_pixel_budget':8*50176,'ranking_ids_excluded_from_development':True,'acceptance':'No confirmation claim from this screen; expand best non-dominated candidates on all development IDs before frozen confirmation.'}
            if model=='meter':cfg['processor_path']='/home/dais/workspace/model/Qwen3-VL-4B-Instruct'
            path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_development_v1_{model}_{protocol}.yaml'
            with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            cases.append({'model':model,'protocol':protocol,'config':str(path),'config_sha256':fingerprint(cfg)})
    plan={'created_at':timestamp(),'screen_samples':len(screen_ids),'screen_video_groups':24,'development_samples':len(splits['development']),'confirmation_samples':len(splits['confirmation']),'conditions':conditions,'cases':cases,'selection_rule':'All outcomes retained. Rank complete candidates by Pareto improvements in MAE and both split accuracies; do not label any exploratory maximum as confirmation. Original-all bias-6 comparators included.','prohibited':'No label/ID/filename-based model output, no forced 1/5 endpoints, no deleting failed experiments.','theory_document':str(ROOT/'mydata_bench/auto_research_addbase/LITERATURE_AND_HYPOTHESES_20260908.md')}
    create_json(dest/'prospective_plan.json',plan);print('Frozen',fingerprint(plan),len(screen_ids),'samples',len(conditions),'conditions')
if __name__=='__main__':main()
