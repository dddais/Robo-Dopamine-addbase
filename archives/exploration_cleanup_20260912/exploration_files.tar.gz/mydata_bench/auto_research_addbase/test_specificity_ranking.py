import unittest
from .specificity_ranking import rank_specificity


class SpecificityTests(unittest.TestCase):
    def rows(self):
        # The head with greater target mass has still greater visual mass.
        # After controlling for area, the first head is more target-specific.
        return [dict(status='ok', video_sha256=str(i), raw_mass=[[.3, .4]],
            image_mass=[[.3, .8]], target_count=1, visual_count=2,
            excess_mass=[[.15, 0.]]) for i in range(3)]

    def test_area_control_changes_head_order(self):
        result = rank_specificity(self.rows(), 0)
        self.assertEqual(result['ranking'][0]['head'], 0)
        self.assertAlmostEqual(result['ranking'][0]['score'], .15)

    def test_duplicate_video_does_not_increase_effective_sample_count(self):
        rows = self.rows()
        reference = rank_specificity(rows, 0)
        repeated = rank_specificity(rows + [rows[0]], 0)
        self.assertEqual(repeated['video_groups'], 3)
        self.assertEqual(repeated['ranking'], reference['ranking'])
        self.assertEqual(rank_specificity(list(reversed(rows)), 0)['ranking'], reference['ranking'])


if __name__ == '__main__':
    unittest.main()
