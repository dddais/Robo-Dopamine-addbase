"""Execute an explicitly recorded fixed job after resource-release markers."""
import argparse
import subprocess
import time
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True)
    parser.add_argument('--job', required=True)
    args = parser.parse_args()
    path = pathlib.Path(args.plan).resolve()
    plan = json.loads(path.read_text())
    job = plan['jobs'][args.job]
    events = path.parent / (args.job + '_events.jsonl')
    if events.exists():
        raise RuntimeError('Job already has execution history; inspect before any recovery')
    append(events, {'time': timestamp(), 'event': 'waiting_markers', 'pid': os.getpid(),
                    'plan_sha256': fingerprint(plan), 'requires': job['requires']})
    while not all(pathlib.Path(p).exists() for p in job['requires']):
        time.sleep(20)
    for index, command in enumerate(job['commands']):
        with (path.parent / f'{args.job}_stage{index}.log').open('x') as log:
            child = subprocess.Popen(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
            append(events, {'time': timestamp(), 'event': 'launch', 'pid': child.pid,
                            'stage': index, 'command': command})
            code = child.wait()
        append(events, {'time': timestamp(), 'event': 'exit', 'pid': child.pid,
                        'stage': index, 'returncode': code})
        if code:
            raise RuntimeError('Scheduled stage failed; preserve outputs and inspect')
    append(events, {'time': timestamp(), 'event': 'job_completed'})


if __name__ == '__main__':
    main()
