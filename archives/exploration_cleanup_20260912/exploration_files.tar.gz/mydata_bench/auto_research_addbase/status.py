"""Read-only status: count completed records, never equate attempted to valid."""
import collections,json,pathlib
from .common import *
def main():
    for root in [BASE,RESEARCH/'development_v1']:
        print(str(root.relative_to(ROOT)))
        for folder in sorted(root.iterdir()):
            if not folder.is_dir() or not (folder/'config.json').exists():continue
            cfg=json.loads((folder/'config.json').read_text())
            if cfg.get('pilot'):continue
            stages=[]
            for stage in ['baseline','rank','attention','sweep']:
                path=folder/f'{stage}.jsonl'
                if not path.exists():continue
                latest={}
                for r in read_rows(path):latest[r['example_id'],r.get('condition','baseline')]=r
                counts=collections.Counter(r['status'] for r in latest.values())
                stages.append(f'{stage}:ok={counts["ok"]},error={sum(counts.values())-counts["ok"]},samples={len({k[0] for k in latest})}')
            print(folder.name,' | '.join(stages),flush=True)
if __name__=='__main__':main()
