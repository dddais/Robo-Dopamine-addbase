"""Execute already frozen full-development configs with conservative GPU admission."""
import argparse,os,subprocess,time,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);p.add_argument('--configs',required=True);p.add_argument('--after-pids',default='');p.add_argument('--name',required=True);a=p.parse_args()
    log=RESEARCH/f'{a.name}_queue_events.jsonl';env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(a.gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    for pid in [x for x in a.after_pids.split(',') if x]:
        path=pathlib.Path('/proc')/pid
        if not path.exists():continue
        if (path/'cwd').resolve()!=ROOT:raise ValueError('Can only depend on own research process')
        identity=(path/'cmdline').read_bytes()
        while path.exists():
            try:
                if (path/'cmdline').read_bytes()!=identity:break
            except OSError:break
            append(log,{'time':timestamp(),'event':'waiting_own_process','pid':int(pid)});time.sleep(20)
    for config_path in a.configs.split(','):
        path=pathlib.Path(config_path).resolve();cfg=yaml.safe_load(path.read_text());out=output_path(cfg['output_dir'])
        plan=json.loads((out/'prospective_plan.json').read_text());assert fingerprint(cfg)==plan['config_sha256']
        while True:
            free=int(subprocess.check_output(['nvidia-smi',f'--id={a.gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())
            if free>=(24000 if cfg['model']=='meter' else 34000):break
            append(log,{'time':timestamp(),'event':'waiting_free_memory','free_mib':free,'config':str(path)});time.sleep(20)
        for stage,command in [('branches',[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.score_branches','--config',str(path)]),('combine',[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.combine_scores','--folder',str(out)])]:
            append(log,{'time':timestamp(),'event':'launch','stage':stage,'command':command})
            with (out/f'{stage}.log').open('a') as f:
                proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT);code=proc.wait()
            append(log,{'time':timestamp(),'event':'exit','stage':stage,'returncode':code,'pid':proc.pid})
            if code:break
        print(cfg['model'],cfg['protocol'],'finished attempts',flush=True)
    append(log,{'time':timestamp(),'event':'queue_completed'})
if __name__=='__main__':main()
