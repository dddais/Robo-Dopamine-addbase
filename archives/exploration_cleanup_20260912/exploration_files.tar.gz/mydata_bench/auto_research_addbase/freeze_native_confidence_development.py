"""Freeze and materialize a new, label-free readout of existing neural branches."""
import argparse,hashlib,json,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--materialize-only',action='store_true');a=p.parse_args()
    root=RESEARCH/'score_native_confidence_development_v1';plan_path=root/'prospective_plan.json'
    if not plan_path.exists():
        if a.materialize_only:raise ValueError('Freeze the plan before materialization')
        create_json(plan_path,{'time':timestamp(),'hypothesis':'Uniform extrapolation can erase confident completed-task evidence. Smoothly damp only the attention-induced score direction with native completion confidence, retaining all original reward bins.',
            'formula':'z*=z0 + lambda*(1-q_native)^power*D, where D is the observed symmetric region difference or observed-minus-static difference.',
            'models':['meter','rr','qwen'],'protocols':['text_image','interleaved','image_text','video_text','text_video'],
            'ks':[32,64],'scopes':['all_frames','last_frame'],'weights':[4.,8.,16.],'powers':[1.,2.],
            'confidence_contract':{'meter':'separately trained native task-success probability at the same final prog token','rr_qwen':'normalized expected reward over all five native score logits'},
            'no_new_training':True,'no_labels_in_readout':True,'no_endpoint_replacement':True,
            'comparison':'same native/readout baseline, same original bias, ungated region/temporal contrast, matched wrong-region and low-head controls',
            'selection':'Same60/24-video-group development screen. A100% suc ceiling only permits nondecrease for extension; strict improvement of both classes remains mandatory on234 and498.',
            'confirmation_metrics_used':False})
    plan=json.loads(plan_path.read_text());ready=[];pending=[]
    for model in plan['models']:
        for protocol in plan['protocols']:
            source=RESEARCH/f'score_temporal_development_v1/{model}_{protocol}'
            if not (source/'completion_events.jsonl').exists():pending.append(source.name);continue
            dest=root/source.name;source_cfg=json.loads((source/'config.json').read_text())
            ids=json.loads(pathlib.Path(source_cfg['example_ids_file']).read_text());blob=(source/'score_branches.jsonl').read_bytes()
            indexed={(r['example_id'],r['condition']):r for r in map(json.loads,blob.decode().splitlines())}
            expected={(eid,c['name']) for eid in ids for c in source_cfg['branch_conditions']}
            if not expected<=indexed.keys():pending.append(source.name);continue
            cfg=dict(source_cfg);conditions=list(cfg['conditions'])
            for control in ['target','wrong','low_rank']:
                for scope in plan['scopes']:
                    for k in (plan['ks'] if control=='target' else [32]):
                        prefix=f'{control}_{scope}_b3_k{k}'
                        for mechanism in ['region','temporal']:
                            branches=['baseline',prefix+'_plus',prefix+'_minus']
                            if mechanism=='temporal':branches+=['static_'+prefix+'_plus','static_'+prefix+'_minus']
                            for weight in plan['weights']:
                                for power in plan['powers']:
                                    conditions.append({'name':f'contrast_{control}_confidence_{mechanism}_{scope}_b3_k{k}_lambda{weight:g}_power{power:g}',
                                        'k':k,'scope':scope,'region':control,'contrast_weight':weight,'native_confidence_power':power,
                                        'combination_type':'region_contrast' if mechanism=='region' else 'temporal_region_contrast','source_branches':branches})
            cfg.update(output_dir=str(dest),stage='prospectively_frozen_native_confidence_development',conditions=conditions,
                native_confidence_plan_sha256=fingerprint(plan),native_confidence_source_folder=str(source))
            config_path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_native_confidence_development_v1_{model}_{protocol}.yaml'
            if (dest/'config.json').exists():
                if json.loads((dest/'config.json').read_text())!=cfg:raise ValueError('Frozen confidence config mismatch')
                ready.append(str(dest));continue
            create_json(dest/'config.json',cfg);create_json(dest/'ranking.json',json.loads((source/'ranking.json').read_text()))
            with config_path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            digest=hashlib.sha256(blob).hexdigest()
            for row in indexed.values():append(dest/'score_branches.jsonl',{**row,'reused_from':str(source/'score_branches.jsonl'),'reused_source_sha256':digest,'reuse_time':timestamp()})
            create_json(dest/'prospective_plan.json',{'time':timestamp(),'config':cfg,'config_sha256':fingerprint(cfg),
                'global_plan_sha256':fingerprint(plan),'source_sha256':digest,'source_rows':len(indexed),'readout_only':True,'confirmation_metrics_used':False})
            ready.append(str(dest))
    append(root/'materialization_events.jsonl',{'time':timestamp(),'ready':ready,'pending':pending})
    print('ready',len(ready),'pending',pending)


if __name__=='__main__':main()
