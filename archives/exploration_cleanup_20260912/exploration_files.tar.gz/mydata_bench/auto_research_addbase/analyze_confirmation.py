"""Analyze every frozen confirmation case without selecting new parameters."""
import argparse, collections, datetime
from .common import *
from .metrics import summarize
from .analyze_development import contrast
from .paired_analysis import paired, holm
from mydata_bench.meter_eval.readout import canonicalize


def confirmation_contrast(candidate, comparator, continuous):
    effect = contrast(candidate, comparator, continuous)
    # The shared development helper has a historical constant metadata flag.
    # Phase belongs to this frozen analysis; acceptance is reported separately.
    effect.pop('confirmation', None)
    effect['evaluation_phase'] = 'frozen_confirmation'
    return effect


def analyze_case(case, manifest, labels, ids):
    folder = pathlib.Path(case['output_dir'])
    cfg = json.loads((folder / 'config.json').read_text())
    if fingerprint(cfg) != case['config_sha256']:
        raise ValueError('Confirmation configuration changed after freezing')
    if fingerprint(json.loads((folder / 'ranking.json').read_text())) != case['ranking_sha256']:
        raise ValueError('Frozen ranking changed')
    if not (folder / 'combination_events.jsonl').exists():
        raise ValueError('Wait for the confirmation default combination to finish')
    frozen_sources = manifest['provenance']['source_sha256']
    inference_files = [name for name in frozen_sources if name.startswith(('mydata_bench/meter_eval/', 'mydata_bench/top_eval/'))
                       or name.rsplit('/', 1)[-1] in {'score_branches.py', 'combine_scores.py', 'discrete_runtime.py',
                           'attention.py', 'native_confidence.py', 'kl_budget.py', 'common.py'}]
    launches = list(read_rows(folder / 'launches.jsonl'))
    if not launches:
        raise ValueError('Missing inference provenance')
    for launch in launches:
        if any(launch['source_sha256'].get(name) != frozen_sources[name] for name in inference_files):
            raise ValueError('Inference code changed after the confirmation freeze')
    blob = (folder / 'sweep.jsonl').read_bytes()
    indexed = collections.defaultdict(dict)
    conflicts = []
    for line in blob.decode().splitlines():
        row = canonicalize(json.loads(line))
        old = indexed[row['condition']].get(row['example_id'])
        if old and old.get('status') == 'ok' and any(old.get(key) != row.get(key) for key in ['status', 'progress', 'score_logits', 'native_prediction']):
            conflicts.append({'example_id': row['example_id'], 'condition': row['condition']})
        indexed[row['condition']][row['example_id']] = row
    expected_names = [c['name'] for c in cfg['conditions']]
    summaries = {name: summarize(indexed[name].values(), labels, ids) for name in expected_names}
    attempt_coverage = {name: {'n_attempted_expected': sum(i in indexed[name] for i in ids),
                              'n_expected': len(ids), 'n_extra_ids': len(set(indexed[name]) - set(ids))}
                        for name in expected_names}
    zeros = {}
    for reference, zero in [('baseline', 'zero_preserve_k32'), ('static_baseline', 'static_zero_preserve_k32'),
                            ('baseline', 'zero_primary'), ('static_baseline', 'static_zero_primary')]:
        if zero not in expected_names:
            continue
        bad = [i for i in ids if indexed[reference].get(i, {}).get('status') != 'ok'
               or indexed[zero].get(i, {}).get('status') != 'ok'
               or indexed[reference][i].get('score_logits') != indexed[zero][i].get('score_logits')
               or indexed[reference][i].get('progress') != indexed[zero][i].get('progress')]
        zeros[zero] = {'n_expected': len(ids), 'n_exact': len(ids) - len(bad), 'mismatch_or_invalid_ids': bad}
    continuous = cfg['model'] in {'meter', 'sole'}
    condition_configs = {c['name']: c for c in cfg['conditions']}
    comparisons = {}
    for name in case['conditions']:
        k = condition_configs[name]['k']
        entry = {}
        for comparator in dict.fromkeys(['baseline', 'native_generation_baseline', f'original_all_k{k}', case['best_development_original']]):
            entry[comparator] = {'summary_contrast': confirmation_contrast(summaries[name], summaries[comparator], continuous),
                                 'paired': paired(indexed[name], indexed[comparator], labels, ids, continuous)}
        point_gate = all(entry[b]['summary_contrast'].get('point_estimate_10pp_gate', False)
                         for b in ['baseline', 'native_generation_baseline'])
        original = entry[f'original_all_k{k}']['summary_contrast']
        original_gate = original.get('complete', False) and original.get('mae_delta', 1) < 0 and original.get('accuracy_delta', -1) > 0
        entry['point_gate_vs_both_baselines'] = point_gate
        entry['improves_original_same_k'] = original_gate
        entry['joint_direction_p_vs_both_baselines'] = max(entry[b]['paired'].get('joint_direction_intersection_union_p', 1.)
                                                         for b in ['baseline', 'native_generation_baseline'])
        comparisons[name] = entry
    primary = case['primary']
    primary_bins_improve = not continuous or all(summaries[primary]['overall']['mae'] is not None
                                                and summaries[b]['overall']['mae'] is not None
                                                and summaries[primary]['overall']['mae'] < summaries[b]['overall']['mae']
                                                for b in ['baseline', 'native_generation_baseline'])
    best_original_effect = comparisons[primary][case['best_development_original']]['summary_contrast']
    beats_best_original = best_original_effect.get('complete', False) and best_original_effect.get('mae_delta', 1) < 0 and best_original_effect.get('accuracy_delta', -1) > 0
    controls = {}
    for name in expected_names:
        if not name.startswith('control_'):
            continue
        feasible = [i for i in ids if indexed[name].get(i, {}).get('status') == 'ok' and indexed[primary].get(i, {}).get('status') == 'ok']
        controls[name] = {'full_n_expected': len(ids), 'n_feasible': len(feasible),
                          'excluded_ids': [i for i in ids if i not in feasible],
                          'primary_vs_control_on_explicit_feasible_subset': paired(indexed[primary], indexed[name], labels, feasible, continuous)}
    complete_attempts = all(x['n_attempted_expected'] == len(ids) and x['n_extra_ids'] == 0 for x in attempt_coverage.values())
    zero_ok = all(not audit['mismatch_or_invalid_ids'] for audit in zeros.values()) and bool(zeros)
    neighborhood_pass = all(entry['point_gate_vs_both_baselines'] and entry['improves_original_same_k'] for entry in comparisons.values())
    return {'model': cfg['model'], 'protocol': cfg['protocol'], 'primary': primary, 'selected_ks': case['selected_ks'],
            'source_sweep_sha256': hashlib.sha256(blob).hexdigest(), 'n_expected': len(ids),
            'summaries': summaries, 'attempt_coverage': attempt_coverage, 'complete_attempts': complete_attempts,
            'duplicate_success_conflicts': conflicts, 'zero_audits': zeros, 'comparisons': comparisons,
            'control_comparisons': controls, 'primary_five_bin_mae_improves': primary_bins_improve,
            'primary_beats_best_development_original_mae_and_accuracy': beats_best_original,
            'all_frozen_neighbors_pass_point_and_same_k_improvement': neighborhood_pass,
            'confirmation_case_point_acceptance': complete_attempts and zero_ok and not conflicts and neighborhood_pass and primary_bins_improve,
            'confirmation_case_strict_original_acceptance': complete_attempts and zero_ok and not conflicts and neighborhood_pass and primary_bins_improve and beats_best_original,
            'primary_joint_direction_p': comparisons[primary]['joint_direction_p_vs_both_baselines']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', default=str(RESEARCH / 'confirmation_v1/frozen_manifest_v1.json'))
    args = parser.parse_args()
    manifest = json.loads(pathlib.Path(args.manifest).read_text())
    protocol = manifest['analysis_protocol']
    if fingerprint(protocol) != manifest['protocol_sha256']:
        raise ValueError('Frozen statistical protocol changed')
    ids = json.loads(pathlib.Path(protocol['confirmation_ids_file']).read_text())
    if fingerprint(ids) != protocol['ids_sha256']:
        raise ValueError('Confirmation IDs changed')
    for name, expected in manifest['input_file_sha256'].items():
        if hashlib.sha256((BASE / 'inputs' / name).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Frozen input file changed: {name}')
    for name in ['metrics.py', 'paired_analysis.py', 'analyze_development.py']:
        relative = 'mydata_bench/auto_research_addbase/' + name
        if hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() != manifest['provenance']['source_sha256'][relative]:
            raise ValueError(f'Frozen metric/statistical implementation changed: {name}')
    labels = {r['example_id']: r for r in read_rows(BASE / 'inputs/labels.jsonl')}
    reports = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']
        reports[name] = analyze_case(case, manifest, labels, ids)
        print(name, 'all_neighbors_point_acceptance', reports[name]['confirmation_case_point_acceptance'], flush=True)
    adjusted = holm({name: report['primary_joint_direction_p'] for name, report in reports.items()})
    accepted = collections.defaultdict(list)
    strict_original_accepted = collections.defaultdict(list)
    for name, report in reports.items():
        report['holm_primary_joint_direction_p'] = adjusted[name]
        if report['confirmation_case_point_acceptance']:
            accepted[report['model']].append(report['protocol'])
        if report['confirmation_case_strict_original_acceptance']:
            strict_original_accepted[report['model']].append(report['protocol'])
    result = {'time': timestamp(), 'manifest_sha256': fingerprint(manifest), 'phase': 'Frozen confirmation, no reselection',
              'frozen_input_files_and_metric_implementations_verified': True,
              'analysis_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
              'cases': reports, 'accepted_protocols_by_model': dict(accepted),
              'at_least_three_models_with_three_point_accepted_protocols': sum(len(v) >= 3 for v in accepted.values()) >= 3,
              'accepted_protocols_also_beating_best_development_original': dict(strict_original_accepted),
              'at_least_three_models_with_three_strict_original_accepted_protocols': sum(len(v) >= 3 for v in strict_original_accepted.values()) >= 3,
              'statistics_note': '20000 whole-video-cluster bootstrap draws and one-sided cluster sign-flip tests, seed20260908. IUT takes the largest four-metric directional p and then the larger p against the two baselines; Holm covers all declared primary cases. These p values do not test a10pp lower confidence bound. Point acceptance and uncertainty are reported separately.',
              'boundary': protocol['boundary'], 'no_new_hyperparameters_selected': True}
    stamp = datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
    path = pathlib.Path(args.manifest).parent / f'confirmation_analysis_{stamp}.json'
    create_json(path, result)
    print(path, flush=True)


if __name__ == '__main__':
    main()
