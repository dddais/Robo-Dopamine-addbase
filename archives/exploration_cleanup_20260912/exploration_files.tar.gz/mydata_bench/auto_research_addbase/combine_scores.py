"""Label-free offline combination of prospectively specified score branches."""
import argparse,json,pathlib
import numpy as np
from .common import *
from .score_branches import score_readout
from mydata_bench.meter_eval.readout import canonicalize


def combine_logits(logits,condition,native_confidence=None,diagnostics=None):
    arrays=[np.asarray(z,dtype=np.float64) for z in logits]
    if len({z.shape for z in arrays})!=1:raise ValueError('Native bin dimensions must match')
    weight=condition['contrast_weight'];kind=condition.get('combination_type','region_contrast')
    if 'native_confidence_power' in condition:
        from .native_confidence import damping_factor
        if native_confidence is None:raise ValueError('Native confidence is required by this recipe')
        weight*=damping_factor(native_confidence,condition['native_confidence_power'])
    if kind=='native_logit_temperature' and len(arrays)==1:
        if weight<=0:raise ValueError('Positive native-logit temperature multiplier required')
        result=arrays[0]*weight
        base=arrays[0];direction=base
    elif kind=='region_contrast' and len(arrays)==3:
        base,plus,minus=arrays;direction=plus-minus;result=base+weight*direction
    elif kind=='temporal_region_contrast' and len(arrays)==5:
        base,plus,minus,static_plus,static_minus=arrays
        direction=(plus-minus)-(static_plus-static_minus);result=base+weight*direction
    elif kind=='visual_contrast' and len(arrays)==2:
        base,static=arrays;direction=base-static;result=base+weight*direction
    else:raise ValueError('Invalid contrast recipe')
    if 'target_kl' in condition:
        from .kl_budget import kl_budget_tilt
        if 'native_confidence_power' in condition:raise ValueError('KL and confidence damping must not be silently combined')
        tilted,audit=kl_budget_tilt(base,direction,condition['target_kl'],condition.get('max_contrast_weight',64.))
        result=np.asarray(tilted,dtype=np.float64)
        if diagnostics is not None:diagnostics.update(kl_budget_audit=audit)
    if not np.isfinite(result).all():raise ValueError('Nonfinite synthesized logits')
    return result.tolist()


def main():
    p=argparse.ArgumentParser();p.add_argument('--folder',required=True);p.add_argument('--supplement');a=p.parse_args();folder=pathlib.Path(a.folder)
    cfg=json.loads((folder/'config.json').read_text());source=pathlib.Path(cfg.get('score_branch_source',folder/'score_branches.jsonl'))
    if cfg.get('score_branch_source_sha256'):
        import hashlib
        if hashlib.sha256(source.read_bytes()).hexdigest()!=cfg['score_branch_source_sha256']:raise ValueError('Frozen read-only branch source changed')
    rows={(r['example_id'],r['condition']):canonicalize(r) for r in read_rows(source)}
    ids=json.loads(pathlib.Path(cfg['example_ids_file']).read_text());out=folder/'sweep.jsonl';known=set()
    if out.exists():known={(r['example_id'],r['condition']) for r in read_rows(out) if r['status']=='ok'}
    supplement=json.loads(pathlib.Path(a.supplement).read_text()) if a.supplement else None
    conditions=cfg['conditions']+(supplement.get('conditions',[]) if supplement else [])
    if len({c['name'] for c in conditions})!=len(conditions):raise ValueError('Supplement must add new condition names')
    for eid in ids:
        base=rows.get((eid,'baseline'))
        for condition in conditions:
            name=condition['name']
            if (eid,name) in known:continue
            row={'time':timestamp(),'example_id':eid,'condition':name,'condition_config':condition,'branch_source':str(source)}
            sources=condition.get('source_branches',[name]);required=[rows.get((eid,s)) for s in sources]
            if any(r is None for r in required):continue
            if any(r['status']!='ok' for r in required):
                append(out,{**row,'status':'error','error':'One or more required inference branches invalid','branch_errors':{s:r.get('error') for s,r in zip(sources,required) if r['status']!='ok'}});continue
            if len(required)==1 and condition.get('combination_type')!='native_logit_temperature':
                result=required[0];append(out,{**result,**row,'status':'ok'});continue
            extra={};confidence=None
            if 'native_confidence_power' in condition:
                from .native_confidence import native_completion_confidence,damping_factor
                native=rows.get((eid,'native_generation_baseline'))
                if base is None or native is None or base.get('status')!='ok' or native.get('status')!='ok':
                    append(out,{**row,'status':'error','error':'Native confidence source unavailable'});continue
                confidence=native_completion_confidence(cfg['model'],base,native)
                extra={'native_completion_confidence':confidence,'native_confidence_damping':damping_factor(confidence,condition['native_confidence_power']),
                    'native_confidence_source':'trained native success head' if cfg['model']=='meter' else 'normalized expectation over all five native reward bins',
                    'gate_role':'scales attention-derived logit difference only; no reward replacement or class-conditioned parameter selection'}
            logits=combine_logits([r['score_logits'] for r in required],condition,confidence,extra)
            append(out,{**row,'status':'ok','video_sha256':required[0]['video_sha256'],
                        'score_logits':logits,'source_score_logits':{s:r['score_logits'] for s,r in zip(sources,required)},
                        **score_readout(logits,cfg['model']),**extra,
                        'combination':condition.get('combination_type','region_contrast')+'; every native bin retained; no label access'})
    append(folder/'combination_events.jsonl',{'time':timestamp(),'expected_samples':len(ids),'expected_conditions':len(conditions),'prospective_config_sha256':fingerprint(cfg),'supplement':supplement})
if __name__=='__main__':main()
