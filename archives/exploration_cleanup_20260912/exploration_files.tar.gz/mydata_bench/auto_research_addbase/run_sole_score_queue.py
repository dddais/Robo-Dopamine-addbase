"""Verify numeric-trie and zero controls before the SOLE development screen."""
import argparse,subprocess,time,yaml
from .common import *


def main():
    p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);p.add_argument('--engineering-version',default='v3');p.add_argument('--version',default='v2');a=p.parse_args()
    root=RESEARCH/f'sole_score_development_{a.version}';out=RESEARCH/f'sole_score_engineering_{a.engineering_version}';out.mkdir(parents=True,exist_ok=True);log=root/'queue_events.jsonl'
    path=out/'engineering.yaml'
    if not path.exists():
        cfg=yaml.safe_load((ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_sole_score_development_{a.version}_image_text.yaml').read_text());source=pathlib.Path(cfg['output_dir'])
        create_json(out/'example_ids.json',json.loads(pathlib.Path(cfg['example_ids_file']).read_text())[:2]);create_json(out/'ranking.json',json.loads((source/'ranking.json').read_text()))
        cfg.update(output_dir=str(out),example_ids_file=str(out/'example_ids.json'),stage='label_free_sole_numeric_trie_engineering')
        with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
    while int(subprocess.check_output(['nvidia-smi',f'--id={a.gpu}','--query-gpu=memory.free','--format=csv,noheader,nounits'],text=True).strip())<34000:time.sleep(20)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(a.gpu),OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',TOKENIZERS_PARALLELISM='false')
    command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.score_branches','--config',str(path)]
    append(log,{'time':timestamp(),'event':'engineering_launch','command':command})
    with (out/'engineering.log').open('a') as f:proc=subprocess.Popen(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT);code=proc.wait()
    if code:raise RuntimeError('SOLE numeric engineering process failed')
    rows={(r['example_id'],r['condition']):r for r in read_rows(out/'score_branches.jsonl')};ids=json.loads((out/'example_ids.json').read_text());nonwrong=[r for r in rows.values() if r.get('condition_config',{}).get('region')!='wrong']
    checks={'all_target_branches_valid':all(r['status']=='ok' for r in nonwrong),
            'all201_native_scores':all(len(r.get('score_logits',[]))==201 and r.get('native_score_values')==list(range(-100,101)) for r in nonwrong if r['condition']!='native_generation_baseline'),
            'observed_zero_logits_exact':all(rows[(i,'baseline')].get('score_logits') is not None and rows[(i,'baseline')].get('score_logits')==rows[(i,'zero_preserve_k32')].get('score_logits') for i in ids),
            'static_zero_logits_exact':all(rows[(i,'static_baseline')].get('score_logits') is not None and rows[(i,'static_baseline')].get('score_logits')==rows[(i,'static_zero_preserve_k32')].get('score_logits') for i in ids),
            'native_baseline_canonical_format_supported':all(rows[(i,'baseline')].get('native_percentage_format_probability',0.)>=1e-3 for i in ids)}
    native_differences=[i for i in ids if rows[(i,'baseline')].get('progress')!=rows[(i,'native_generation_baseline')].get('progress')]
    passed=all(checks.values());append(log,{'time':timestamp(),'event':'engineering_audit','checks':checks,'passed':passed,'native_vs_integer_readout_differences':native_differences})
    if not (out/'audit.json').exists():create_json(out/'audit.json',{'time':timestamp(),'checks':checks,'passed':passed,'native_vs_integer_readout_differences':native_differences,'labels_used':False})
    if not passed:raise RuntimeError('SOLE numeric validation failed; development screen not started')
    paths=[str(ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_sole_score_development_{a.version}_{protocol}.yaml') for protocol in ['image_text','text_image','interleaved','video_text','text_video']]
    command=[sys.executable,'-u','-m','mydata_bench.auto_research_addbase.run_score_extensions','--gpu',str(a.gpu),'--name',f'sole_score_development_{a.version}','--configs',','.join(paths)]
    append(log,{'time':timestamp(),'event':'screen_launch','command':command});code=subprocess.call(command,cwd=ROOT,env=env)
    append(log,{'time':timestamp(),'event':'screen_exit','returncode':code})
    if code:raise RuntimeError('SOLE score screen failed')
    append(log,{'time':timestamp(),'event':'queue_completed'})


if __name__=='__main__':main()
