"""Plot all selected exploratory neighbors as observed points, never CIs."""
import argparse
import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', required=True)
    args = parser.parse_args()
    source = pathlib.Path(args.source).resolve()
    overview = json.loads(source.read_text())
    cases = {name: json.loads(pathlib.Path(path).read_text())
             for name, path in overview['case_files'].items()}
    fig, axes = plt.subplots(2, 4, figsize=(18, 11), sharey=True)
    columns = [('mae_delta', 'MAE difference (lower is better)', 1),
               ('accuracy_delta', 'Total accuracy difference (pp)', 100),
               ('suc_delta', 'Success accuracy difference (pp)', 100),
               ('fail_delta', 'Failure accuracy difference (pp)', 100)]
    colors = ['#1764a6', '#bb4a00', '#23764a']
    markers = ['o', 'D', '^']
    labels = []
    for case in cases.values():
        parameters = case.get('parameters', {'rho': case['rho']})
        parameter_text = ', '.join(f'{key}={value:g}' for key, value in parameters.items())
        labels.append(f'{case["model"]}/{case["protocol"]}\nk={",".join(map(str, case["selected_ks"]))}\n{parameter_text}')
    for row_index, (partition, partition_label) in enumerate([
            ('reused_validation', 'Reused validation: 498 examples / 179 video clusters'),
            ('full_cohort', 'Full descriptive cohort: 846 examples / 299 video clusters')]):
        for column_index, (metric, title, scale) in enumerate(columns):
            ax = axes[row_index, column_index]
            for y, case in enumerate(cases.values()):
                report = case['partitions'][partition]
                for k_index, comparison in enumerate(report['comparisons'].values()):
                    value = comparison['effects']['native_generation_baseline'][metric] * scale
                    ax.scatter(value, y + (k_index - 1) * .15, s=26,
                               marker=markers[k_index], color=colors[k_index],
                               label=['Lower k', 'Frozen primary k', 'Upper k'][k_index] if y == 0 else None)
            ax.axvline(0, color='#555555', linewidth=.8)
            if metric == 'accuracy_delta':
                ax.axvline(10, color='#777777', linestyle='--', linewidth=.9)
            ax.grid(axis='x', alpha=.2)
            ax.set_axisbelow(True)
            ax.spines[['top', 'right']].set_visible(False)
            ax.set_title(title, fontsize=10)
            ax.set_yticks(range(len(cases)), labels, fontsize=8)
        axes[row_index, 0].set_ylabel(partition_label, fontsize=10, labelpad=12)
    axes[0, 0].invert_yaxis()
    axes[0, 0].legend(fontsize=8, loc='upper right')
    fig.suptitle('Post-confirmation exploration: all nine fixed recipes and all three selected k values', fontsize=13)
    fig.text(.015, .015,
             'All points compare the candidate with native generation on the same cohort. Meter MAE is continuous ordinal; Qwen/RR MAE is native 1-5.\n'
             'Points are observed effects, not confidence intervals. Reused validation is not a new independent test; full cohort includes development and ranking overlap.\n'
             'The original v1 confirmation failure is preserved. Passing all requirements also needs matched-readout and original-method comparisons, detailed in the tables.', fontsize=9)
    fig.tight_layout(rect=(0, .07, 1, .96))
    out = source.parent / ('figures_' + datetime.datetime.now().strftime('%Y%m%dT%H%M%S'))
    out.mkdir()
    for extension in ['png', 'svg']:
        fig.savefig(out / ('all_selected_neighbor_effects.' + extension), dpi=180, bbox_inches='tight')
    plt.close(fig)
    create_json(out / 'provenance.json', {
        'time': timestamp(), 'source': str(source),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'case_source_sha256': {name: hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
                               for name, path in overview['case_files'].items()},
        'all_cases_and_selected_neighbors_included': True,
        'method_family': overview.get('method_family', 'original_method_anchor'),
        'plot_source_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
        'no_inferential_intervals_or_new_selection': True})
    print(out)


if __name__ == '__main__':
    main()
