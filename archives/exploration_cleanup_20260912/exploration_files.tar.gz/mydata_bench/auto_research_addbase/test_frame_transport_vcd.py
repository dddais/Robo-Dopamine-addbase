import unittest
import torch
from .frame_transport_vcd import contrast_logits, diffusion_corruption, sample_seed


class FixedVCDTests(unittest.TestCase):
    def test_zero_identical_and_all_bin_permutation(self):
        clean = [1., 3., 2., -1., .25]
        noisy = [-1., .5, 2., 4., 0.]
        self.assertEqual(contrast_logits(clean, noisy, 0), clean)
        self.assertEqual(contrast_logits(clean, clean), clean)
        permutation = [2, 4, 0, 3, 1]
        original = contrast_logits(clean, noisy)
        self.assertEqual(contrast_logits([clean[i] for i in permutation], [noisy[i] for i in permutation]), [original[i] for i in permutation])
        # Intermediate native bins can be the winning output.
        self.assertEqual(max(range(5), key=lambda i: original[i]), 1)

    def test_corruption_is_reproducible_and_identity_key_has_no_instruction(self):
        clean = torch.arange(72, dtype=torch.float32).reshape(3, 24) / 72
        seed = sample_seed('1234', 'text_video', 'pixel_values_videos')
        a = diffusion_corruption(clean, seed)
        b = diffusion_corruption(clean, seed)
        self.assertTrue(torch.equal(a, b))
        self.assertFalse(torch.equal(a, clean))
        self.assertEqual(a.shape, clean.shape)
        self.assertEqual(a.dtype, clean.dtype)
        self.assertTrue(torch.equal(clean, torch.arange(72).reshape(3, 24) / 72))


if __name__ == '__main__':
    unittest.main()
