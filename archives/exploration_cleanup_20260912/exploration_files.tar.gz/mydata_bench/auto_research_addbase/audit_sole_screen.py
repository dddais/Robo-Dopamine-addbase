"""Final coverage, duplicate and numeric-format audit for completed SOLE screens."""
import argparse
import collections
import datetime
import numpy as np
from .common import *


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--folder', required=True)
    args = parser.parse_args()
    folder = pathlib.Path(args.folder).resolve()
    if not (folder / 'completion_events.jsonl').exists() or not (folder / 'combination_events.jsonl').exists():
        raise ValueError('A final audit requires completed inference and combination')
    cfg = json.loads((folder / 'config.json').read_text())
    if cfg['model'] != 'sole':
        raise ValueError('SOLE numeric contract only')
    ids = set(json.loads(pathlib.Path(cfg['example_ids_file']).read_text()))
    conditions = list(cfg['conditions'])
    branches = list(cfg['branch_conditions'])
    ledger = folder / 'analysis_supplements.jsonl'
    if ledger.exists():
        for entry in read_rows(ledger):
            data = json.loads(pathlib.Path(entry['path']).read_text())
            if fingerprint(data) != entry['sha256']:
                raise ValueError('Supplement changed')
            conditions += data.get('conditions', [])
            branches += data.get('branch_conditions', [])
    scientific = ['status', 'error', 'progress', 'score_logits', 'native_prediction',
                  'native_percent_prediction', 'raw_output', 'native_percentage_format_probability']
    reports = {}
    indexed = {}
    for filename, specs in [('score_branches.jsonl', branches), ('sweep.jsonl', conditions)]:
        blob = (folder / filename).read_bytes()
        rows = [json.loads(line) for line in blob.decode().splitlines() if line.strip()]
        counts = collections.Counter()
        latest = {}
        conflicts = []
        for row in rows:
            key = (row['example_id'], row['condition'])
            if key in latest:
                fields = [f for f in scientific if latest[key].get(f) != row.get(f)]
                if fields:
                    conflicts.append({'example_id': key[0], 'condition': key[1], 'fields': fields})
            counts[key] += 1
            latest[key] = row
        expected = {(i, c['name']) for i in ids for c in specs}
        missing = sorted(expected - latest.keys())
        extra = sorted(latest.keys() - expected)
        report = {'sha256': hashlib.sha256(blob).hexdigest(), 'n_raw_rows': len(rows),
                  'n_unique_keys': len(latest), 'n_expected': len(expected),
                  'duplicate_keys': [{'example_id': i, 'condition': c, 'n_rows': n}
                                     for (i, c), n in counts.items() if n > 1],
                  'scientific_conflicts': conflicts, 'missing_keys': missing, 'extra_keys': extra,
                  'valid_expected': sum(latest.get(key, {}).get('status') == 'ok' for key in expected),
                  'errors_by_message': dict(collections.Counter(r.get('error', 'unknown') for key, r in latest.items()
                                                                if key in expected and r.get('status') != 'ok'))}
        reports[filename] = report
        indexed[filename] = latest
    rows = indexed['score_branches.jsonl']
    base = {i: rows.get((i, 'baseline'), {}) for i in ids}
    native = {i: rows.get((i, 'native_generation_baseline'), {}) for i in ids}
    masses = [r['native_percentage_format_probability'] for r in base.values() if r.get('status') == 'ok']
    quantiles = dict(zip(['min', 'p05', 'median', 'p95', 'max'], np.quantile(masses, [0, .05, .5, .95, 1]).tolist())) if masses else {}
    changed = [{'example_id': i, 'map_progress': base[i]['progress'], 'native_progress': native[i]['progress']}
               for i in sorted(ids) if base[i].get('status') == native[i].get('status') == 'ok'
               and base[i]['progress'] != native[i]['progress']]
    zeros = {}
    for reference, zero in [('baseline', 'zero_preserve_k32'), ('static_baseline', 'static_zero_preserve_k32')]:
        bad = [i for i in sorted(ids) if rows.get((i, reference), {}).get('status') != 'ok'
               or rows.get((i, zero), {}).get('status') != 'ok'
               or any(rows[(i, reference)].get(k) != rows[(i, zero)].get(k) for k in ['score_logits', 'progress'])]
        zeros[zero] = {'n_expected': len(ids), 'n_exact': len(ids) - len(bad), 'mismatch_or_invalid_ids': bad}
    result = {'time': timestamp(), 'scope': 'Completed final files, deduplicated by example and condition',
              'protocol': cfg['protocol'], 'files': reports, 'zero_audits': zeros,
              'numeric_contract': {'n_valid_baseline': len(masses), 'format_mass_quantiles': quantiles,
                                   'n_mass_below_point99': sum(v < .99 for v in masses),
                                   'native_vs_map_changes': changed,
                                   'boundary': '201 canonical signed integer formats, not all lexical formats or all vocabulary; no clipping, native greedy comparator retained'},
              'complete_attempts_and_no_scientific_conflicts': all(not r['missing_keys'] and not r['extra_keys'] and not r['scientific_conflicts'] for r in reports.values())}
    stamp = datetime.datetime.now().strftime('%Y%m%dT%H%M%S')
    path = folder / f'completed_score_audit_{stamp}.json'
    create_json(path, result)
    print(path)
    print({n: {k: v[k] for k in ['n_raw_rows', 'n_unique_keys', 'n_expected', 'valid_expected']} for n, v in reports.items()})
    print('complete/no-conflicts', result['complete_attempts_and_no_scientific_conflicts'], 'numeric', result['numeric_contract'])


if __name__ == '__main__':
    main()
