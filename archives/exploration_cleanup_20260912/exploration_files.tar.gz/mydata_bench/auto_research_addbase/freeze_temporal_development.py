"""Remove static appearance sensitivity from the regional score contrast."""
from .common import *
import yaml


def main():
    root=RESEARCH/'score_temporal_development_v1';root.mkdir(parents=True,exist_ok=True);plans=[]
    for model in ['meter','rr','qwen']:
        for protocol in ['text_image','interleaved','image_text','video_text','text_video']:
            source=RESEARCH/f'score_development_v1/{model}_{protocol}';out=root/f'{model}_{protocol}'
            cfg=json.loads((source/'config.json').read_text());old_branches=cfg['branch_conditions'];old_recipes=cfg['conditions']
            static=[{'name':'static_baseline','k':0,'media_condition':'static_first'},
                    {'name':'static_zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame','media_condition':'static_first'}]
            static.extend({**c,'name':'static_'+c['name'],'media_condition':'static_first'} for c in old_branches if c['name'].endswith(('_plus','_minus')))
            temporal=[]
            for c in old_recipes:
                if len(c['source_branches'])!=3:continue
                base,plus,minus=c['source_branches'];parts=c['name'].split('_',2)
                temporal.append({**c,'name':parts[0]+'_'+parts[1]+'_temporal_'+parts[2],
                                 'combination_type':'temporal_region_contrast','source_branches':[base,plus,minus,'static_'+plus,'static_'+minus]})
            for weight in [1.,2.,4.]:temporal.append({'name':f'contrast_vcd_static_first_lambda{weight:g}','k':0,'contrast_weight':weight,'combination_type':'visual_contrast','source_branches':['baseline','static_baseline']})
            cfg.update(output_dir=str(out),stage='prospectively_frozen_temporal_region_development',branch_conditions=old_branches+static,
                conditions=old_recipes+[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in static]+temporal,
                hypothesis='Subtract region-attention sensitivity on a frozen first-frame trajectory to reduce static object appearance priors and isolate task-relevant change.',
                combination='z0 + lambda*((z_plus_observed-z_minus_observed)-(z_plus_static-z_minus_static)); all native score bins retained',
                counterfactual='First frame repeated in memory only. Original text, native tokens, grids and presentation timestamps must remain identical. Tracking boxes follow displayed first-frame pixels.',
                selection_rule='Full234 and final confirmation require strict four-way improvement and +10pp. A60 screening ceiling at100% suc permits only extension with suc unchanged, fail improved, MAE lower and +10pp; it never counts as final acceptance.')
            path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_temporal_development_v1_{model}_{protocol}.yaml'
            with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            create_json(out/'ranking.json',json.loads((source/'ranking.json').read_text()))
            source_path=source/'score_branches.jsonl';digest=hashlib.sha256(source_path.read_bytes()).hexdigest()
            ids=set(json.loads(pathlib.Path(cfg['example_ids_file']).read_text()));old_names={c['name'] for c in old_branches}
            observed={(r['example_id'],r['condition']):r for r in read_rows(source_path)}
            assert all((i,n) in observed for i in ids for n in old_names)
            for row in observed.values():
                if row['example_id'] in ids and row['condition'] in old_names:append(out/'score_branches.jsonl',{**row,'reused_from':str(source_path),'reused_source_sha256':digest,'reuse_time':timestamp()})
            create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':cfg['hypothesis'],'config':cfg,'config_sha256':fingerprint(cfg),'observed_branches_reused_from':str(source_path),'observed_source_sha256':digest,'confirmation_metrics_used':False})
            plans.append(str(path))
    create_json(root/'prospective_plan.json',{'time':timestamp(),'configs':plans,'all_native_bins_retained':True,'phase':'same 60 development examples /24 whole video clusters','static_neural_branches_per_case':18,'novel_method_performance_inspected':False})
    print(root,'15 configs,18 new neural branches/case; observed branches reused with source hashes')


if __name__=='__main__':main()
