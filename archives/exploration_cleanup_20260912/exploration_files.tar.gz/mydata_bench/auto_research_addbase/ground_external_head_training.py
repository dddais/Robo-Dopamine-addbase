"""Label-free localization of eligible training/validation media over exactly eight observations."""
import dataclasses
import hashlib
import json
import os
import pathlib
import subprocess
import time
import traceback
import cv2
import numpy as np
from .common import ROOT, create_json, append, read_rows, timestamp
from .prepare_external_head_training import OUT
from .robust_prepare import digest


def make_proxy(sample, folder):
    """Lossless eight-frame proxy; decoded pixels must match all input PNGs."""
    folder.mkdir(parents=True, exist_ok=True)
    manifest = folder / (sample['video_sha256'] + '.json')
    if manifest.exists():
        record = json.loads(manifest.read_text())
        if record['source_pixel_sha256'] != sample['decoded_frame_pixel_sha256']:
            raise ValueError('Proxy source pixels changed')
        return record['path']
    path = folder / (sample['video_sha256'] + '.mkv')
    if path.exists():
        raise FileExistsError('Incomplete proxy exists; preserve and inspect')
    frames = [cv2.imread(p) for p in sample['image_paths']]
    if len(frames) != 8 or any(frame is None for frame in frames) or any(frame.shape != frames[0].shape for frame in frames):
        raise ValueError('Eight equal-size decoded frames required')
    height, width = frames[0].shape[:2]
    writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*'FFV1'), 1., (width, height))
    if not writer.isOpened():
        raise ValueError('FFV1 lossless proxy writer unavailable')
    try:
        for frame in frames:
            writer.write(frame)
    finally:
        writer.release()
    cap = cv2.VideoCapture(str(path))
    decoded = []
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            decoded.append(frame)
    finally:
        cap.release()
    if len(decoded) != 8 or any(not np.array_equal(a, b) for a, b in zip(frames, decoded)):
        raise ValueError('Proxy is not pixel-exact')
    create_json(manifest, dict(path=str(path), sha256=digest(path), source_pixel_sha256=sample['decoded_frame_pixel_sha256'],
        proxy_indices=list(range(8)), original_source_indices=sample['image_source_indices'],
        purpose='SAM3 only; reward models still receive original frames and timestamps', pixel_exact=True))
    return str(path)


def main():
    dest = OUT / 'grounding_v1'
    dest.mkdir(exist_ok=True)
    cfg = dict(model_path='/home/dais/workspace/model/sam3', checkpoint_path='/home/dais/workspace/model/sam3/sam3.pt',
               device='cuda', threshold=.30, mask_threshold=.50, top_n=20)
    create_json(dest / 'grounding_plan_v1.json', dict(time=timestamp(), pid=os.getpid(), source_sha256=digest(__file__),
        sam3_config=cfg, task_parser_source_sha256=digest(ROOT / 'mydata_bench/grounding/parser.py'),
        sam3_source_sha256=digest(ROOT / 'mydata_bench/grounding/sam3.py'),
        selection_source_sha256=digest(ROOT / 'mydata_bench/grounding/base.py'),
        eligibility='one unambiguous object/object_part target; relational phrases resolved geometrically on first frame',
        tracking='existing SAM3 same-instance box tracking on pixel-exact eight-frame FFV1 proxy',
        required_tracking='all8 displayed frames; duplicate source-index boxes combined by envelope',
        grounding_failure_policy='keep sample; whole-method fallback to each model baseline; never turn absence into a reward endpoint',
        eligible_training_denominator_frozen_by_media_overlap_audit=True, label_files_not_read=True, test_model_scores_not_computed=True))
    launch = json.loads((OUT / 'parser_launch_v1.json').read_text())
    while not (dest / 'parser_completion_v1.json').exists():
        process = pathlib.Path('/proc') / str(launch['pid']) / 'cmdline'
        if not process.exists() or b'mydata_bench.auto_research_addbase.parse_external_head_training' not in process.read_bytes():
            raise RuntimeError('Parser stopped without a terminal record; inspect before proceeding')
        time.sleep(20)
    done = json.loads((dest / 'parser_completion_v1.json').read_text())
    if digest(dest / 'parsed_targets_v1.jsonl') != done['records_sha256']:
        raise ValueError('Frozen parser results changed')
    input_done = json.loads((OUT / 'media_overlap_audit_v1.json').read_text())
    if digest(OUT / 'training_inputs_audited_v1.jsonl') != input_done['inputs_sha256']:
        raise ValueError('External inputs changed')
    tasks = {row['task_id']: row for row in read_rows(dest / 'parsed_targets_v1.jsonl')}
    samples = [r for r in read_rows(OUT / 'training_inputs_audited_v1.jsonl') if r['training_eligible']]
    gpu = int(os.environ.get('CUDA_VISIBLE_DEVICES', '3'))
    while True:
        free = int(subprocess.check_output(['nvidia-smi', f'--id={gpu}', '--query-gpu=memory.free', '--format=csv,noheader,nounits'], text=True).strip())
        if free >= 30000:
            break
        append(dest / 'grounding_events_v1.jsonl', dict(time=timestamp(), event='memory_wait', free_mib=free))
        time.sleep(20)
    from mydata_bench.grounding.sam3 import SAM3Grounder
    from mydata_bench.grounding.parser import build_queries, reference_queries
    from mydata_bench.grounding.base import select_relational_candidate
    from mydata_bench.schemas import TargetSpec
    grounder = SAM3Grounder(cfg)
    begin, grounded, errors = time.monotonic(), 0, 0
    for index, sample in enumerate(samples, 1):
        task = tasks[hashlib.sha256(sample['task'].encode()).hexdigest()]
        row = dict(time=timestamp(), example_id=sample['example_id'], video_sha256=sample['video_sha256'])
        result = dict(sample)
        try:
            if task['status'] != 'ok':
                raise ValueError('Preserved target parser failure')
            value = dict(task['target'])
            value.pop('schema_version', None)
            value['example_id'] = sample['example_id']
            value['attributes'] = tuple(value.get('attributes', []))
            value['targets'] = tuple(value.get('targets', []))
            target = TargetSpec(**value)
            if target.multi_target or target.ambiguous or target.entity_type not in ['object', 'object_part']:
                row.update(status='baseline_fallback', reason='outside predeclared single-unambiguous-object grounding scope')
            else:
                queries = build_queries(target)
                first = sample['image_paths'][0]
                candidates = grounder.candidates(first, queries)
                if target.relation:
                    reference = grounder.candidates(first, reference_queries(target))
                    selected, _, reason = select_relational_candidate(first, candidates, reference, target.relation)
                else:
                    selected = grounder.select(first, candidates, len(queries))
                    reason = 'first_frame_open_vocabulary_detection'
                if selected is None:
                    row.update(status='baseline_fallback', reason='no legal first-frame target')
                else:
                    proxy = make_proxy(sample, dest / 'proxies')
                    tracks = grounder.track(proxy, selected['bbox'], 0)
                    by_proxy = {int(t['frame_index']): t for t in tracks if t.get('bbox') is not None}
                    if set(by_proxy) != set(range(8)):
                        row.update(status='baseline_fallback', reason='tracking incomplete across displayed frames',
                                   tracked_proxy_indices=sorted(by_proxy))
                    else:
                        grouped = {}
                        for proxy_index, source_index in enumerate(sample['image_source_indices']):
                            grouped.setdefault(source_index, []).append(by_proxy[proxy_index]['bbox'])
                        mapped = [dict(frame_index=source_index, bbox=[min(b[0] for b in boxes), min(b[1] for b in boxes),
                                  max(b[2] for b in boxes), max(b[3] for b in boxes)]) for source_index, boxes in sorted(grouped.items())]
                        path = dest / 'tracks' / (sample['example_id'] + '.json')
                        create_json(path, dict(frames=mapped, proxy_path=proxy, original_source_indices=sample['image_source_indices'],
                            all8_displayed_frames_tracked=True, first_selection_reason=reason,
                            raw_proxy_tracks=[{k: v for k, v in t.items() if k != '_mask'} for t in tracks]))
                        result.update(first_bbox=selected['bbox'], last_bbox=by_proxy[7]['bbox'],
                            first_image_path=sample['image_paths'][0], last_image_path=sample['image_paths'][-1], tracking_path=str(path))
                        row.update(status='ok', tracking_path=str(path), selection_reason=reason)
                        grounded += 1
        except Exception as exc:
            traceback.print_exc()
            errors += 1
            row.update(status='baseline_fallback', reason='grounding_runtime_error', error=repr(exc))
            try:
                import torch
                torch.cuda.empty_cache()
            except ImportError:
                pass
        result.update(grounding_status=row['status'], grounding_fallback_reason=row.get('reason'),
                      grounding_evidence_path=row.get('tracking_path'))
        append(dest / 'grounding_records_v1.jsonl', row)
        append(dest / 'grounded_inputs_v1.jsonl', result)
        if index % 25 == 0 or index == len(samples):
            print(json.dumps(dict(time=timestamp(), processed=index, expected=len(samples), grounded=grounded,
                baseline_fallback=index-grounded, runtime_errors=errors, elapsed_seconds=time.monotonic()-begin)), flush=True)
    create_json(dest / 'grounding_completion_v1.json', dict(time=timestamp(), expected_samples=len(samples),
        grounded=grounded, baseline_fallback=len(samples)-grounded, runtime_errors=errors,
        output_sha256=digest(dest / 'grounded_inputs_v1.jsonl'), label_files_not_read=True,
        test_model_scores_not_computed=True))


if __name__ == '__main__':
    main()
