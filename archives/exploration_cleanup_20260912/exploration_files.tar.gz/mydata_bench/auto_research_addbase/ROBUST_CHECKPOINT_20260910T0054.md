# Robust research checkpoint — 2026-09-10 00:54 Asia/Shanghai

Current goal is active and unachieved. This turn made substantive progress, not a blocked turn. Do not mark complete or blocked. Continue finding a new, non-overfit method for target3.

## Scope and operational rules

- Only target repository `/home/dais/workspace/Robo-Dopamine-addbase` (physical `/mnt/public1/dais/workspace/Robo-Dopamine-addbase`). Explicit cwd and `login:false` for every exec.
- No git operations, no reading other code repositories, no deleting/overwriting old results; all frozen source/config hashes remain immutable. No subagents or permission questions.
- Python `/home/dais/miniconda3/envs/robo-dopamine/bin/python`; SAM3 `/home/dais/miniconda3/envs/rewardbench-sam3/bin/python`.
- academic-research-suite already applied inline. Chinese commentary.
- Result root R=`results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1`.

## User question and scientific conclusion

User asks whether the old method is cheating. Checked actual old entropy/anchor code and adaptive experiment history. No direct answer-reading or endpoint hardcoding evidence found in checked inference code, but clear adaptive reuse of confirmation498 after initial failures. Full846 includes development/ranking, never independent. Old Meter text_video second-threshold suc fell14.9254pp at full846 primary. Old result cannot count for current robust goal.

Created `METHOD_VALIDITY_AUDIT_20260910.md` with simple explanation and evidence. Appended correction links to root experiment plan, robust protocol, and old `FINAL_RESEARCH_REPORT_20260909.md`. All original values/failures retained.

## Current families (all original old234 development only)

All use Qwen/RR/Meter × five protocols, shared k32/48/64, primary48; no current family has confirmed success. `robust_analyze --family f1|f2|f3|f4|f5` supports all. Only completed cases analyzed; whole-case gate includes both Meter thresholds, both baselines, all3k, same-k and best-development original.

F1 frame transport: latest analyzed13 allfailed, allzero exact. AllRR and allQwen finished; Meter still in queue. F2 fixedVCD: latest6 analyzed allfailed, RRall5 and Qwen text_video. F3 specificity ranking: RRall5 finished, wholecaseallfailed. F4 jointtaskattention: RRall5 finished, wholecaseallfailed. Primary F4 suc drops at every RR input. LatestF4 analysis `f4_frame_transport_analysis_2026-09-09T165149.021698_0000.json`; F2 `f2_frame_transport_analysis_2026-09-09T165150.617166_0000.json`.

F1–F4 mechanisms/frozen files/older queues described in `ROBUST_RESEARCH_PROTOCOL_20260909.md` and preceding checkpoint/turn summary. Do not repeat readout-query steering as novel: old20260908 readout-query family already tried15×60 and failed; this was rechecked during this turn.

## New F5: task-embedding / attention interaction

Frozen formula: `z_F5 = z_original(actual_task) - [z_original(task_embeddings_zero) - z_baseline(task_embeddings_zero)]`.

All fifteen cases share unitweight, original bias6, allframes/allqueries, original raw_mass headranking, k32/48/64, primary48. No old entropy, confidence, KL, static video, anchor or case-specific gains. All bins retained. Zeroing ONLY exact actualTask input embedding positions; actual input_ids,length,pixels,grid,timestamps retained. ROI remains based on real current task, and positional/length information remains, so this is not a completely task-free branch. Zero embeddings may be OOD; no physical causal identification claim.

Files (now frozen): `task_interaction.py`, `_runtime.py`, `_runner.py`, `_queue.py`, `freeze_task_interaction.py`. Configs `addbase_robust_task_interaction_v1_*.yaml`; plan `R/task_interaction_frozen_plan_v1.json`; outputs `R/task_interaction_v1/{case}/{engineering,development}`. Existing joint_task_attention.py only reused for exact Task token span matching, not F4attention.

Full234 each: native/readout baseline, original3k, new3k, wholezero, wholewrong, wholelow, no-attention taskcontrast `2*z_baseline(actual)-z_baseline(ablated)`. Control reported, not secretly used to change original goalgate. Actual original branches reused from hashed F1; real two-example engineering checks recompute baseline/original/new formula, require exactcacheparity and exactwholezero plus exactablatedzero. Null baseline cached percurrent sample, not across samples.

Two meaningful tests passed (`pytest -q .../test_task_interaction.py`): localembeddingablation & hookrestoration/error handling; allbins/permutation/zero. First run had a harmless requires_grad scalarwarning, fixed withdetach BEFOREfreezing; final2passedno warnings.

F5 RRimage_text and RRtext_video engineering PASSED on both old engineerexamples: actualcacheexact, neutralhookonce, neutralzeroexact, wholezeroexact, nonzerohookcalled. Fulldevelopment started and running. No F5 performance analyzed yet. All75configurations and declaredsourcehashes acrossF1–F5 checkedexact: `R/all_five_frozen_lineage_audit_20260910T0054_v1.json`.

## Processes / queues (revalidate /proc and completion, never trust PID alone)

F1: GPU0/1/3 completedfailures[]; GPU2queue2223140 running.
F2: GPU0/3 completedfailures[]; GPU1queue2235606, GPU2queue2235607.
F3: GPU0/3 completedfailures[]; GPU1queue2304131, GPU2queue2304132.
F4: GPU0/3 completedfailures[]; GPU1queue2308875, GPU2queue2308876.
F5 newlylaunched: GPU0queue2312041, GPU1queue2312042, GPU2queue2312043, GPU3queue2312044. Launchmanifest `f5_durable_launches_v1.json`. Eachwaits previous sameGPUqueue terminal and checks livePIDwhilewaiting.

Allocationeachfamily: GPU0RRtext_video/video_text/text_image, GPU1Qwenallfive, GPU2Meterallfive, GPU3RRimage_text/interleaved. GPU1/2queues of laterfamilies may stillwait. AlreadycompletedGPU0/3 olderqueues mustnotrestart.
Foreign GPUprocesses from Robo-Dopamine continue; do not inspecttheircode or stopthem.

## External data — no reward-model performance computed or labels evaluated

EXT=`R/external_roboreward_reserved_v1`; pinned officialtestrevision `469b9af76e8539e8d2ac553b081307738fd92ca5`. Latest `inputs_without_labels_v4.jsonl` and `preparation_completion_v4.json`:2831/2831ready,2551bytehashes; original sealedlabels unchanged. Prior502offby1decoderepairs+6SSLrepairs allpreserved. Latestfullperceptualoverlapauditv4:0exact/0sparseflags againstold407. Cannotexcludesharedepisodesortrainingcontamination.

New `robust_external_episode_groups.py` generated `episode_grouping_plan_v1.json`, `episode_grouping_records_v1.jsonl`, `episode_grouping_audit_v1.json`:2831examples→1172conservativeconnectedsourceepisodegroups, largest8, unresolved0.1831RLDS-stylepaths groupedbysubset/originalsplit/leadingepisodeindex;1000RoboArena paths byUUID;unionalsobyexactbytes/all8pixels. Allfilenamesuffixcontents ignored. No exclusion and no label/performance reading. Usegroupsforfutureclusterbootstrap; not proof ofindependence. Two tests passed; firstpytestrelativeimportcollectionfailure fixed before freeze. Rawfilenamescontain score suffixes; only hashedlocalpaths enter modelinput. Sanitizeddigit-to-N filename shapes were inspected, not rawrewardvalues.

New `proxy_dimension_preflight_v1.json`: all2551videos haveevendimensions,10sizes. No OpenCVFFV1odddimensiontruncation expected.

SAM3 engineeringfromoldranking COMPLETEPASS: `R/external_grounding_engineering_v1/result_v1.json`; image API valid, losslessFFV1pixels exact, trackedall8indices. Prior execsession13830 finishedexit0 and polled. No needrerun.

TaskparserPID2302973 onGPU3:1043uniquetasks, latest975/1043 at16:53:39UTC, errors0. Read `EXT/parser_stdout_v1.log` and `grounding_v1/parser_completion_v1.json` whenappears. GrounderwaiterPID2309556 onGPU3 isalreadyrunning, waitingforparser; exactsourceunchanged. `EXT/grounding_stdout_v1.log` emptyat16:54UTC. Expectstartshortly, inspectfirstrealrowsforruntimefailure before lettingthousandsfall back. Outputs `grounding_v1/grounding_records_v1.jsonl`, `grounded_inputs_v1.jsonl`, tracks/proxies/completion. Singleunambiguousobject/object_part; firstframeSAM3threshold.3/mask.5/top20 then8framepixel-exactproxytracking; requireall8, mapbackoriginalsourceindices. Unsupported/missing/failure=>baselinefallback withfull2831denominator; noendpoints/exclusion. Labels sealedonlybyworkflow, not thirdpartyblinding.

## Immediate next steps

1. Check parsercompletion and first externalgrounding successes/errors. Do not alter a running frozen source; if engineering fails, preserve and version a justified correction and manage only verifiedownprocesses.
2. Analyze newlycompletedF1–F5 and retainallfailures. F5actualengineeringpassed, fulloutcomespending. Do not markgoalcomplete basedonvalidcode.
3. Continue theory-drivendevelopment if candidatefamiliesfail; no externalperformance-guidedselection. Save each newfamilybeforeitsperformance.
4. Before independenttest: allgrounding/coverage/fallbackaudits, freezechosenmethod/settings/cases/metrics/analysis, thenone-timeindependentinference/labeljoin with1172sourcegroups. Oldfull846verificationremainsdescriptive andcannotreplace externalvalidation. External1–5includesmiddlegrades; neveroptimizetoendpoints.
5. Finalreport stillrequires alltarget3acceptanceevidence. Goalactive. No pending toolsessions fromthisturn; allpolled. Processesabovekeepworking.

Actual completedcase counts at checkpoint: {"F1": 14, "F2": 6, "F3": 5, "F4": 5, "F5": 0}
RecordedUTC: 2026-09-09T16:55:51.867253+00:00

## Late analysis update

2026-09-09T16:56:45.856935+00:00

Latest completed-only analyses: {"f1": {"path": "results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f1_frame_transport_analysis_2026-09-09T165629.341194_0000.json", "completed": 14, "passing": {"qwen": 0, "rr": 0, "meter": 0}}, "f2": {"path": "results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f2_frame_transport_analysis_2026-09-09T165150.617166_0000.json", "completed": 6, "passing": {"qwen": 0, "rr": 0, "meter": 0}}, "f3": {"path": "results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f3_frame_transport_analysis_2026-09-09T163425.026175_0000.json", "completed": 5, "passing": {"qwen": 0, "rr": 0, "meter": 0}}, "f4": {"path": "results/mydata_bench/experiments_v2_corssmodel/auto_research/session_20260909_robust_v1/f4_frame_transport_analysis_2026-09-09T165149.021698_0000.json", "completed": 5, "passing": {"qwen": 0, "rr": 0, "meter": 0}}}
All tool sessions polled; no unfinished exec sessions.
