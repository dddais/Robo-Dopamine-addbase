"""Recover the six recorded transient SSL failures, without changing sources."""
import hashlib
import json
import urllib.parse
import urllib.request
import requests
from .common import create_json, append, read_rows, timestamp
from .robust_external_data import OUT
from .robust_external_decode_v2 import recover
from .robust_prepare import digest


def main():
    failed = [r for r in read_rows(OUT / 'download_records_v1.jsonl') if r['status'] != 'ok']
    before = json.loads((OUT / 'preparation_completion_v3.json').read_text())
    inputs = list(read_rows(OUT / 'inputs_without_labels_v3.jsonl'))
    revision = json.loads((OUT / 'reservation_v1.json').read_text())['revision']
    create_json(OUT / 'network_recovery_plan_v3.json', dict(time=timestamp(), source_sha256=digest(__file__),
        failed_source_keys=[r['source_key'] for r in failed], reason='all prior errors were transient SSL unexpected EOF',
        original_attempts_preserved=True, source_revision_unchanged=revision,
        metadata_fields_used=['file_name', 'task'], reward_and_check_not_used=True,
        model_predictions_not_accessed=True, old_inputs_sha256=before['inputs_sha256']))
    cache = {}
    for filename in ['decode_records_v1.jsonl', 'actual_decode_repair_records_v2.jsonl']:
        for row in read_rows(OUT / filename):
            if row['status'] == 'ok':
                cache[row['video_sha256']] = row
    recovered = {}
    folder = OUT / 'network_recovery_v3'
    folder.mkdir(exist_ok=True)
    for record in failed:
        row = dict(source_key=record['source_key'], status='error')
        try:
            remote = urllib.parse.quote(record['source_name'], safe='/')
            url = f'https://huggingface.co/datasets/teetone/RoboReward/resolve/{revision}/test/{remote}'
            path = folder / (record['source_key'] + '.mp4')
            response = requests.get(url + '?download=true', timeout=(20, 60))
            response.raise_for_status()
            raw = response.content
            with path.open('xb') as handle:
                handle.write(raw)
            h = hashlib.sha256(raw).hexdigest()
            decoded = cache.get(h)
            if decoded is None:
                decoded = recover(dict(path=str(path), video_sha256=h))
                append(OUT / 'network_recovery_decode_records_v3.jsonl', dict(time=timestamp(), **decoded))
            if decoded['status'] != 'ok':
                raise ValueError('Recovered download failed verified decoding: ' + decoded.get('error', 'unknown'))
            row.update(status='ok', path=str(path), video_sha256=h, bytes=len(raw), decoded=decoded)
            recovered[record['source_key']] = row
        except Exception as exc:
            row.update(status='error', error=repr(exc))
        append(OUT / 'network_recovery_records_v3.jsonl', dict(time=timestamp(), **row))
        print(json.dumps({k: v for k, v in row.items() if k not in ['decoded', 'path']}), flush=True)
    id_recovery = {}
    # Mechanical reconstruction of opaque identifiers uses only the original
    # file_name/task fields. No reward/check field or test score is consulted.
    for index, row in enumerate(read_rows(OUT / 'test_metadata_sealed.jsonl')):
        key = hashlib.sha256(row['file_name'].encode()).hexdigest()
        if key in recovered:
            eid = hashlib.sha256((str(index) + ':' + row['file_name'] + ':' + row['task']).encode()).hexdigest()
            id_recovery[eid] = recovered[key]
    output = []
    for old in inputs:
        row = dict(old)
        replacement = id_recovery.get(row['example_id'])
        if replacement:
            row.update(video_sha256=replacement['video_sha256'], video_path=replacement['path'],
                       preparation_status='ok', preparation_version='network_recovery_v3',
                       **{k: replacement['decoded'][k] for k in ['image_paths', 'image_source_indices', 'image_sampling_record', 'decoded_frame_pixel_sha256']})
        output.append(row)
    path = OUT / 'inputs_without_labels_v4.jsonl'
    with path.open('x') as handle:
        for row in output:
            handle.write(json.dumps(row, ensure_ascii=False) + '\n')
    create_json(OUT / 'preparation_completion_v4.json', dict(time=timestamp(), expected_rows=len(output),
        ready_rows=sum(r['preparation_status'] == 'ok' for r in output), network_recovered=len(recovered),
        remaining_failed_ids=[r['example_id'] for r in output if r['preparation_status'] != 'ok'],
        inputs_sha256=digest(path), labels_sealed_sha256=before['labels_sealed_sha256'],
        independent_overlap_audit_must_cover_all_v3_inputs=True, external_performance_not_evaluated=True))


if __name__ == '__main__':
    main()
