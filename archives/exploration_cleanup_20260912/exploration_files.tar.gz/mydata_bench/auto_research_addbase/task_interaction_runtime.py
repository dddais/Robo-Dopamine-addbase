"""Three neural branches: real-task steering minus task-ablated steering effect."""
import numpy as np
from .score_branches import ScoreRuntime, score_readout
from .joint_task_attention import task_token_positions
from .task_interaction import ablate_task_embeddings, interaction_logits


class TaskInteractionRuntime(ScoreRuntime):
    def prepare(self, sample, media_condition='observed'):
        prepared = super().prepare(sample, media_condition)
        positions, audit = task_token_positions(self.runtime.processor.tokenizer,
            prepared['inputs']['input_ids'][0].tolist(), sample['task'],
            self.config['model'], self.config['protocol'])
        visual = {p for span in prepared['spans'] for p in range(span.start, span.end)}
        if visual & set(positions):
            raise ValueError('Task embedding positions overlapped visual keys')
        prepared.update(task_positions=positions, task_alignment_audit=audit, ablated_cache={})
        return prepared

    def ablated(self, sample, prepared, condition, heads):
        diag = {}
        embedding = self.runtime.model.model.language_model.embed_tokens
        with ablate_task_embeddings(embedding, prepared['task_positions'], prepared['inputs']['input_ids'], diag):
            result = super().predict(sample, prepared, condition, heads)
        result['task_embedding_ablation_audit'] = diag
        return result

    def predict(self, sample, prepared, condition, heads):
        if condition.get('kind') not in ['task_interaction', 'task_contrast_only']:
            return super().predict(sample, prepared, condition, heads)
        if 'baseline' not in prepared['ablated_cache']:
            prepared['ablated_cache']['baseline'] = self.ablated(sample, prepared, {}, [])
        ablated_base = prepared['ablated_cache']['baseline']
        if condition['kind'] == 'task_contrast_only':
            actual = prepared['cached_records']['baseline']
            if actual['status'] != 'ok':
                raise ValueError('Preserved actual baseline failure')
            logits = (2*np.asarray(actual['score_logits'], dtype=np.float64)
                      - np.asarray(ablated_base['score_logits'], dtype=np.float64)).tolist()
            return dict(score_logits=logits, **score_readout(logits, self.config['model']),
                ablated_baseline=ablated_base, formula='2*z_actual_baseline-z_ablated_baseline',
                task_alignment_audit=prepared['task_alignment_audit'])
        actual_condition = dict(condition, kind='bias')
        can_reuse = condition['bias'] == 6. and condition.get('region', 'target') == 'target' and condition.get('head_group', 'high') == 'high'
        cached_name = f'original_all_k{condition["k"]}'
        if can_reuse and prepared['stage'] == 'development':
            actual = prepared['cached_records'][cached_name]
            if actual['status'] != 'ok':
                raise ValueError('Preserved actual steering failure')
        else:
            actual = super().predict(sample, prepared, actual_condition, heads)
            if can_reuse:
                reference = prepared['cached_records'][cached_name]
                if reference['status'] != 'ok' or any(actual.get(k) != reference.get(k)
                    for k in ['score_logits', 'progress', 'native_prediction']):
                    raise ValueError('Recomputed actual steering differs from frozen clean cache')
        ablated_steered = self.ablated(sample, prepared, actual_condition, heads)
        logits = interaction_logits(actual['score_logits'], ablated_steered['score_logits'], ablated_base['score_logits'])
        return dict(score_logits=logits, **score_readout(logits, self.config['model']),
            actual_steered_logits=actual['score_logits'], ablated_baseline=ablated_base,
            ablated_steered=ablated_steered, actual_steered_cached=can_reuse and prepared['stage'] == 'development',
            actual_steered_cache_verified=can_reuse and prepared['stage'] == 'engineering',
            hook_diagnostics=ablated_steered['hook_diagnostics'],
            task_alignment_audit=prepared['task_alignment_audit'],
            engine='task_embedding_attention_interaction_v1',
            formula='z_actual_steered - (z_ablated_steered - z_ablated_baseline)',
            fitted_gain_or_endpoint_mapping=False)
