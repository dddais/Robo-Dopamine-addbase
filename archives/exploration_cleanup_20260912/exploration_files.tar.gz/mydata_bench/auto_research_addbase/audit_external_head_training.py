"""Quarantine selected training media with old/test or fit/validation overlap."""
import collections
import hashlib
import json
import pathlib
import cv2
import numpy as np
from .common import BASE, create_json, read_rows, timestamp
from .prepare_external_head_training import OUT
from .robust_external_episode_groups import group_components
from .robust_prepare import DEST, digest


def bits(paths):
    result = []
    for index in [0,3,7]:
        im = cv2.imread(paths[index], cv2.IMREAD_GRAYSCALE)
        if im is None:
            raise ValueError('Unreadable overlap-audit frame')
        low = cv2.resize(im, (32,32), interpolation=cv2.INTER_AREA).astype(np.float32)
        values = cv2.dct(low)[:8,:8].reshape(-1)[1:]
        result.append(values > np.median(values))
    return np.stack(result)


def pixel_hashes(paths):
    return tuple(hashlib.sha256(cv2.imread(path).tobytes()).hexdigest() for path in paths)


def main():
    done = json.loads((OUT/'media_preparation_completion_v1.json').read_text())
    path = OUT/'inputs_without_labels_v1.jsonl'
    if digest(path) != done['inputs_sha256']:
        raise ValueError('Training inputs changed')
    test_path = DEST/'external_roboreward_reserved_v1/inputs_without_labels_v4.jsonl'
    test_done = json.loads((test_path.parent/'preparation_completion_v4.json').read_text())
    if digest(test_path) != test_done['inputs_sha256']:
        raise ValueError('Reserved test inputs changed')
    create_json(OUT/'media_overlap_plan_v1.json', dict(time=timestamp(), source_sha256=digest(__file__),
        training_inputs_sha256=digest(path), test_inputs_sha256=digest(test_path), old_inputs_sha256=digest(BASE/'inputs/full.jsonl'),
        rule='exclude whole training source/byte/pixel connected group on exact or three-frameDCT<=4 matches to reserved test/old data; quarantine exact connected components crossing training fit/validation',
        perceptual='same frozen32x32DCT8x8minusDC at displayed0,3,7 as reserved test overlap audit',
        labels_or_model_performance_read=False, decisions_change_test_inputs=False))
    rows = list(read_rows(path))
    ready = [r for r in rows if r['preparation_status']=='ok']
    episodes = {r['example_id']:r['source_episode_sha256'] for r in ready}
    components = group_components(ready, episodes)
    partitions = collections.defaultdict(set)
    for row in ready:
        partitions[components[row['example_id']]].add(row['training_partition'])
    bad_groups = {group:{'training_fit_validation_exact_overlap'} for group, split in partitions.items() if len(split)>1}
    references = []
    for source, reference_path in [('reserved_test',test_path), ('old_data',BASE/'inputs/full.jsonl')]:
        unique = {r['video_sha256']:r for r in read_rows(reference_path)}
        for h, row in sorted(unique.items()):
            references.append(dict(source=source, video_sha256=h,
                pixels=tuple(row.get('decoded_frame_pixel_sha256') or pixel_hashes(row['image_paths'])),
                bits=bits(row['image_paths'])))
    reference_bits = np.stack([r['bits'] for r in references])
    refs_bytes, refs_pixels = collections.defaultdict(list), collections.defaultdict(list)
    for index, row in enumerate(references):
        refs_bytes[row['video_sha256']].append(index)
        refs_pixels[row['pixels']].append(index)
    train_by_hash = collections.defaultdict(list)
    for row in ready:
        train_by_hash[row['video_sha256']].append(row)
    flags = []
    for i, (h, samples) in enumerate(sorted(train_by_hash.items()),1):
        row = samples[0]
        exact = set(refs_bytes[h]) | set(refs_pixels[tuple(row['decoded_frame_pixel_sha256'])])
        distances = np.count_nonzero(reference_bits != bits(row['image_paths'])[None,...], axis=-1)
        potential = set(np.flatnonzero((distances<=4).all(-1)).tolist())
        for match in sorted(exact | potential):
            ref = references[match]
            reason = ref['source'] + ('_exact_overlap' if match in exact else '_sparse_perceptual_flag')
            flags.append(dict(training_video_sha256=h, reference_video_sha256=ref['video_sha256'],
                reason=reason, three_hamming_distances=distances[match].tolist()))
            for sample in samples:
                bad_groups.setdefault(components[sample['example_id']],set()).add(reason)
        if i%100==0 or i==len(train_by_hash):
            print(json.dumps(dict(time=timestamp(), audited=i, expected=len(train_by_hash), flags=len(flags))),flush=True)
    output = OUT/'training_inputs_audited_v1.jsonl'
    retained, quarantined = collections.Counter(), collections.Counter()
    with output.open('x') as handle:
        for row in rows:
            group = components.get(row['example_id'])
            reasons = sorted(bad_groups.get(group,set())) if group else ['media_unavailable']
            eligible = not reasons
            value = dict(row, training_episode_group_sha256=group, training_eligible=eligible,
                         training_quarantine_reasons=reasons)
            (retained if eligible else quarantined)[row['training_partition']] += 1
            handle.write(json.dumps(value,ensure_ascii=False)+'\n')
    create_json(OUT/'media_overlap_audit_v1.json',dict(time=timestamp(), examples=len(rows), ready=len(ready),
        reference_video_count=len(references), training_video_count=len(train_by_hash),
        exact_training_components=len(partitions), retained_by_partition=dict(retained), quarantined_by_partition=dict(quarantined),
        quarantined_group_count=len(bad_groups), flags=flags, inputs_sha256=digest(output),
        all_expected_rows_retained_in_audit=True, reserved_test_inputs_unchanged=True, labels_or_rewards_read=False,
        limitation='sparse perceptual matching and coarse source IDs do not prove absence of all related episodes or training contamination'))


if __name__ == '__main__':
    main()
