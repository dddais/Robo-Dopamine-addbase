import json
import pytest
import yaml
from mydata_bench.auto_research_addbase.freeze_reward_gradient_confirmation import selected_confirmation_cases
from mydata_bench.auto_research_addbase import analyze_reward_gradient_confirmation as analyzer
from mydata_bench.auto_research_addbase.robust_prepare import digest


def test_reserved_confirmation_cannot_replace_failed_original_model_scope():
    cases = {f'{model}_{i}': dict(model=model, full846_point_gate=i < 3)
             for model in ['qwen', 'rr', 'meter'] for i in range(5)}
    analysis = dict(cases=cases, full846_original_scope_gate=True)
    assert len(selected_confirmation_cases(analysis)) == 9
    cases['qwen_2']['full846_point_gate'] = False
    cases['meter_3']['full846_point_gate'] = True
    with pytest.raises(ValueError, match='scope is not met'):
        selected_confirmation_cases(analysis)


def test_incomplete_reserved_outputs_block_test_label_join(tmp_path, monkeypatch):
    root = tmp_path/'reward_gradient_confirmation_v1'
    root.mkdir()
    dummy = tmp_path/'dummy.json'
    dummy.write_text('{}')
    ids = tmp_path/'ids.json'
    ids.write_text(json.dumps(['reserved-'+str(i) for i in range(2831)]))
    cfg = tmp_path/'case.yaml'
    cfg.write_text(yaml.safe_dump(dict(output_dir=str(root/'case'), model='rr', protocol='image_text')))
    plan = dict(source_sha256={}, expected_cases=9,
        configurations=[dict(path=str(cfg), sha256=digest(cfg)) for _ in range(9)])
    for field in ['input', 'example_ids', 'groups', 'policy', 'confirmation_claim', 'selection_analysis']:
        path = ids if field == 'example_ids' else dummy
        plan[field+'_file'] = str(path)
        plan[field+'_sha256'] = digest(path)
    (root/'frozen_plan_v1.json').write_text(json.dumps(plan))
    monkeypatch.setattr(analyzer, 'DEST', tmp_path)
    def forbidden_read_rows(path):
        raise AssertionError('No label/input rows may be parsed before all frozen cases finish')
    monkeypatch.setattr(analyzer, 'read_rows', forbidden_read_rows)
    with pytest.raises(FileNotFoundError, match='completion_v1.json'):
        analyzer.main()
    assert not (root/'performance_opening_v1.json').exists()
