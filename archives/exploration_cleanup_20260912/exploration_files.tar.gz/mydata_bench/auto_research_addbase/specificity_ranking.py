"""Task-region excess attention, penalized for variability across video groups."""
import collections
import numpy as np


def rank_specificity(rows, skip_early_layers=8):
    groups = collections.defaultdict(list)
    for row in rows:
        if row.get('status') != 'ok':
            raise ValueError('Ranking requires all predeclared valid localization examples')
        mass = np.asarray(row['raw_mass'], dtype=np.float64)
        visual = np.asarray(row['image_mass'], dtype=np.float64)
        fraction = row['target_count'] / row['visual_count']
        if mass.shape != visual.shape or mass.ndim != 2 or not 0 < fraction <= 1:
            raise ValueError('Invalid localization measurement')
        excess = mass - fraction * visual
        if not np.isfinite(excess).all():
            raise ValueError('Nonfinite head statistic')
        if not np.allclose(excess, row['excess_mass'], atol=1e-12, rtol=1e-10):
            raise ValueError('Saved excess does not reproduce from probabilities and area')
        groups[row['video_sha256']].append(excess)
    if len(groups) < 2:
        raise ValueError('At least two independent video groups required')
    measurements = np.stack([np.mean(groups[key], axis=0) for key in sorted(groups)])
    mean = measurements.mean(0)
    standard_error = measurements.std(0, ddof=1) / np.sqrt(len(groups))
    score = mean - 1.96 * standard_error
    ranking = [dict(layer=layer, head=head, score=float(score[layer, head]),
                    mean_excess=float(mean[layer, head]), standard_error=float(standard_error[layer, head]))
               for layer in range(skip_early_layers, mean.shape[0]) for head in range(mean.shape[1])]
    ranking.sort(key=lambda row: (-row['score'], row['layer'], row['head']))
    return dict(metric='mean_area_adjusted_excess_minus_1.96_video_group_SE',
                sample_count=len(rows), video_groups=len(groups), skip_early_layers=skip_early_layers,
                uses_reward_labels=False, ranking=ranking,
                interpretation='fixed label-free ranking heuristic; not simultaneous confidence intervals for selected heads')
