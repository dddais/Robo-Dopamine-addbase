"""Freeze F2 across all fifteen cases, without reading F2 model outcomes."""
import json
import yaml
from .common import ROOT, create_json, timestamp
from .robust_prepare import DEST, digest


def main():
    old_plan = json.loads((DEST / 'frame_transport_frozen_plan_v1.json').read_text())
    source = ROOT / 'mydata_bench/auto_research_addbase'
    configs = []
    for case in old_plan['configurations']:
        cfg = yaml.safe_load(open(case['path']))
        cfg.update(clean_source_dir=cfg['output_dir'],
                   output_dir=str(DEST / ('frame_transport_vcd_v1/' + case['model'] + '_' + case['protocol'])),
                   stage='development234_F2_fixed_VCD', output_score_adjustment='fixed 2*z_clean-z_corrupted',
                   diffusion_step=500, vcd_weight=1., noise_seed_version='robust-F2-seed0',
                   no_plausibility_mask=True)
        for name in ['frame_transport_vcd.py', 'frame_transport_vcd_runner.py', 'freeze_frame_transport_vcd.py']:
            path = source / name
            cfg['source_sha256'][str(path.relative_to(ROOT))] = digest(path)
        for condition in cfg['conditions']:
            if condition.get('kind') == 'frame_transport':
                condition['vcd_weight'] = 0. if condition['fraction'] == 0 else 1.
        cfg['conditions'].append(dict(name='vcd_only', k=0, clean_source_condition='baseline', vcd_weight=1.))
        for k in cfg['k_neighborhood']:
            cfg['conditions'].append(dict(name=f'vcd_original_k{k}', k=k, clean_source_condition=f'original_all_k{k}', vcd_weight=1., kind='bias', bias=6., scope='all_frames'))
        path = ROOT / f'mydata_bench/configs/v2_crossmodel/addbase_robust_frame_transport_vcd_v1_{case["model"]}_{case["protocol"]}.yaml'
        with path.open('x') as f:
            yaml.safe_dump(cfg, f, sort_keys=False)
        configs.append(dict(model=case['model'], protocol=case['protocol'], path=str(path), sha256=digest(path)))
    create_json(DEST / 'frame_transport_vcd_frozen_plan_v1.json', dict(time=timestamp(), configurations=configs,
        stage='F2 prospective development only', shared_parameters=dict(fraction=.5, vcd_weight=1., diffusion_step=500,
        k_neighborhood=[32, 48, 64], primary_k=48), all_native_bins_preserved=True,
        first_F1_results_known=['qwen_text_video', 'rr_text_video', 'rr_image_text'],
        F2_performance_not_seen=True, external_test_performance_not_seen=True,
        clean_dependency='fixed F1 plan; resolve prediction content hash only after each source is terminal',
        official_VCD_difference='adapted native reward bins, deterministic per-video noise, no adaptive vocabulary filter',
        contribution_controls=['F1_without_VCD', 'VCD_without_F1', 'original_attention_with_same_VCD'],
        reference_noise_implementation=str(DEST / 'references_v1/vcd_noise_master_pinned.py')))
    print('F2 frozen', len(configs), 'cases')


if __name__ == '__main__':
    main()
