"""Frozen reused-data evaluation of development-selected entropy evidence."""
import argparse
import collections
from .common import *
from .entropy_development import PHASE_ROOT, entropy_scaled_logits, name_for
from .score_branches import score_readout
from mydata_bench.meter_eval.readout import canonicalize

OUTPUT = RESEARCH / 'entropy_evidence_evaluation_v1'


def source_folders(case):
    return {'development': pathlib.Path(case['folder']),
            'reused_validation': pathlib.Path(case['confirmation_output_dir']),
            'ranking_overlap_remainder': pathlib.Path(case['output_dir'])}


def freeze():
    plan = json.loads((PHASE_ROOT / 'prospective_plan_v1.json').read_text())
    selection = json.loads((PHASE_ROOT / 'development_selection_v1.json').read_text())
    if fingerprint(plan) != selection['plan_sha256'] or not selection['all_nine_development_eligible']:
        raise ValueError('All nine development selections must be eligible')
    parent = json.loads(pathlib.Path(plan['parent_manifest_path']).read_text())
    if fingerprint(parent) != plan['parent_manifest_sha256']:
        raise ValueError('Parent manifest changed')
    confirmation = json.loads(pathlib.Path(parent['confirmation_manifest_path']).read_text())
    cases = []
    for case in plan['cases']:
        name = case['model'] + '_' + case['protocol']
        audit = json.loads((PHASE_ROOT / name / 'generation_audit_v1.json').read_text())
        if audit['invalid_rows'] or audit['parent_nested_mismatch_ids'] or audit['prior_anchor_nested_mismatch_ids']:
            raise ValueError('Development integrity audit failed')
        dev_path = PHASE_ROOT / name / 'scores.jsonl'
        cases.append({**case, 'parameters': selection['selections'][name]['parameters'],
                      'development_scores_path': str(dev_path),
                      'development_scores_sha256': hashlib.sha256(dev_path.read_bytes()).hexdigest(),
                      'parent_source_sha256': {p: hashlib.sha256((f / 'sweep.jsonl').read_bytes()).hexdigest()
                                               for p, f in source_folders(case).items()}})
    create_json(OUTPUT / 'frozen_manifest_v1.json', {
        'time': timestamp(), 'method_family': 'entropy_scaled_attention_evidence',
        'phase': 'Post-confirmation exploratory evaluation; all validation data reused',
        'development_plan_sha256': fingerprint(plan), 'development_selection_sha256': fingerprint(selection),
        'cases': cases, 'formula': plan['formula'], 'boundary': plan['boundary'],
        'mechanism_limits': plan['mechanism_limits'],
        'partitions': {'development': plan['development_ids_path'],
                       'reused_validation': confirmation['analysis_protocol']['confirmation_ids_file'],
                       'ranking_overlap_remainder': str(RESEARCH / 'frozen_cohort_completion_v1/remaining_ids.json')},
        'partition_ids_sha256': {'development': plan['development_ids_sha256'],
                                'reused_validation': confirmation['analysis_protocol']['ids_sha256'],
                                'ranking_overlap_remainder': parent['remaining_ids_sha256']},
        'full_ids_path': str(RESEARCH / 'frozen_cohort_completion_v1/full_cohort_ids.json'),
        'full_ids_sha256': parent['full_cohort_ids_sha256'], 'labels_sha256': plan['labels_sha256'],
        'source_sha256': {n: hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / n).read_bytes()).hexdigest()
                          for n in ['entropy_development.py', 'entropy_evaluation.py', 'anchor_development.py', 'metrics.py', 'analyze_development.py']},
        'gate': 'All three unchanged k: complete scores, both baselines MAE down/suc up/fail up/total +10pp, same-k original MAE and accuracy improvements, all-neighbor five-bin MAE down. Primary vs development-selected original is a separate strict gate. No reselection after validation.',
        'control_scope': 'Here parent controls use the selected target original anchor; these are conditional evidence-component controls. Whole-method controls are analyzed separately using the already verified neural wrong/low original branches.'})
    print(OUTPUT / 'frozen_manifest_v1.json')


def run():
    manifest = json.loads((OUTPUT / 'frozen_manifest_v1.json').read_text())
    for name, sha in manifest['source_sha256'].items():
        if hashlib.sha256((ROOT / 'mydata_bench/auto_research_addbase' / name).read_bytes()).hexdigest() != sha:
            raise ValueError('Frozen source changed: ' + name)
    parts = {p: json.loads(pathlib.Path(path).read_text()) for p, path in manifest['partitions'].items()}
    full = json.loads(pathlib.Path(manifest['full_ids_path']).read_text())
    if fingerprint(full) != manifest['full_ids_sha256'] or any(fingerprint(ids) != manifest['partition_ids_sha256'][p] for p, ids in parts.items()):
        raise ValueError('Frozen IDs changed')
    if sum(map(len, parts.values())) != len(full) or set().union(*map(set, parts.values())) != set(full):
        raise ValueError('Invalid partition coverage')
    audits = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; out = OUTPUT / name
        if out.exists():
            raise ValueError('Preserve prior outputs; do not silently restart')
        parameters = case['parameters']; dev_blob = pathlib.Path(case['development_scores_path']).read_bytes()
        if hashlib.sha256(dev_blob).hexdigest() != case['development_scores_sha256']:
            raise ValueError('Frozen development scores changed')
        development = {(r['example_id'], r['condition']): r for r in map(json.loads, dev_blob.decode().splitlines())
                       if r['parameters'] == parameters}
        audit = {'sources': {}, 'n_rows': 0, 'n_invalid_rows': 0, 'development_replay_mismatch_ids': []}
        out.mkdir()
        with (out / 'scores.jsonl').open('x') as handle:
            for partition, folder in source_folders(case).items():
                blob = (folder / 'sweep.jsonl').read_bytes(); sha = hashlib.sha256(blob).hexdigest()
                if sha != case['parent_source_sha256'][partition]:
                    raise ValueError('Frozen parent scores changed')
                rows = collections.defaultdict(dict)
                for line in blob.decode().splitlines():
                    row = canonicalize(json.loads(line)); rows[row['condition']][row['example_id']] = row
                audit['sources'][partition] = {'folder': str(folder), 'sweep_sha256': sha}
                recipes = []
                for parent, k in zip(case['conditions'], case['selected_ks']):
                    recipes += [(name_for(parameters, parent), parent, k, 'method'),
                                (f'anchor_reference_rho{parameters["rho"]:g}_k{k}', 'baseline', k, 'anchor_only')]
                if partition == 'reused_validation':
                    primary_k = case['selected_ks'][case['conditions'].index(case['primary'])]
                    recipes += [('entropy_component__' + n, n, primary_k, 'fixed_target_anchor_component_control')
                                for n in rows if n.startswith('control_')]
                for condition, parent, k, role in recipes:
                    for eid in parts[partition]:
                        required = [rows[n].get(eid) for n in [parent, 'baseline', f'original_all_k{k}']]
                        row = {'example_id': eid, 'condition': condition, 'parameters': parameters, 'k': k,
                               'partition': partition, 'role': role, 'parent_condition': parent}
                        if any(r is None or r.get('status') != 'ok' for r in required):
                            row.update(status='error', error='One or more fixed source scores invalid'); audit['n_invalid_rows'] += 1
                        else:
                            logits, diagnostics = entropy_scaled_logits(*(r['score_logits'] for r in required), **parameters)
                            row.update(status='ok', score_logits=logits, **score_readout(logits, case['model']), **diagnostics)
                            if partition == 'development' and role == 'method' and any(row.get(f) != development[(eid, condition)].get(f) for f in ['score_logits', 'progress', 'native_prediction']):
                                audit['development_replay_mismatch_ids'].append([eid, condition])
                        handle.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + '\n'); audit['n_rows'] += 1
            handle.flush(); os.fsync(handle.fileno())
        audit.update(time=timestamp(), label_free_generation=True,
                     scores_sha256=hashlib.sha256((out / 'scores.jsonl').read_bytes()).hexdigest())
        create_json(out / 'generation_audit_v1.json', audit); audits[name] = audit
        print(name, 'selected frozen scores generated', flush=True)
    from .metrics import summarize
    from .analyze_development import contrast
    label_blob = (BASE / 'inputs/labels.jsonl').read_bytes()
    if hashlib.sha256(label_blob).hexdigest() != manifest['labels_sha256']:
        raise ValueError('Frozen labels changed')
    labels = {r['example_id']: r for r in map(json.loads, label_blob.decode().splitlines())}
    accepted = {p: collections.defaultdict(list) for p in ['full_cohort', *parts]}
    strict = {p: collections.defaultdict(list) for p in accepted}; files = {}
    for case in manifest['cases']:
        name = case['model'] + '_' + case['protocol']; out = OUTPUT / name
        parameters = case['parameters']; rows = collections.defaultdict(dict)
        for row in read_rows(out / 'scores.jsonl'):
            rows[row['condition']][row['example_id']] = row
        refs = list(dict.fromkeys(['baseline', 'native_generation_baseline', *case['conditions'],
                                   *[f'original_all_k{k}' for k in case['selected_ks']], case['best_development_original']]))
        for partition, folder in source_folders(case).items():
            blob = (folder / 'sweep.jsonl').read_bytes()
            if hashlib.sha256(blob).hexdigest() != case['parent_source_sha256'][partition]:
                raise ValueError('Frozen parent source changed during evaluation')
            for line in blob.decode().splitlines():
                row = canonicalize(json.loads(line))
                if row['condition'] in refs and row['example_id'] in set(parts[partition]):
                    rows[row['condition']][row['example_id']] = row
        method_names = [name_for(parameters, parent) for parent in case['conditions']]
        anchors = [f'anchor_reference_rho{parameters["rho"]:g}_k{k}' for k in case['selected_ks']]
        primary = name_for(parameters, case['primary']); reports = {}
        for partition, ids in {'full_cohort': full, **parts}.items():
            summaries = {n: summarize(rows[n].values(), labels, ids) for n in refs + method_names + anchors}
            comparisons = {}
            for condition, parent, k, anchor in zip(method_names, case['conditions'], case['selected_ks'], anchors):
                effects = {b: contrast(summaries[condition], summaries[b], case['model'] in {'meter', 'sole'})
                           for b in dict.fromkeys(['baseline', 'native_generation_baseline', f'original_all_k{k}', case['best_development_original'], parent, anchor])}
                for effect in effects.values():
                    effect.pop('confirmation', None); effect['evaluation_phase'] = 'entropy_exploratory_' + partition
                original = effects[f'original_all_k{k}']
                gate = all(effects[b].get('point_estimate_10pp_gate', False) for b in ['baseline', 'native_generation_baseline'])
                gate = gate and original.get('complete', False) and original.get('mae_delta', 1) < 0 and original.get('accuracy_delta', -1) > 0
                bins = all(summaries[condition]['overall']['mae'] is not None and summaries[b]['overall']['mae'] is not None
                           and summaries[condition]['overall']['mae'] < summaries[b]['overall']['mae'] for b in ['baseline', 'native_generation_baseline'])
                comparisons[condition] = {'effects': effects, 'point_gate': gate and bins, 'five_bin_mae_both_baselines': bins}
            passed = not audits[name]['development_replay_mismatch_ids'] and all(v['point_gate'] for v in comparisons.values())
            best = comparisons[primary]['effects'][case['best_development_original']]
            strict_pass = passed and best.get('complete', False) and best.get('mae_delta', 1) < 0 and best.get('accuracy_delta', -1) > 0
            reports[partition] = {'summaries': summaries, 'comparisons': comparisons, 'all_three_k_point_acceptance': passed,
                                  'strict_development_selected_original_acceptance': strict_pass}
            if passed: accepted[partition][case['model']].append(case['protocol'])
            if strict_pass: strict[partition][case['model']].append(case['protocol'])
        controls = {}
        for condition in list(rows):
            if not condition.startswith('entropy_component__'):
                continue
            ids = [eid for eid in parts['reused_validation'] if rows[condition].get(eid, {}).get('status') == 'ok' and rows[primary].get(eid, {}).get('status') == 'ok']
            c = summarize(rows[condition].values(), labels, ids); p = summarize(rows[primary].values(), labels, ids)
            effect = contrast(p, c, case['model'] in {'meter', 'sole'}); effect.pop('confirmation', None)
            controls[condition] = {'n_expected': len(parts['reused_validation']), 'n_feasible': len(ids),
                                   'primary_summary_on_feasible_subset': p, 'control_summary_on_feasible_subset': c,
                                   'effect': effect, 'scope': manifest['control_scope']}
        files[name] = str(out / 'analysis_v1.json')
        create_json(files[name], {'time': timestamp(), 'method_family': manifest['method_family'],
                    'model': case['model'], 'protocol': case['protocol'], 'parameters': parameters, 'rho': parameters['rho'],
                    'primary': primary, 'selected_ks': case['selected_ks'], 'partitions': reports,
                    'conditional_component_controls_reused_validation': controls, 'generation_audit': audits[name], 'boundary': manifest['boundary']})
        print(name, 'acceptance', {p: v['all_three_k_point_acceptance'] for p, v in reports.items()}, flush=True)
    create_json(OUTPUT / 'summary_v1.json', {
        'time': timestamp(), 'method_family': manifest['method_family'], 'manifest_sha256': fingerprint(manifest), 'case_files': files,
        'accepted_protocols_by_partition': {p: dict(v) for p, v in accepted.items()},
        'three_models_three_inputs_point_by_partition': {p: sum(len(v) >= 3 for v in models.values()) >= 3 for p, models in accepted.items()},
        'strict_accepted_protocols_by_partition': {p: dict(v) for p, v in strict.items()},
        'three_models_three_inputs_strict_by_partition': {p: sum(len(v) >= 3 for v in models.values()) >= 3 for p, models in strict.items()},
        'original_and_anchor_failures_not_rewritten': True, 'boundary': manifest['boundary'],
        'statistics': 'Descriptive reused-data metrics only; no independent-test or confirmatory-p claim for this adaptive follow-up.'})
    print(OUTPUT / 'summary_v1.json', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--freeze', action='store_true'); args = parser.parse_args()
    freeze() if args.freeze else run()
