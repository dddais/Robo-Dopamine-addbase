"""Descriptive support for instruction contrasts in frozen fit data, not an experiment."""
import collections
import itertools
import json
from .common import BASE, create_json, read_rows, timestamp
from .robust_prepare import DEST, digest


def characterize(samples, grades, key):
    groups=collections.defaultdict(list)
    for row in samples:
        groups[key(row)].append(row)
    histogram=collections.Counter()
    mixed_groups=endpoint_groups=0
    mixed_rows=set()
    for values in groups.values():
        informative=endpoint=False
        for a,b in itertools.combinations(values,2):
            same_task=a['task']==b['task']
            different_grade=grades[a['example_id']]!=grades[b['example_id']]
            histogram['within_visual_group_pairs']+=1
            if not same_task:
                histogram['different_instruction_pairs']+=1
            if not same_task and different_grade:
                informative=True
                mixed_rows.update([a['example_id'],b['example_id']])
                histogram['different_instruction_different_grade_pairs']+=1
                histogram['grade_gap_'+str(abs(grades[a['example_id']]-grades[b['example_id']]))]+=1
                if a.get('grounding_status')=='ok' and b.get('grounding_status')=='ok':
                    histogram['different_instruction_different_grade_both_grounded']+=1
                if {grades[a['example_id']],grades[b['example_id']]}=={1,5}:
                    endpoint=True
                    histogram['grade1_vs5_different_instruction_pairs']+=1
        mixed_groups+=informative
        endpoint_groups+=endpoint
    return dict(rows=len(samples),visual_groups=len(groups),multirow_visual_groups=sum(len(v)>1 for v in groups.values()),
        informative_groups=mixed_groups,informative_unique_rows=len(mixed_rows),grade1_vs5_informative_groups=endpoint_groups,
        pair_counts=dict(histogram),task_matching='exact task string, no semantic normalization',pairs_are_dependent=True)


def main():
    inputs=DEST/'external_training_research_v1/grounding_v1/grounded_inputs_v1.jsonl'
    label_path=DEST/'external_training_research_v1/fit_labels_only_v1.jsonl'
    rows=[r for r in read_rows(inputs) if r['training_partition']=='fit']
    labels={r['example_id']:r['reward'] for r in read_rows(label_path)}
    if {r['example_id'] for r in rows}!=set(labels):
        raise ValueError('Fit-only cohort/label mismatch')
    old=list(read_rows(BASE/'inputs/cohort.jsonl'))
    old_ids={r['example_id'] for r in old}
    old_labels={r['example_id']:r['reward'] for r in read_rows(BASE/'inputs/labels.jsonl') if r['example_id'] in old_ids}
    if set(old_labels)!=old_ids:
        raise ValueError('Old exposed cohort/label mismatch')
    result=dict(time=timestamp(),source_sha256=digest(__file__),fit_input_sha256=digest(inputs),fit_labels_sha256=digest(label_path),
        fit_encoded_video=characterize(rows,labels,lambda r:r['video_sha256']),
        fit_displayed_frame_signature=characterize(rows,labels,lambda r:json.dumps(r['decoded_frame_pixel_sha256'],sort_keys=True,separators=(',',':'))),
        old846_encoded_video=characterize(old,old_labels,lambda r:r['video_sha256']),old_cohort_sha256=digest(BASE/'inputs/cohort.jsonl'),
        prior_inline_attempt='schema assumption label instead of actual reward caused KeyError before any output artifact; corrected from inspected schema',
        interpretation='descriptive training/design audit; no method performance, no validation/reserved labels, no pairwise method selected',
        final_goal_completed=False)
    create_json(DEST/'fit_instruction_contrast_support_audit_v1.json',result)
    for key in ['fit_encoded_video','fit_displayed_frame_signature','old846_encoded_video']:
        print(key,result[key],flush=True)


if __name__=='__main__':
    main()
