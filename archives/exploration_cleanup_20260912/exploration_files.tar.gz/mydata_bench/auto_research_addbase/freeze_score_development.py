"""Freeze development-only branch and contrast grids before seeing their scores."""
import yaml
from .common import *


def main():
    dest=RESEARCH/'score_development_v1';dest.mkdir(parents=True,exist_ok=True)
    branches=[{'name':'baseline','k':0},{'name':'native_generation_baseline','k':0,'kind':'native_generation'},
              {'name':'zero_preserve_k32','k':32,'kind':'visual_preserve','bias':0.,'scope':'last_frame'}]
    recipes=[]
    for k in [32,64]:
        branches.append({'name':f'original_all_k{k}','k':k,'kind':'bias','bias':6.,'scope':'all_frames'})
        for scope in ['last_frame','all_frames']:
            for control in (['target','wrong','low_rank'] if scope=='last_frame' else ['target']):
                prefix=f'{control}_{scope}_b3_k{k}'
                for sign,bias in [('plus',3.),('minus',-3.)]:
                    branches.append({'name':f'{prefix}_{sign}','k':k,'kind':'visual_preserve','bias':bias,'scope':scope,
                                     'region':'wrong' if control=='wrong' else 'target','head_group':'low' if control=='low_rank' else 'high'})
                for weight in [.5,1.,2.,4.]:
                    recipes.append({'name':f'contrast_{prefix}_lambda{weight:g}','k':k,'contrast_weight':weight,
                                    'scope':scope,'region':control,'source_branches':['baseline',f'{prefix}_plus',f'{prefix}_minus']})
    recipes=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes
    configs=[]
    for model in ['qwen','rr','meter']:
        for protocol in ['text_video','video_text','text_image','image_text','interleaved']:
            source=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_development_v1_{model}_{protocol}.yaml'
            cfg=yaml.safe_load(source.read_text());out=dest/f'{model}_{protocol}'
            cfg.update(output_dir=str(out),branch_conditions=branches,conditions=recipes,stage='prospectively_frozen_score_development_only',attention_engine='native_residual',
                       combination='z0 + lambda*(z_plus-z_minus); native five-score argmax or native ten-bin expected progress',
                       selection_rule='Require complete target conditions, native-vs-prefix baseline parity audit, all four favorable point directions, total accuracy >=10pp versus BOTH readout-only and original generation baselines, and improvement vs original bias. Then extend selected mechanism and adjacent k to all234 development samples with controls. Confirmation498 remains unused.',
                       engineering_evidence='score_engineering_v1; zero residual logits exact and original generation vs prefix score audit, recorded separately')
            path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_score_development_v1_{model}_{protocol}.yaml'
            with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            configs.append({'model':model,'protocol':protocol,'path':str(path),'sha256':fingerprint(cfg),'preferred_ranking_source':str(RESEARCH/f'development_v1/{model}_{protocol}/ranking.json'),'fallback_meter_ranking_source':str(BASE/f'meter_{protocol}_v1/ranking.json') if model=='meter' else None})
    create_json(dest/'prospective_plan.json',{'time':timestamp(),'phase':'development only','sample_ids':'same 60 examples /24 whole video clusters as first candidate','branch_conditions':branches,'derived_conditions':recipes,'configs':configs,'all_native_score_bins_retained':True,'no_confirmation_data_used':True})
    print(dest,len(branches),'forward branches',len(recipes),'total readouts per sample')
if __name__=='__main__':main()
