import unittest
import numpy as np
from .kl_budget import kl_budget_tilt,logsumexp
from .combine_scores import combine_logits


class KLBudgetTests(unittest.TestCase):
    def test_exact_budget_and_full_support(self):
        base=np.array([-.7,1.,2.,.1,-2.]);direction=np.array([3.,-1.,.4,-.6,1.])
        for delta in [.25,.5,1.,2.,4.]:
            result,meta=kl_budget_tilt(base,direction,delta)
            result=np.asarray(result);logp=base-logsumexp(base);logq=result-logsumexp(result)
            actual=float(np.exp(logp)@(logp-logq))
            self.assertAlmostEqual(actual,delta,places=10)
            self.assertAlmostEqual(meta['achieved_kl_p0_to_candidate_nats'],actual,places=10)
            self.assertEqual(result.shape,base.shape)
            self.assertTrue(np.isfinite(result).all())

    def test_zero_and_constant_directions_remain_baseline(self):
        base=[1.,3.,-2.,.5,0.]
        for direction,delta in [([4.]*5,2.),([0.]*5,2.),([1.,0.,2.,3.,-1.],0.)]:
            result,meta=kl_budget_tilt(base,direction,delta)
            np.testing.assert_array_equal(result,base);self.assertEqual(meta['effective_contrast_weight'],0.)

    def test_shift_invariance_and_gain_cap(self):
        base=np.array([1.,3.,-2.,.5,0.]);direction=np.array([.3,-.2,.1,-.1,.4])
        a,_=kl_budget_tilt(base,direction,1.)
        b,_=kl_budget_tilt(base+10.,direction+7.,1.)
        np.testing.assert_allclose(np.array(a)-logsumexp(np.array(a)),np.array(b)-logsumexp(np.array(b)),atol=1e-12)
        _,audit=kl_budget_tilt(base,direction*1e-8,4.,64.)
        self.assertEqual(audit['effective_contrast_weight'],64.)
        self.assertLess(audit['achieved_kl_p0_to_candidate_nats'],4.)

    def test_readout_temperature_control_uses_same_budget(self):
        base=[-1.,0.,3.,1.,2.];audit={}
        result=combine_logits([base],{'contrast_weight':1.,'combination_type':'native_logit_temperature','target_kl':1.},diagnostics=audit)
        self.assertEqual(np.argmax(result),np.argmax(base))
        self.assertAlmostEqual(audit['kl_budget_audit']['achieved_kl_p0_to_candidate_nats'],1.,places=10)


if __name__=='__main__':unittest.main()
