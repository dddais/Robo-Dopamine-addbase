"""Ablate finite-difference radius independently of the query-row restriction."""
import yaml
from .common import *


def main():
    root=RESEARCH/'score_local_radius_development_v1';plans=[]
    for model in ['meter','rr','qwen']:
        for protocol in ['text_image','interleaved','image_text','video_text','text_video']:
            source=RESEARCH/f'score_development_v1/{model}_{protocol}';cfg=json.loads((source/'config.json').read_text());out=root/f'{model}_{protocol}'
            branches=[c for c in cfg['branch_conditions'] if c['name'] in {'baseline','native_generation_baseline','zero_preserve_k32','original_all_k32','original_all_k64'}];recipes=[]
            for bias in [.5,1.5]:
                for scope in ['last_frame','all_frames']:
                    for k in [32,64]:
                        for control in (['target','wrong','low_rank'] if bias==1.5 and k==32 else ['target']):
                            prefix=f'{control}_local_{scope}_b{bias:g}_k{k}'
                            for sign,value in [('plus',bias),('minus',-bias)]:branches.append({'name':prefix+'_'+sign,'k':k,'kind':'visual_preserve','bias':value,'scope':scope,'query_scope':'all','region':'wrong' if control=='wrong' else 'target','head_group':'low' if control=='low_rank' else 'high'})
                            for gain in [3.,6.,12.,24.]:recipes.append({'name':f'contrast_{prefix}_gamma{gain:g}','k':k,'contrast_weight':gain/(2*bias),'direction_gain':gain,'central_difference_radius':bias,'scope':scope,'region':control,'source_branches':['baseline',prefix+'_plus',prefix+'_minus']})
            cfg.update(output_dir=str(out),stage='prospectively_frozen_local_radius_development',branch_conditions=branches,conditions=[{'name':c['name'],'k':c['k'],'source_branches':[c['name']]} for c in branches]+recipes,
                hypothesis='b3 changes target/background odds by exp6 and may saturate visual redistribution. Test b0.5/b1.5 with the same derivative gains while retaining all-query intervention; this separates radius from the rejected readout-only factor.',
                combination='z0 + gamma*(z(+b)-z(-b))/(2b), all queries, all native bins',
                selection_rule='Strict final234/confirmation gates unchanged. Only a100% suc ceiling on60 permits nondecrease as an extension screen, not as acceptance.')
            path=ROOT/f'mydata_bench/configs/v2_crossmodel/addbase_local_radius_development_v1_{model}_{protocol}.yaml'
            with path.open('x') as f:yaml.safe_dump(cfg,f,sort_keys=False)
            create_json(out/'ranking.json',json.loads((source/'ranking.json').read_text()))
            src=source/'score_branches.jsonl';blob=src.read_bytes();digest=hashlib.sha256(blob).hexdigest();reuse_names={'baseline','native_generation_baseline','zero_preserve_k32','original_all_k32','original_all_k64'};seen=set()
            for line in blob.decode().splitlines():
                r=json.loads(line)
                if r['condition'] in reuse_names:
                    key=(r['example_id'],r['condition'])
                    if key in seen:raise ValueError('Expected unique baseline/control source rows')
                    seen.add(key);append(out/'score_branches.jsonl',{**r,'reused_from':str(src),'reused_source_sha256':digest,'reuse_time':timestamp()})
            create_json(out/'prospective_plan.json',{'time':timestamp(),'reason':cfg['hypothesis'],'config':cfg,'config_sha256':fingerprint(cfg),'reused_rows':len(seen),'source_sha256':digest,'confirmation_metrics_used':False})
            plans.append(str(path))
    create_json(root/'prospective_plan.json',{'time':timestamp(),'configs':plans,'phase':'same60 development examples/24 video groups','new_branches_per_case':24,'mathematical_engine':'unchanged native residual, with tested positive/negative continuous bias parameter'})
    print(root,'15 cases; all-query smaller radius,24 new neural branches/case')


if __name__=='__main__':main()
